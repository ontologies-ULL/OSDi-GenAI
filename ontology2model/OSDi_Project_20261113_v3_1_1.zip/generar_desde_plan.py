#!/usr/bin/env python3
"""Validate and render an AI-authored model plan. No TTL-to-tree fallback exists."""
import argparse
import hashlib
import json
import re
import sys
import uuid
from pathlib import Path
from tempfile import TemporaryDirectory

PACKAGE = Path(__file__).resolve().parent
sys.path.insert(0, str(PACKAGE / 'engine'))
from ai_contract import prepare_context, validate_plan
from plan_renderer import render_plan
from presentation import present
from ooxml import patch_workbook, load_profile, col_letter
from evaluate import Evaluator

ENGINE_VERSION = '3.1'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def output_stem(model):
    local = model.rsplit('#', 1)[-1].rsplit('/', 1)[-1]
    stem = re.sub(r'[^A-Za-z0-9_.-]', '_', local).strip(' .') or 'model'
    if re.fullmatch(r'(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?', stem, re.I):
        stem = 'model_' + stem
    if len(stem) > 140:
        stem = stem[:120] + '_' + hashlib.sha256(model.encode()).hexdigest()[:12]
    return stem


def generate(case, plan_path, out, schema=None, template=None, compatibility_profile=None):
    out = Path(out)
    if out.exists() and any(out.iterdir()):
        raise ValueError('Output directory is not empty; choose a new directory for every attempt.')
    out.mkdir(parents=True, exist_ok=True)
    template = Path(template or PACKAGE / 'PLANTILLA_BASE.xlsm')
    report = {'engine_version': ENGINE_VERSION, 'run_id': uuid.uuid4().hex, 'status': 'BLOCKED',
              'mode': 'AI_AUTHORED_PLAN_WITH_MECHANICAL_RENDERER', 'scope': ['Parameters', 'Model'],
              'native_excel_recalculation': 'NOT_RUN', 'macros_executed': False,
              'other_sheets': 'NOT_INSPECTED', 'numerical_payoffs': 'NOT_VALIDATED_EXTERNAL_DEPENDENCIES',
              'reference_data_used_by_renderer': False, 'semantic_completeness': 'NOT_PROVEN',
              'ai_authorship_verifiable_from_plan_alone': False,
              'deterministic_semantic_fallback': False}
    stem = 'ERROR'
    published = []
    def remove_uncommitted_outputs():
        # These paths were created by this attempt in an initially empty directory.
        # Keep the submitted AI plan and diagnostics, never touch source files.
        for path in reversed(published):
            if path.resolve().parent != out.resolve():
                raise ValueError('Refusing to clean a path outside this execution directory.')
            path.unlink(missing_ok=True)
    try:
        # Preserve the exact submitted artifact, including rejected attempts.
        plan_bytes = Path(plan_path).read_bytes()
        report['plan_sha256'] = hashlib.sha256(plan_bytes).hexdigest()
        (out / 'submitted.ai-plan.json').write_bytes(plan_bytes)
        plan = json.loads(plan_bytes)
        context = prepare_context(case, schema, compatibility_profile, PACKAGE)
        report['sources'] = {'case_sha256': digest(case), 'schema_sha256': context['schema_sha256'],
                             'template_sha256': digest(template)}
        report['schema_selection'] = context['schema_selection']
        report['plan_checks'] = validate_plan(plan, context)
        report['authorship_claim'] = plan['authorship']
        report['model'] = plan['model_iri']
        report['decisions'] = plan['decisions']
        stem = output_stem(plan['model_iri'])
        compiled, parameter_cells, names = render_plan(plan)
        style = load_profile()
        sheets = present(compiled, parameter_cells, style)
        for index, intervention in enumerate(plan['interventions'], 3):
            local = intervention['iri'].rsplit('#', 1)[-1].rsplit('/', 1)[-1]
            for metric, column in [('C', 'D'), ('LE', 'E'), ('QALE', 'F')]:
                name = metric + '_' + re.sub(r'[^A-Za-z0-9_.]', '_', local)
                if len(name) > 255:
                    name = name[:240] + '_' + hashlib.sha256(intervention['iri'].encode()).hexdigest()[:12]
                if name.casefold() in {n.casefold() for n in names}:
                    raise ValueError('Result/parameter name collision: ' + name)
                names[name] = "'Model'!$" + column + '$' + str(index)
        scoped = [{'name': name, 'sheet': sheet, 'value': str(value)}
                  for sheet in ['Parameters', 'Model'] for name, value in plan['settings'].items()]
        numeric = {p['name']: p['expected'] for p in plan['parameters']}
        evaluator = Evaluator(compiled['cells'], {**numeric, **plan['settings']})
        sibling_groups = {}
        for edge, parent_column, parent_row in compiled['edges']:
            value = evaluator.cell(col_letter(edge.column) + str(edge.row + 1))
            if not -1e-10 <= value <= 1 + 1e-10:
                raise ValueError('Invalid branch probability: ' + edge.label)
            sibling_groups.setdefault((parent_column, parent_row), []).append(value)
        for values in sibling_groups.values():
            if abs(sum(values) - 1) > 1e-10:
                raise ValueError('Sibling probabilities do not sum to one: ' + str(values))
        masses = []
        for intervention, first, last in compiled['starts']:
            values = [evaluator.cell(col_letter(compiled['output_col']) + str(edge.row))
                      for edge, _ in compiled['leaves'] if first <= edge.row <= last]
            if any(not -1e-10 <= value <= 1 + 1e-10 for value in values) or abs(sum(values) - 1) > 1e-10:
                raise ValueError('Invalid terminal probability mass for ' + intervention)
            masses.append({'intervention': intervention, 'leaves': len(values), 'probability_sum': sum(values)})
        target = out / (stem + '.xlsm')
        with TemporaryDirectory(prefix='osdi_render_', dir=out) as temporary:
            candidate = Path(temporary) / target.name
            preservation = patch_workbook(template, candidate, sheets, names, scoped_names=scoped,
                                          expected_styles_fingerprint=style['styles_fingerprint'])
            if digest(case) != context['case_sha256']:
                raise ValueError('Input changed while rendering.')
            candidate.replace(target)
            published.append(target)
        ir = {'model': plan['model_iri'], 'authored_plan_sha256': report['plan_sha256'],
              'parameters': plan['parameters'], 'settings': plan['settings'],
              'interventions': [{'iri': i, 'first_row': first, 'last_row': last} for i, first, last in compiled['starts']],
              'routes': [{'row': edge.row, 'probability_cells': path, 'active_progressions': list(edge.active),
                          'state': edge.state} for edge, path in compiled['leaves']]}
        ir_target = out / (stem + '.ir.json')
        published.append(ir_target)
        ir_target.write_text(json.dumps(ir, ensure_ascii=False, indent=2), encoding='utf-8')
        report.update(status='GENERATED_STRUCTURALLY_VALIDATED', file=target.name,
                      parameters=len(plan['parameters']), leaves=len(compiled['leaves']), depth=compiled['depth'],
                      probabilities=masses, settings=plan['settings'], preservation=preservation,
                      output_sha256=digest(target), uninspected_dependencies=sorted(set(
                          ['CPI', 'language', 'unitLE', 'unitQALE', 'Localization labels']
                          + plan.get('unresolved_dependencies', []))))
    except (ValueError, OSError, TypeError, KeyError, RecursionError, OverflowError, ZeroDivisionError) as error:
        remove_uncommitted_outputs()
        report['reason'] = str(error)
        report['status'] = 'BLOCKED'
        report.pop('file', None)
    try:
        (out / (stem + '.validation.json')).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    except (OSError, ValueError, TypeError):
        remove_uncommitted_outputs()
        raise
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ttl', required=True, type=Path)
    parser.add_argument('--plan', required=True, type=Path, help='Mandatory AI-authored plan; Python cannot supply it.')
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--schema', type=Path)
    parser.add_argument('--template', type=Path)
    parser.add_argument('--compatibility-profile')
    args = parser.parse_args()
    try:
        report = generate(args.ttl, args.plan, args.out, args.schema, args.template, args.compatibility_profile)
    except (ValueError, OSError) as error:
        report = {'engine_version': ENGINE_VERSION, 'status': 'BLOCKED', 'reason': str(error)}
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report['status'] == 'GENERATED_STRUCTURALLY_VALIDATED' else 1


if __name__ == '__main__':
    sys.exit(main())
