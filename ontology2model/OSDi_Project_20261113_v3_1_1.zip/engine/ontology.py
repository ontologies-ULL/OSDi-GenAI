"""Dependency-free, bounded Turtle reader and OSDi graph inspection.

This is a Turtle/RDF reader, not an OWL reasoner. It supports the syntax used by
the supplied OSDi schema and cases, including anonymous restrictions and lists.
Named class inheritance and explicitly declared inverse properties are applied.
This is not complete OWL entailment. Remote imports are never fetched implicitly.
This version exposes source facts and vocabulary checks only. Tree topology and payoff
expressions are supplied by the AI plan, outside this module.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
import hashlib
import math
import re
from urllib.parse import urljoin

OSDI = "https://w3id.org/ontologies-ULL/OSDi#"
RDF = "http://www.w3.org/1999/02/22-rdf-syntax-ns#"
RDFS = "http://www.w3.org/2000/01/rdf-schema#"
OWL = "http://www.w3.org/2002/07/owl#"
XSD = "http://www.w3.org/2001/XMLSchema#"
COMPATIBILITY_PROFILE='declared-1.0-modern-1.1'
AUDITED_SCHEMA_HASHES={'1.0':'0ff3901b2477ffdadeb70e8905d3c10320f75d4ea00998e2a16eccdb24d4e283',
                       '1.1':'a15a887311b24f11b4018fb0cc6512b72efb9b66d8385fd967937a4dfcc62577'}
LEGACY_1_0_PROPERTIES={'hasProbabilityOfDeath','hasLifeExpectancyReduction','hasIncreasedMortalityRate',
    'involvesModification','isModificationOf','isModifiedBy','modifies','hasScreeningCost',
    'hasDiagnosisCost','hasProbabilityOfDiagnosis','usesDrug','usesFollowUpTest','usesTreatment','REMOVEhasFrequency'}


class OntologyError(ValueError):
    """Unsupported or inconsistent source data; generation must not guess."""


@dataclass(frozen=True)
class Literal:
    lexical: str
    datatype: str | None = None
    language: str | None = None

    @property
    def value(self):
        # RDF datatype identity is the complete IRI. A user vocabulary called
        # ex:double or ex:boolean must never acquire XSD numeric semantics.
        dt = self.datatype[len(XSD):] if self.datatype and self.datatype.startswith(XSD) else ''
        if dt == "boolean":
            if self.lexical in ("true", "1"): return True
            if self.lexical in ("false", "0"): return False
            raise OntologyError(f"Invalid boolean literal: {self.lexical!r}")
        if dt in {"byte", "short", "int", "integer", "long", "nonNegativeInteger", "positiveInteger", "unsignedInt", "unsignedLong", "unsignedShort", "unsignedByte"}:
            try: return int(self.lexical)
            except ValueError as exc: raise OntologyError(f"Invalid integer literal: {self.lexical!r}") from exc
        if dt in {"float", "double", "decimal"}:
            try: val = float(self.lexical)
            except ValueError as exc: raise OntologyError(f"Invalid number: {self.lexical!r}") from exc
            if not math.isfinite(val): raise OntologyError(f"Non-finite model number: {self.lexical!r}")
            return val
        return self.lexical


def local(term):
    if isinstance(term, Literal): return term.lexical
    return str(term).rsplit("#", 1)[-1].rsplit("/", 1)[-1]


def iri(term):
    if not isinstance(term, str): return term
    if ":" in term or term.startswith("_:"): return term
    return OSDI + term


def plain(term):
    return term.value if isinstance(term, Literal) else term


def sort_key(term):
    if isinstance(term, Literal): return (1, term.lexical, term.datatype or "", term.language or "")
    return (0, str(term), "", "")


def _resolve(base, reference):
    result=urljoin(base,reference)
    # urllib drops an empty fragment on relative IRIs, but a namespace ending
    # in '#' must retain that delimiter before a QName local part is appended.
    if reference.endswith('#') and not result.endswith('#'): result+='#'
    return result


def _unescape(text, literal=True):
    escapes = {"t": "\t", "b": "\b", "n": "\n", "r": "\r", "f": "\f", '"': '"', "'": "'", "\\": "\\"}
    def replace(m):
        s = m.group(1)
        if s[0] in "uU":
            n = int(s[1:], 16)
            if n > 0x10FFFF or 0xD800 <= n <= 0xDFFF: raise OntologyError("Invalid Unicode escape")
            return chr(n)
        if s in escapes: return escapes[s]
        if not literal and s in "_~.-!$&'()*+,;=/?#@%:": return s
        raise OntologyError(f"Unsupported escape \\{s}")
    return re.sub(r"\\(u[0-9a-fA-F]{4}|U[0-9a-fA-F]{8}|.)", replace, text)


class TurtleParser:
    """Explicit subset of RDF 1.1 Turtle, with strict end-of-input checks."""
    def __init__(self, text, source="memory", base=""):
        self.text, self.source, self.base = text.lstrip("\ufeff"), source, base
        self.pos = 0
        self.prefixes = {}
        self.triples = []
        self.counter = 0
        self.tag = hashlib.sha256(str(source).encode()).hexdigest()[:12]
        self.lookahead = None

    def fail(self, message):
        line = self.text.count("\n", 0, self.pos) + 1
        raise OntologyError(f"{self.source}:{line}: {message}")

    def token(self):
        if self.lookahead is not None:
            out, self.lookahead = self.lookahead, None
            return out
        n = len(self.text)
        while self.pos < n:
            if self.text[self.pos].isspace(): self.pos += 1; continue
            if self.text[self.pos] == "#":
                end = self.text.find("\n", self.pos)
                self.pos = n if end < 0 else end + 1
                continue
            break
        if self.pos == n: return ("EOF", "")
        start = self.pos
        ch = self.text[start]
        if self.text.startswith("<<", start): self.fail("RDF-star quoted triples are not supported")
        if self.text.startswith("^^", start): self.pos += 2; return ("^^", "^^")
        if ch in ";,[]()": self.pos += 1; return (ch, ch)
        if ch == "<":
            end = self.text.find(">", start + 1)
            if end < 0: self.fail("Unterminated IRI")
            raw = self.text[start + 1:end]
            if re.search(r'[<>"{}|^`\x00-\x20]', raw): self.fail("Invalid character in IRI")
            self.pos = end + 1
            return ("IRI", _unescape(raw, False))
        if ch in "\"'":
            quote = ch * (3 if self.text.startswith(ch * 3, start) else 1)
            self.pos += len(quote)
            content_start = self.pos
            while self.pos < n:
                if self.text[self.pos] == "\\": self.pos += 2; continue
                if self.text.startswith(quote, self.pos):
                    raw = self.text[content_start:self.pos]
                    self.pos += len(quote)
                    if len(quote) == 1 and ("\n" in raw or "\r" in raw): self.fail("Newline in short string")
                    return ("STRING", _unescape(raw))
                self.pos += 1
            self.fail("Unterminated string")
        number = re.match(r"[+-]?(?:(?:[0-9]+\.[0-9]*|\.[0-9]+|[0-9]+)[eE][+-]?[0-9]+|[0-9]*\.[0-9]+|[0-9]+)", self.text[start:])
        if number:
            end = start + len(number.group())
            if end == n or self.text[end].isspace() or self.text[end] in ";,.)]#":
                self.pos = end
                return ("NUMBER", number.group())
        if ch == ".": self.pos += 1; return (".", ".")
        end = start
        while end < n and not self.text[end].isspace() and self.text[end] not in ";,[]()<>\"'#":
            if self.text[end] == "\\" and end + 1 < n: end += 2
            else: end += 1
        word = self.text[start:end]
        while word.endswith(".") and not word.endswith("\\."):
            word, end = word[:-1], end - 1
        if not word: self.fail(f"Unexpected character {ch!r}")
        self.pos = end
        return ("WORD", word)

    def peek(self):
        if self.lookahead is None: self.lookahead = self.token()
        return self.lookahead

    def expect(self, kind):
        tok = self.token()
        if tok[0] != kind: self.fail(f"Expected {kind}, found {tok!r}")
        return tok[1]

    def blank(self, label=None):
        if label is not None: return f"_:{self.tag}_label_{label}"
        self.counter += 1
        return f"_:{self.tag}_anon_{self.counter}"

    def node(self, predicate=False):
        kind, text = self.token()
        if kind == "IRI": return _resolve(self.base, text)
        if kind == "WORD":
            if predicate and text == "a": return RDF + "type"
            if text in ("true", "false"): return Literal(text, XSD + "boolean")
            if text.startswith("_:"): return self.blank(text[2:])
            if ":" not in text: self.fail(f"Expected prefixed name, found {text!r}")
            pre, name = text.split(":", 1)
            if pre not in self.prefixes: self.fail(f"Undefined prefix {pre!r}")
            return self.prefixes[pre] + _unescape(name, False)
        if kind == "NUMBER":
            dt = "double" if "e" in text.lower() else "decimal" if "." in text else "integer"
            return Literal(text, XSD + dt)
        if kind == "STRING":
            dt, lang = None, None
            if self.peek()[0] == "^^": self.token(); dt = self.node()
            elif self.peek()[0] == "WORD" and self.peek()[1].startswith("@"):
                lang = self.token()[1][1:].lower()
                if not re.fullmatch(r"[a-zA-Z]+(?:-[a-zA-Z0-9]+)*", lang): self.fail("Invalid language tag")
            return Literal(text, dt, lang)
        if kind == "[":
            subj = self.blank()
            if self.peek()[0] != "]": self.predicate_list(subj)
            self.expect("]")
            return subj
        if kind == "(":
            items = []
            while self.peek()[0] != ")":
                if self.peek()[0] == "EOF": self.fail("Unterminated RDF collection")
                items.append(self.node())
            self.token()
            tail = RDF + "nil"
            for item in reversed(items):
                head = self.blank()
                self.triples.extend([(head, RDF + "first", item), (head, RDF + "rest", tail)])
                tail = head
            return tail
        self.fail(f"Unexpected RDF term {kind} {text!r}")

    def predicate_list(self, subject):
        while True:
            pred = self.node(predicate=True)
            if not isinstance(pred, str) or pred.startswith("_:"): self.fail("Predicate must be an IRI")
            while True:
                self.triples.append((subject, pred, self.node()))
                if self.peek()[0] != ",": break
                self.token()
            if self.peek()[0] != ";": return
            while self.peek()[0] == ";": self.token()
            if self.peek()[0] in (".", "]"): return

    def parse(self):
        while self.peek()[0] != "EOF":
            tok = self.peek()
            if tok[0] == "WORD" and tok[1].lower() in ("@prefix", "prefix", "@base", "base"):
                directive = self.token()[1]
                if "prefix" in directive.lower():
                    pre = self.expect("WORD")
                    if not pre.endswith(":"): self.fail("Prefix declaration lacks colon")
                    self.prefixes[pre[:-1]] = _resolve(self.base, self.expect("IRI"))
                else: self.base = _resolve(self.base, self.expect("IRI"))
                if directive.startswith("@"): self.expect(".")
                continue
            subject = self.node()
            if isinstance(subject, Literal): self.fail("Literal cannot be RDF subject")
            # A non-empty blank-node property list may itself be a statement.
            if self.peek()[0] != ".": self.predicate_list(subject)
            self.expect(".")
        return self.triples


def parse_turtle(path):
    path = Path(path)
    parser = TurtleParser(path.read_text(encoding="utf-8-sig"), str(path), path.resolve().as_uri())
    return parser.parse()


def osdi_version_declaration(triples, source='ontology'):
    """Read the canonical ontology's own version, never a case ontology's label."""
    base=OSDI.rstrip('#')
    declared=any(s==base and p==RDF+'type' and o==OWL+'Ontology' for s,p,o in triples)
    version_iris={o for s,p,o in triples if s==base and p==OWL+'versionIRI'}
    version_info={o for s,p,o in triples if s==base and p==OWL+'versionInfo'}
    if len(version_iris)>1 or len(version_info)>1:
        raise OntologyError('Ambiguous OSDi version declarations in '+source+'.')
    if (version_iris or version_info) and not declared:
        raise OntologyError('OSDi version metadata lacks its canonical owl:Ontology declaration in '+source+'.')
    version_iri=next(iter(version_iris),None)
    info_term=next(iter(version_info),None)
    if version_iri is not None and (not isinstance(version_iri,str) or not version_iri.startswith(base+'/') or '#' in version_iri or '/' in version_iri[len(base)+1:]):
        raise OntologyError('Invalid canonical OSDi versionIRI in '+source+'.')
    if info_term is not None and not isinstance(info_term,Literal):
        raise OntologyError('OSDi versionInfo must be a literal in '+source+'.')
    info=info_term.lexical if info_term is not None else None
    iri_version=version_iri[len(base)+1:] if version_iri is not None else None
    if iri_version is not None and info is not None and iri_version!=info:
        raise OntologyError('Conflicting OSDi versionIRI/versionInfo in '+source+': '+iri_version+' versus '+info+'.')
    return {'ontology_declared':declared,'version':iri_version or info,
            'version_iri':version_iri,'version_info':info}


def osdi_import_identifiers(triples):
    base=OSDI.rstrip('#')
    return sorted({o for _,p,o in triples if p==OWL+'imports' and isinstance(o,str)
                   and (o==base or o.startswith(base+'/') or o.startswith(base+'#'))})


class Dataset:
    def __init__(self, case_path, schema_path=None, aliases=None, compatibility=None):
        self.case_path = str(Path(case_path).resolve())
        self.schema_path = str(Path(schema_path).resolve()) if schema_path else None
        self.case_triples = parse_turtle(case_path)
        self.schema_triples = parse_turtle(schema_path) if schema_path else []
        self.triples = set(self.case_triples + self.schema_triples)
        self.forward = defaultdict(lambda: defaultdict(set))
        self.backward = defaultdict(lambda: defaultdict(set))
        for s, p, o in self.triples:
            self.forward[s][p].add(o)
            self.backward[p][o].add(s)
        self.aliases = dict(aliases or {})
        self.diagnostics = []
        self._inverse_properties = defaultdict(set)
        for s, p, o in self.triples:
            if p == OWL + "inverseOf" and isinstance(o, str) and not s.startswith("_:") and not o.startswith("_:"):
                self._inverse_properties[s].add(o)
                self._inverse_properties[o].add(s)
        self._class_cache = {}
        self._type_cache = {}
        self.source_metadata = self._source_metadata()
        self.compatibility=dict(compatibility) if compatibility is not None else None
        if self.compatibility is not None:self._validate_explicit_compatibility()
        self._check_imports()
        self._check_schema_version()
        self._detect_constant_aliases()

    def _source_metadata(self):
        """Record source declarations without interpreting version labels as aliases."""
        def describe(triples):
            ontologies = sorted({s for s,p,o in triples if p == RDF + 'type' and o == OWL + 'Ontology'})
            return {
                'ontologies': ontologies,
                'version_iris': sorted({o for s,p,o in triples if s in ontologies and p == OWL + 'versionIRI' and isinstance(o,str)}),
                'version_info': sorted({str(plain(o)) for s,p,o in triples if s in ontologies and p == OWL + 'versionInfo'}),
                'imports': sorted({o for s,p,o in triples if p == OWL + 'imports' and isinstance(o,str)}),
            }
        return {'case': describe(self.case_triples), 'schema': describe(self.schema_triples),
                'reasoning': 'NAMED_CLASS_HIERARCHY_AND_EXPLICIT_INVERSE_PROPERTIES',
                'remote_imports_fetched': False}

    def _check_imports(self):
        loaded = set()
        for source in ('case','schema'):
            loaded.update(self.source_metadata[source]['ontologies'])
            loaded.update(self.source_metadata[source]['version_iris'])
        exceptions={OSDI.rstrip('#')+'/1.0'} if self.compatibility is not None else set()
        missing = sorted({x for source in ('case','schema') for x in self.source_metadata[source]['imports'] if x not in loaded and x not in exceptions})
        self.source_metadata['import_resolutions']=[{'source':source,'iri':target,'resolved_locally':target in loaded}
            for source in ('case','schema') for target in self.source_metadata[source]['imports']]
        if self.compatibility is not None:
            for resolution in self.source_metadata['import_resolutions']:
                if resolution['iri'] in exceptions:resolution['accepted_by_explicit_compatibility_profile']=COMPATIBILITY_PROFILE
        self.source_metadata['imports_status']='UNRESOLVED' if missing else 'EXPLICIT_COMPATIBILITY_PROFILE' if self.compatibility is not None else 'RESOLVED_OR_NONE'
        self.source_metadata['version_policy']=('EXPLICIT_AUDITED_COMPATIBILITY_PROFILE; ORIGINAL_IMPORT_PRESERVED'
            if self.compatibility is not None else 'EXACT_DECLARED_ONTOLOGY_OR_VERSION_IRI; NO_NAMESPACE_VERSION_REWRITE')
        if missing:
            raise OntologyError('Unresolved ontology import(s): '+', '.join(missing)+
                '. Supply matching declarations/dependencies locally; a different version is not interchangeable.')
        if self.source_metadata['case']['imports'] and self.compatibility is None:
            self.diagnostics.append({'severity':'notice','code':'IMPORTS_RESOLVED_LOCALLY',
                'imports':self.source_metadata['case']['imports'],
                'schema_version_iris':self.source_metadata['schema']['version_iris'],
                'message':'Import identifiers match supplied ontology declarations; no remote ontology was fetched.'})

    def _validate_explicit_compatibility(self):
        """Gate an opt-in execution profile; never rewrite the source RDF graph."""
        evidence=self.compatibility
        if evidence.get('profile')!=COMPATIBILITY_PROFILE or evidence.get('explicit_opt_in') is not True:
            raise OntologyError('Unknown or non-explicit version compatibility profile.')
        base=OSDI.rstrip('#');requested=osdi_import_identifiers(self.case_triples)
        if [x for x in requested if x!=base]!=[base+'/1.0']:
            raise OntologyError('Compatibility profile requires the exact declared OSDi 1.0 import and no other version.')
        target=osdi_version_declaration(self.schema_triples,'effective schema')
        if target['version']!='1.1' or target['version_iri']!=base+'/1.1':
            raise OntologyError('Compatibility profile requires an exact effective OSDi 1.1 schema.')
        native_path=Path(evidence.get('declared_schema_path',''))
        if not self.schema_path or not native_path.is_file():raise OntologyError('Compatibility profile requires both audited local schema files.')
        native_hash=hashlib.sha256(native_path.read_bytes()).hexdigest()
        target_hash=hashlib.sha256(Path(self.schema_path).read_bytes()).hexdigest()
        if native_hash!=AUDITED_SCHEMA_HASHES['1.0'] or target_hash!=AUDITED_SCHEMA_HASHES['1.1']:
            raise OntologyError('Compatibility profile schema hash differs from the audited native 1.0 / target 1.1 pair.')
        if osdi_version_declaration(self.case_triples,'case')['version'] not in (None,'1.0'):
            raise OntologyError('Compatibility profile conflicts with an embedded OSDi version declaration.')
        schema_types={s for s,p,o in self.schema_triples if p==RDF+'type' and o in (OWL+'Class',RDFS+'Class')}
        schema_properties={s for s,p,o in self.schema_triples if p==RDF+'type' and o in (OWL+'ObjectProperty',OWL+'DatatypeProperty',OWL+'AnnotationProperty',RDF+'Property')}
        schema_terms=schema_types|schema_properties
        tbox_predicates={RDFS+'subClassOf',RDFS+'subPropertyOf',RDFS+'domain',RDFS+'range',
                         OWL+'equivalentClass',OWL+'equivalentProperty',OWL+'inverseOf',OWL+'disjointWith',RDF+'type'}
        schema_triples=set(self.schema_triples)
        overrides=[(s,p) for s,p,o in self.case_triples if s in schema_terms and p in tbox_predicates and (s,p,o) not in schema_triples]
        if overrides:raise OntologyError('Compatibility profile cannot accept embedded overrides of canonical OSDi schema axioms: '+str(overrides[0]))
        models=self.models()
        if not models:raise OntologyError('Compatibility profile requires a modern Experiment/usesModel decision-tree signature.')
        scope=set()
        for model in models:
            experiments=self.subjects('usesModel',model)
            if len(experiments)!=1 or not self.is_a(experiments[0],'Experiment'):
                raise OntologyError('Compatibility profile requires one modern Experiment with usesModel for '+model)
            for prop in ('hasYear','hasTimeHorizon','hasDisutilityCombinationMethod'):
                if self.objects(model,prop):raise OntologyError('Compatibility profile rejects native 1.0 Model-owned settings: '+prop+' on '+model)
            scope|={model,experiments[0]}|set(self._reachable(self.members(model)))
        for subject,predicate,obj in self.case_triples:
            if predicate in {OSDI+p for p in LEGACY_1_0_PROPERTIES} and (subject in scope or obj in scope):
                raise OntologyError('Compatibility profile rejects connected native 1.0 semantics: '+predicate+' on '+subject)
        schema_subjects={s for s,_,_ in self.schema_triples}
        schema_direct_types=defaultdict(set);schema_parents=defaultdict(set)
        for subject,predicate,obj in self.schema_triples:
            if predicate==RDF+'type':schema_direct_types[subject].add(obj)
            elif predicate in (RDFS+'subClassOf',OWL+'equivalentClass') and isinstance(obj,str) and not obj.startswith('_:'):
                schema_parents[subject].add(obj)
                if predicate==OWL+'equivalentClass':schema_parents[obj].add(subject)
        def schema_has_type(value,expected):
            pending=list(schema_direct_types[value]);seen=set()
            while pending:
                cls=pending.pop()
                if cls==expected:return True
                if cls in seen:continue
                seen.add(cls);pending.extend(schema_parents[cls])
            return False
        role_types={'hasDataItemType':OSDI+'DataItemType','isValueOfAttribute':OSDI+'Attribute',
                    'hasCategory':'http://www.w3.org/2004/02/skos/core#Concept',
                    'hasExpressionLanguage':OSDI+'ExpressionLanguage'}
        for subject in sorted(scope):
            for prop in sorted(LEGACY_1_0_PROPERTIES):
                if self.objects(subject,prop):raise OntologyError('Compatibility profile rejects native 1.0 semantics: '+prop+' on '+subject)
            if self.is_a(subject,'ModifierParameter'):
                raise OntologyError('Compatibility profile rejects native 1.0 ModifierParameter semantics: '+subject)
            for prop in self.forward[self.canonical(subject)]:
                if prop.startswith(OSDI) and prop not in schema_properties:
                    raise OntologyError('Compatibility profile found an unknown target-1.1 OSDi property: '+prop)
            for cls in self.objects(subject,RDF+'type'):
                if isinstance(cls,str) and cls.startswith(OSDI) and cls not in schema_types:
                    raise OntologyError('Compatibility profile found an unknown target-1.1 OSDi class: '+cls)
            for role,expected_type in role_types.items():
                for value in self.objects(subject,role):
                    if not isinstance(value,str) or value not in schema_subjects:
                        raise OntologyError('Compatibility profile found an unknown target-1.1 vocabulary value for '+role+' on '+subject+': '+str(value))
                    if not schema_has_type(value,expected_type):
                        raise OntologyError('Compatibility profile found a wrong-role vocabulary value for '+role+' on '+subject+': '+value+' is not a schema-defined '+expected_type)
        evidence.update(status='GATE_PASSED',declared_version='1.0',effective_version='1.1',
            declared_schema_sha256=native_hash,effective_schema_sha256=target_hash,
            original_imports=list(self.source_metadata['case']['imports']),imports_rewritten=False,
            semantic_equivalence_claimed=False,
            gate_checks=['EXACT_DECLARED_1_0_IMPORT','AUDITED_SCHEMA_HASHES','MODERN_EXPERIMENT_MODEL_SIGNATURE',
                         'NO_NATIVE_MODEL_SETTINGS','NO_LEGACY_SCOPED_SEMANTICS','KNOWN_TARGET_VOCABULARY','KNOWN_VOCABULARY_ROLE_VALUES','SCHEMA_DEFINED_ROLE_RANGES','NO_CANONICAL_TBOX_OVERRIDES'],
            limitations=['Finite-profile structural checks are not an OWL semantic-equivalence proof.',
                         'The original declared 1.0 import remains unchanged; execution explicitly uses audited 1.1 semantics.',
                         'The AI plan must pass its independent evidence, formula and arithmetic controls.'])
        self.source_metadata['compatibility_profile']=evidence
        self.diagnostics.append({'severity':'warning','code':'EXPLICIT_VERSION_COMPATIBILITY',**evidence})

    def _check_schema_version(self):
        ontology_iri=OSDI.rstrip('#')
        schema=osdi_version_declaration(self.schema_triples,'supplied schema')
        case=osdi_version_declaration(self.case_triples,'case')
        imports=osdi_import_identifiers(self.case_triples)
        versioned=[x for x in imports if x!=ontology_iri]
        if len(versioned)>1:raise OntologyError('Ambiguous mixed OSDi version imports: '+', '.join(versioned))
        if schema['version'] and case['version'] and schema['version']!=case['version'] and self.compatibility is None:
            raise OntologyError('Case and schema declare a different version of OSDi; declarations are not rewritten.')
        if versioned and schema['version_iri']!=versioned[0] and self.compatibility is None:
            raise OntologyError('Case imports a different version of OSDi than the supplied schema; exact versionIRI required.')
        version=schema['version']
        self.source_metadata['compiler_schema_baseline']='1.1'
        self.source_metadata['compiler_schema_supported_versions']=['1.0','1.1']
        self.source_metadata['compiler_schema_version']=version
        self.source_metadata['schema_version_supported']=version in self.source_metadata['compiler_schema_supported_versions']
        self.source_metadata['schema_version_matches_baseline']=version=='1.1' if version else None
        self.source_metadata['osdi_version_declaration']=schema
        if version=='1.0':
            self.diagnostics.append({'severity':'notice','code':'NATIVE_SCHEMA_PROFILE_1_0',
                'version':'1.0','message':'The native 1.0 finite-tree subset uses Model settings. Legacy modifiers, direct mortality/life effects and specialized detection costs require separate compilation and remain blocking.'})
        if version and not self.source_metadata['schema_version_supported']:
            self.diagnostics.append({'severity':'warning','code':'SCHEMA_VERSION_NOT_BASELINE',
                'versions':[version],'baseline':'1.1',
                'message':'Supplied schema is not an audited native compiler profile. No version migration is performed; successful parsing is not semantic compatibility.'})

    def _detect_constant_aliases(self):
        """Resolve only OSDi vocabulary constants with punctuation-only spelling.

        This explicit compatibility convention is recorded, never an OWL sameAs
        inference. Any local data on the short spelling disables auto-aliasing.
        """
        constants = defaultdict(list)
        for s in sorted(self.forward):
            if s.startswith(OSDI) and local(s).startswith("Constant_") and self.forward[s].get(OSDI + "hasExpectedValue"):
                constants[local(s).replace("_", "")].append(s)
        for s in sorted(self.forward):
            if not s.startswith(OSDI) or not local(s).startswith("Constant") or "_" in local(s): continue
            candidates = constants.get(local(s), [])
            substantive = {p: v for p, v in self.forward[s].items() if p not in (RDF + "type", RDFS + "label", RDFS + "comment")}
            if not substantive and len(candidates) == 1:
                self.aliases.setdefault(s, candidates[0])
                self.diagnostics.append({"severity": "warning", "code": "VOCABULARY_ALIAS", "subject": s, "canonical": candidates[0], "message": "Explicit compatibility alias; source has no owl:sameAs assertion."})

    def canonical(self, s):
        s = iri(s)
        seen = set()
        while s in self.aliases:
            if s in seen: raise OntologyError("Cyclic alias configuration")
            seen.add(s); s = self.aliases[s]
        return s

    def objects(self, subject, predicate, *, canonical=True):
        subject, predicate = iri(subject), iri(predicate)
        key = self.canonical(subject) if canonical else subject
        vals = set(self.forward[key].get(predicate, set()))
        if key != subject: vals |= self.forward[subject].get(predicate, set())
        for inverse in self._inverse_properties.get(predicate, ()):
            vals |= self.backward[inverse].get(key, set())
            if key != subject: vals |= self.backward[inverse].get(subject, set())
        if canonical: vals = {self.canonical(x) if isinstance(x, str) else x for x in vals}
        return sorted(vals, key=sort_key)

    def subjects(self, predicate=None, obj=None):
        if predicate is None: return sorted(self.forward)
        predicate = iri(predicate)
        if obj is None:
            out={s for vals in self.backward[predicate].values() for s in vals}
            for inverse in self._inverse_properties.get(predicate, ()):
                out.update(x for s in self.forward for x in self.forward[s].get(inverse,()) if isinstance(x,str))
            return sorted(out)
        obj = iri(obj) if isinstance(obj, str) else obj
        target = self.canonical(obj) if isinstance(obj, str) else obj
        out={s for x, vals in self.backward[predicate].items() if (self.canonical(x) if isinstance(x,str) else x) == target for s in vals}
        for inverse in self._inverse_properties.get(predicate, ()):
            for candidate in (target,obj):
                out.update(x for x in self.forward[candidate].get(inverse,()) if isinstance(x,str))
        return sorted(out)

    def one(self, subject, predicate, default=None, *, required=False):
        values = self.objects(subject, predicate)
        if len(values) > 1: raise OntologyError(f"Expected one {local(predicate)} for {subject}, got {len(values)}")
        if not values:
            if required: raise OntologyError(f"Missing {local(predicate)} for {subject}")
            return default
        return values[0]

    def value(self, subject, predicate, default=None, *, required=False):
        return plain(self.one(subject, predicate, default, required=required))

    def text_values(self, subject, predicate):
        """Preserve all descriptive alternatives, with their RDF language tags."""
        result=[]
        for value in self.objects(subject,predicate):
            if isinstance(value,Literal):
                result.append({'value':value.lexical,'language':value.language,'datatype':value.datatype})
            else:
                result.append({'value':str(value),'language':None,'datatype':None,'term_kind':'IRI'})
        return sorted(result,key=lambda v:(v['language'] or '',v['value'],v['datatype'] or ''))

    def text(self, subject, predicate, language='en', default=''):
        """Choose descriptive text only; numerical cardinality remains strict.

        Default preference: English, untagged, Spanish, other language tags in
        lexical order. A different language argument explicitly changes the
        first preference. Multiple different values in one language are invalid.
        """
        alternatives=self.text_values(subject,predicate)
        by_language=defaultdict(set)
        for value in alternatives:by_language[value['language'] or ''].add(value['value'])
        for tag,values in by_language.items():
            if len(values)>1:
                raise OntologyError(f'Multiple distinct descriptive values for {local(predicate)} in language {tag or "untagged"} on {subject}')
        preferred=(language or '').lower()
        order=list(dict.fromkeys([preferred,'','en','es']+sorted(by_language)))
        for tag in order:
            if by_language.get(tag):return next(iter(by_language[tag]))
        return default

    def ancestors(self, cls):
        cls = iri(cls)
        if cls in self._class_cache: return self._class_cache[cls]
        result, todo = {cls}, [cls]
        while todo:
            node = todo.pop()
            parents = self.objects(node, RDFS + "subClassOf", canonical=False)
            parents += self.objects(node, OWL + "equivalentClass", canonical=False)
            parents += self.subjects(OWL + "equivalentClass", node)
            for parent in parents:
                if isinstance(parent, str) and not parent.startswith("_:") and parent not in result:
                    result.add(parent); todo.append(parent)
        self._class_cache[cls] = result
        return result

    def types(self, subject, *, inferred=True, local_names=False):
        direct = {x for x in self.objects(subject, RDF + "type") if isinstance(x, str)}
        types = set().union(*(self.ancestors(c) for c in direct)) if inferred and direct else direct
        # Compact only the compiler vocabulary; preserve foreign IRIs so a
        # class named ex:Cost cannot masquerade as osdi:Cost. Explicit custom
        # subclasses still contribute their canonical OSDi ancestors above.
        return {local(x) if x.startswith(OSDI) or x==OWL+'NamedIndividual' else x for x in types} if local_names else types

    def is_a(self, subject, cls): return iri(cls) in self.types(subject)

    def rdf_list(self, head):
        result, seen = [], set()
        while head != RDF + "nil":
            if head in seen: raise OntologyError("Cyclic RDF list")
            seen.add(head)
            result.append(self.one(head, RDF + "first", required=True))
            head = self.one(head, RDF + "rest", required=True)
        return result

    def models(self):
        case_subjects = {s for s, _, _ in self.case_triples}
        return sorted(s for s in case_subjects if self.is_a(s, "DecisionTreeModel"))

    def members(self, model):
        model = self.resolve_model(model)
        # Membership reuse is directional. Walk the finite graph rather than
        # recursively expanding it: cycles add no new items and cannot hang.
        result, seen, pending, adjacency = set(), set(), [model], {}
        while pending:
            current=pending.pop()
            if current in seen: continue
            seen.add(current)
            result.update(self.objects(current,'includesModelItem'))
            result.update(self.subjects('includedByModel',current))
            reused=self.objects(current,'usesSameModelItemsAs')
            if any(not isinstance(x,str) or x.startswith('_:') for x in reused):
                raise OntologyError('Model reuse requires named model IRIs: '+str(current))
            for target in reused:
                if not self.is_a(target,'Model') and not self.is_a(target,'DecisionTreeModel'):
                    raise OntologyError('Unresolved/non-model usesSameModelItemsAs target: '+target)
            adjacency[current]=reused
            pending.extend(reused)
        # Kahn elimination detects directed cycles without recursion limits.
        degree={n:0 for n in seen}
        for targets in adjacency.values():
            for target in targets: degree[target]+=1
        ready=[n for n,d in degree.items() if d==0]
        removed=0
        while ready:
            node=ready.pop();removed+=1
            for target in adjacency[node]:
                degree[target]-=1
                if degree[target]==0:ready.append(target)
        if removed<len(seen) and not any(d.get('code')=='MODEL_MEMBERSHIP_CYCLE' and d.get('subject')==model for d in self.diagnostics):
            self.diagnostics.append({'severity':'warning','code':'MODEL_MEMBERSHIP_CYCLE','subject':model,
                'message':'Cyclic usesSameModelItemsAs links resolved as a finite union of explicitly declared members.'})
        if len(seen)>1 and not any(d.get('code')=='MODEL_MEMBERSHIP_REUSE' and d.get('subject')==model for d in self.diagnostics):
            self.diagnostics.append({'severity':'notice','code':'MODEL_MEMBERSHIP_REUSE','subject':model,
                'models':sorted(seen),'message':'Membership includes explicitly reused model items; experiment settings and roles are not inherited.'})
        return sorted(result)

    def resolve_model(self, model):
        matches = [m for m in self.models() if m == model or local(m) == model]
        if len(matches) != 1: raise OntologyError(f"Model selector {model!r} matches {len(matches)} models")
        return matches[0]

    def properties(self, subject):
        return {local(p): [plain(x) for x in self.objects(subject,p)] for p in sorted(self.forward[self.canonical(subject)])}

    def _reachable(self, members):
        # Follow functional model relationships, not membership links back into
        # other models. Inverse assertions are resolved by objects(). Unknown
        # constructs remain data for the compiler's explicit support checks.
        links = {"hasCost","hasUtility","hasAge","hasSex","hasLifeExpectancy","hasRiskCharacterization","hasEpidemiologicalParameter","hasSensitivity","hasSpecificity","hasTemporaryThreshold","hasOnsetAge","hasEndAge","hasDuration","hasEffect","hasEffectMagnitude","hasUncertaintyCharacterization","hasProgressionElement","affectsProgressionElement","hasIntervention","hasDiagnosisStrategy","hasTreatmentStrategy","hasFollowUpStrategy",
            "hasStrategy","usesHealthTechnology","hasGuideline","hasSubGuideline","hasDose","hasFrequency",
            "hasConditionExpression","hasSubProgression","hasNext","hasPrevious","hasFirst","requires",
            "dependsOnAttribute","dependsOnParameter","hasParameter","hasInitialProportion","hasProportionWithinGroup",
            "usesAttributeValue","affects","supersedesClinicalProgression","followedByStrategy","followsStrategy",
            "hasGroupItem","hasSubpopulation"}
        out, todo = set(members), list(members)
        while todo:
            node = todo.pop()
            for prop in links:
                for target in self.objects(node, prop):
                    if isinstance(target,str) and target not in out: out.add(target); todo.append(target)
        return out

    def parameter(self, subject):
        subject = self.canonical(subject)
        types = self.types(subject, local_names=True)
        canonical_types=self.types(subject)
        expected = self.value(subject, "hasExpectedValue")
        data_types = self.objects(subject, "hasDataItemType")
        is_disutility = self.value(subject,"isDisutility",False)
        if not isinstance(is_disutility,bool):raise OntologyError('isDisutility must be an XSD boolean: '+subject)
        if {iri('Cost'),iri('Utility')}<=canonical_types:raise OntologyError('Conflicting Cost/Utility types: '+subject)
        if iri("Cost") in canonical_types: group = "COST"
        elif iri("Utility") in canonical_types: group = "DISUTILITY" if is_disutility else "UTILITY"
        elif self.objects(subject,"isValueOfAttribute") or iri("AttributeValueParameter") in canonical_types: group = "ATTRIBUTE"
        elif iri("EpidemiologicalParameter") in canonical_types or self.subjects("hasRiskCharacterization",subject) or self.subjects("hasEpidemiologicalParameter",subject) or any(t in {iri(x) for x in ("DI_Probability","DI_Incidence","DI_Prevalence","DI_Proportion")} for t in data_types): group = "RISK"
        else: group = "UNKNOWN"
        natures={iri(x) for x in ('SecondOrderUncertaintyParameter','FirstOrderUncertaintyParameter','CalculatedParameter','DeterministicParameter')}&canonical_types
        if len(natures)>1:raise OntologyError('Conflicting parameter natures: '+subject)
        if iri("SecondOrderUncertaintyParameter") in canonical_types: uncertainty = "SECOND_ORDER"
        elif iri("FirstOrderUncertaintyParameter") in canonical_types: uncertainty = "FIRST_ORDER"
        elif iri("CalculatedParameter") in canonical_types: uncertainty = "CALCULATED"
        elif iri("DeterministicParameter") in canonical_types: uncertainty = "DETERMINISTIC"
        else: uncertainty = "UNKNOWN"
        distribution = None
        unc = self.objects(subject,"hasUncertaintyCharacterization")
        if len(unc)==1:
            raw_types = self.types(unc[0],inferred=False,local_names=True)
            kinds = sorted(t[:-len("DistributionExpression")].upper() for t in raw_types if t.endswith("DistributionExpression") and t!="ProbabilityDistributionExpression")
            distribution={"iri":unc[0],"kind":kinds[0] if len(kinds)==1 else None,"parameters":{local(p):plain(self.one(unc[0],p)) for p in sorted(self.forward[unc[0]]) if p.startswith(OSDI) and len(self.objects(unc[0],p))==1 and isinstance(self.one(unc[0],p),Literal)}}
        return {"iri":subject,"id":local(subject),"types":sorted(types),"group":group,"uncertainty":uncertainty,"expected":expected,"distribution":distribution,"uncertainty_nodes":unc,"year":self.value(subject,"hasYear"),"description":self.text(subject,"hasDescription"),"source":self.text(subject,"hasSource",default="Unknown"),"text_values":{"hasDescription":self.text_values(subject,"hasDescription"),"hasSource":self.text_values(subject,"hasSource")},"data_item_types":data_types,"one_time":self.value(subject,"appliesOneTime"),"is_disutility":is_disutility,"attributes":self.objects(subject,"isValueOfAttribute"),"aliases":sorted(k for k,v in self.aliases.items() if v==subject)}

    def describe_model(self, model):
        model = self.resolve_model(model)
        members = self.members(model)
        reach = self._reachable(members)
        params = sorted(s for s in reach if self.objects(s,"hasExpectedValue") or self.is_a(s,"Parameter"))
        entities = {s:{"iri":s,"id":local(s),"types":sorted(self.types(s,local_names=True)),"properties":self.properties(s)} for s in sorted(reach) if s not in params}
        populations = [s for s in members if self.is_a(s,"Population")]
        diseases = [s for s in members if self.is_a(s,"Disease")]
        interventions = [s for s in reach if self.is_a(s,"Intervention")]
        experiments = self.subjects("usesModel",model)
        diagnostics = list(self.diagnostics)
        if len(populations)!=1: diagnostics.append({"severity":"error","code":"POPULATION_COUNT","message":f"Expected one in-scope population, found {len(populations)}."})
        if len(diseases)!=1: diagnostics.append({"severity":"error","code":"DISEASE_COUNT","message":f"This tree profile supports one disease, found {len(diseases)}."})
        if len(experiments)>1: diagnostics.append({"severity":"error","code":"EXPERIMENT_SELECTION","message":"More than one experiment; select explicitly before generation."})
        for parameter in params:
            par=self.parameter(parameter)
            if par['expected'] is None and par['uncertainty']!='CALCULATED': diagnostics.append({"severity":"error","code":"MISSING_EXPECTED_VALUE","subject":parameter,"message":"No expected value; must not substitute zero."})
            if par['uncertainty'] in ('FIRST_ORDER','CALCULATED'): diagnostics.append({"severity":"error","code":"UNSUPPORTED_PARAMETER_MODE","subject":parameter,"message":f"Requires an explicit compiler for {par['uncertainty']}."})
        imports=sorted({o for _,p,o in self.case_triples if p==OWL+'imports' and isinstance(o,str)})
        return {"iri":model,"id":local(model),"description":self.text(model,"hasDescription"),"text_values":{"hasDescription":self.text_values(model,"hasDescription")},"members":members,"parameters":[self.parameter(s) for s in params],"entities":entities,"populations":populations,"diseases":diseases,"interventions":sorted(interventions),"experiments":[{"iri":s,**self.properties(s)} for s in experiments],"imports":imports,"source_metadata":self.source_metadata,"aliases":self.aliases,"diagnostics":diagnostics}


def load_dataset(case_ttl, schema_ttl=None, aliases=None, compatibility=None):
    return Dataset(case_ttl, schema_ttl, aliases, compatibility)


if __name__ == '__main__':
    import argparse, json
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('case'); parser.add_argument('--schema'); parser.add_argument('--model')
    args=parser.parse_args()
    graph=load_dataset(args.case,args.schema)
    result=graph.describe_model(args.model) if args.model else {'models':graph.models(),'case_triples':len(graph.case_triples),'schema_triples':len(graph.schema_triples),'diagnostics':graph.diagnostics}
    print(json.dumps(result,ensure_ascii=False,indent=2))
