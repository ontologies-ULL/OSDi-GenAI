"""Mechanical rendering of an explicit, AI-authored decision-tree plan.

This module deliberately has no RDF/OSDi input and no ontology dependency. It
never chooses interventions, builds clinical branches, or derives a payoff.
Those decisions and expressions must already exist in the supplied plan.
The retained workbook layout is the 2.2 presentation contract.
"""
from copy import deepcopy
from dataclasses import dataclass, field
import ast
import math
import re

from ooxml import col_letter as col


class PlanRenderError(ValueError):
    """The explicit plan cannot be represented by the workbook contract."""


@dataclass
class Edge:
    label: str
    probability: str
    node_id: str
    active: tuple = ()
    children: list = field(default_factory=list)
    state: dict = field(default_factory=dict)
    payoffs: dict = field(default_factory=dict)
    evidence: list = field(default_factory=list)
    residual: bool = False
    row: int = 0
    column: int = 0


def finite_number(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise PlanRenderError(label + ' must be a finite number.')
    return value


def _text(value, label, *, allow_empty=False):
    if not isinstance(value, str) or (not allow_empty and not value.strip()):
        raise PlanRenderError(label + ' must be text' + ('.' if allow_empty else ' and nonempty.'))
    return value


def canonical_formula(formula):
    """Normalize spelling of the plan's restricted arithmetic without inference.

    This changes whitespace and removes singleton SUM/PRODUCT wrappers only.
    It retains the expression's operand order and grouping; it does not choose
    any clinical operation, replace a parameter, or inspect its value/source.
    The caller's source/allowed-name validator remains mandatory.
    """
    _text(formula, 'formula')
    if len(formula) > 8192 or '**' in formula:
        raise PlanRenderError('Formula is too long or uses unsupported ** syntax.')
    pattern = re.compile(r'\s+|\{life\}|(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?|[A-Za-z_][A-Za-z0-9_.]*|[()+\-*/^,]')
    parts, original_names = [], {}
    position = 0
    while position < len(formula):
        match = pattern.match(formula, position)
        if match is None:
            raise PlanRenderError('Unsupported formula token at character ' + str(position))
        token = match.group()
        position = match.end()
        if token.isspace():
            continue
        if token == '{life}' or re.fullmatch(r'[A-Za-z_][A-Za-z0-9_.]*', token):
            symbol = 'v_' + str(len(original_names))
            original_names[symbol] = token
            parts.append(symbol)
        else:
            parts.append('**' if token == '^' else token)
    try:
        expression = ast.parse(' '.join(parts), mode='eval').body
    except (SyntaxError, ValueError, RecursionError) as exc:
        raise PlanRenderError('Invalid restricted arithmetic formula.') from exc
    functions = {'SUM', 'PRODUCT', 'MIN', 'MAX', 'PV'}
    operators = {ast.Add: ('+', 10), ast.Sub: ('-', 10),
                 ast.Mult: ('*', 20), ast.Div: ('/', 20), ast.Pow: ('^', 40)}

    def render(node):
        if isinstance(node, ast.Name) and node.id in original_names:
            return original_names[node.id], 100
        if isinstance(node, ast.Constant) and type(node.value) in (int, float):
            finite_number(node.value, 'formula literal')
            value = str(int(node.value)) if node.value == int(node.value) else repr(node.value)
            return value, 100
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and not node.keywords:
            function = original_names.get(node.func.id, '')
            if function not in functions or not node.args or (function == 'PV' and len(node.args) != 3):
                raise PlanRenderError('Unsupported function or arity in formula: ' + function)
            if function in {'SUM', 'PRODUCT'} and len(node.args) == 1:
                return render(node.args[0])
            separator = ',' if function == 'PV' else ', '
            return function + '(' + separator.join(render(arg)[0] for arg in node.args) + ')', 100
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
            text, precedence = render(node.operand)
            # Explicit parentheses also avoid Excel/Python unary-power
            # precedence differences when an exponent is negated as a whole.
            if precedence <= 40:
                text = '(' + text + ')'
            return ('+' if isinstance(node.op, ast.UAdd) else '-') + text, 30
        if isinstance(node, ast.BinOp) and type(node.op) in operators:
            operator, precedence = operators[type(node.op)]
            left, left_precedence = render(node.left)
            right, right_precedence = render(node.right)
            if left_precedence < precedence or operator == '^' and left_precedence == precedence:
                left = '(' + left + ')'
            if right_precedence < precedence or right_precedence == precedence:
                right = '(' + right + ')'
            return left + ' ' + operator + ' ' + right, precedence
        raise PlanRenderError('Unsupported expression in restricted arithmetic formula.')

    try:
        return render(expression)[0]
    except RecursionError as exc:
        raise PlanRenderError('Formula nesting exceeds the supported bound.') from exc


def _parameters(parameters):
    """Serialize explicit parameter records into the established column layout."""
    if not isinstance(parameters, list):
        raise PlanRenderError('parameters must be an explicit list.')
    cells, names, seen_iris = {}, {}, set()
    groups = {'ATTRIBUTE', 'RISK', 'COST', 'UTILITY', 'DISUTILITY', 'UNKNOWN'}
    seen_names = set()
    for row, parameter in enumerate(parameters, 7):
        if not isinstance(parameter, dict):
            raise PlanRenderError('Every parameter must be an object.')
        p = parameter
        for key in ('iri', 'id', 'name', 'group', 'uncertainty', 'expected', 'year', 'description', 'source', 'distribution'):
            if key not in p:
                raise PlanRenderError('Missing explicit parameter field: ' + key)
        parameter_iri = _text(p['iri'], 'parameter iri')
        name = _text(p['name'], 'parameter name')
        if parameter_iri in seen_iris or name.casefold() in seen_names:
            raise PlanRenderError('Duplicate parameter IRI or Excel name: ' + name)
        if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_.]*', name) or len(name) > 255:
            raise PlanRenderError('Unsupported explicit Excel name: ' + name)
        if re.fullmatch(r'[A-Za-z]{1,3}[1-9][0-9]*', name) or re.fullmatch(r'R[0-9]*C[0-9]*', name, re.I) or name.upper() in {'R', 'C'}:
            raise PlanRenderError('Excel name conflicts with cell addressing: ' + name)
        seen_iris.add(parameter_iri)
        seen_names.add(name.casefold())
        if p['group'] not in groups:
            raise PlanRenderError('Unknown parameter group: ' + str(p['group']))
        finite_number(p['expected'], 'expected value of ' + name)
        _text(p['description'], 'parameter description', allow_empty=True)
        _text(p['source'], 'parameter source', allow_empty=True)
        if p['year'] is not None:
            finite_number(p['year'], 'parameter year')
            if int(p['year']) != p['year']:
                raise PlanRenderError('Parameter year must be integral.')

        def put(column, value=None, formula=None):
            cell = {'value': value} if formula is None else {'formula': formula}
            cell.update(parameter_group=p['group'], uncertainty=p['uncertainty'])
            cells[column + str(row)] = cell

        put('B', name)
        put('C', p['group'])
        put('D', p['uncertainty'])
        put('H', float(p['expected']))
        put('O', p['description'])
        put('P', p['source'])
        if p['year'] is not None:
            put('N', float(p['year']))
        active = 'H' + str(row)
        if p['uncertainty'] == 'SECOND_ORDER':
            dist = p['distribution']
            if not isinstance(dist, dict) or not isinstance(dist.get('parameters'), dict):
                raise PlanRenderError('Explicit second-order distribution missing: ' + name)
            kind, dp = dist.get('kind'), dist['parameters']
            put('J', kind)
            for transform, identity in [('hasScaleParameter', 1), ('hasOffsetParameter', 0)]:
                if transform in dp:
                    finite_number(dp[transform], transform)
                    if dp[transform] != identity:
                        raise PlanRenderError('Unsupported non-identity distribution transform: ' + transform)
            if kind == 'BETA':
                a, b = dp.get('hasAlfaParameter'), dp.get('hasBetaParameter')
                draw = f'_xlfn.BETA.INV(RAND(),K{row},L{row})'
            elif kind == 'GAMMA':
                a, b = dp.get('hasAlfaParameter'), dp.get('hasLambdaParameter')
                draw = f'_xlfn.GAMMA.INV(RAND(),K{row},L{row})'
            elif kind == 'UNIFORM':
                a, b = dp.get('hasLowerLimitParameter'), dp.get('hasUpperLimitParameter')
                draw = f'RAND() * (K{row} - L{row}) + L{row}'
            elif kind == 'NORMAL':
                a, b = dp.get('hasAverageParameter'), dp.get('hasStandardDeviationParameter')
                draw = f'_xlfn.NORM.INV(RAND(),K{row},L{row})'
            else:
                raise PlanRenderError('Unsupported distribution: ' + str(kind))
            finite_number(a, 'first distribution argument of ' + name)
            finite_number(b, 'second distribution argument of ' + name)
            if kind in {'BETA', 'GAMMA'} and (a <= 0 or b <= 0):
                raise PlanRenderError('Distribution arguments must be positive: ' + name)
            if kind == 'NORMAL' and b <= 0:
                raise PlanRenderError('Normal standard deviation must be positive: ' + name)
            if kind == 'UNIFORM' and a > b:
                raise PlanRenderError('Uniform lower bound exceeds upper bound: ' + name)
            put('K', float(a))
            put('L', float(b))
            put('G', formula=draw)
            active = f'IF(isProbabilistic=0,H{row},G{row})'
        elif p['uncertainty'] != 'DETERMINISTIC':
            raise PlanRenderError('Unsupported explicit uncertainty: ' + str(p['uncertainty']))
        elif p['distribution'] is not None:
            raise PlanRenderError('A deterministic parameter must not hide a distribution.')
        if p['group'] == 'COST':
            if p['year'] is None:
                raise PlanRenderError('Explicit cost year is required: ' + name)
            active += f'*ROUND(1000*VLOOKUP(studyYear,CPI,2,FALSE)/VLOOKUP(N{row},CPI,2,FALSE),0)/ 1000'
        put('F', formula=active)
        names[name] = "'Parameters'!$F$" + str(row)
    return cells, names


def render_plan(plan):
    """Return ``(compiled, parameter_cells, names)`` without deriving semantics.

    Input ordering is authoritative. The AI supplies complete branch topology,
    explicit parameter names and all four expressions for each terminal route.
    ``{life}`` is only a positional placeholder for the route's life cell.
    Formal/source/expression validation must precede this rendering operation.
    """
    if not isinstance(plan, dict) or plan.get('format') != 'osdi-ai-plan/1':
        raise PlanRenderError('Expected an explicit osdi-ai-plan/1 object.')
    _text(plan.get('model_iri'), 'model_iri')
    settings = plan.get('settings')
    if not isinstance(settings, dict):
        raise PlanRenderError('settings must be an explicit object.')
    for key, value in settings.items():
        _text(key, 'setting name')
        finite_number(value, 'setting ' + key)
    pcells, names = _parameters(plan.get('parameters'))
    interventions = plan.get('interventions')
    if not isinstance(interventions, list) or not interventions:
        raise PlanRenderError('At least one explicit intervention is required.')
    seen_ids, seen_interventions = set(), set()
    leaf_count, node_count, max_depth = 0, 0, 0

    def parse_nodes(nodes, level, ancestors):
        nonlocal leaf_count, node_count, max_depth
        if not isinstance(nodes, list) or not nodes:
            raise PlanRenderError('Each split requires an explicit nonempty list of nodes.')
        if level > 12:
            raise PlanRenderError('Tree exceeds the depth limit of 12.')
        max_depth = max(max_depth, level)
        result = []
        for index, node in enumerate(nodes):
            if not isinstance(node, dict):
                raise PlanRenderError('Every tree node must be an object.')
            if id(node) in ancestors:
                raise PlanRenderError('Cyclic node object in explicit plan.')
            node_id = _text(node.get('id'), 'node id')
            if node_id in seen_ids:
                raise PlanRenderError('Duplicate node id: ' + node_id)
            seen_ids.add(node_id)
            node_count += 1
            if node_count > 250000:
                raise PlanRenderError('Tree exceeds the explicit resource bound of 250000 nodes.')
            residual = node.get('residual', False)
            if not isinstance(residual, bool):
                raise PlanRenderError('residual must be a JSON boolean.')
            if residual:
                if index != len(nodes) - 1 or index == 0:
                    raise PlanRenderError('A residual must follow explicit siblings and be last.')
                if node.get('probability') not in (None, ''):
                    raise PlanRenderError('Residual and explicit probability are mutually exclusive.')
                probability = ''
            else:
                probability = canonical_formula(_text(node.get('probability'), 'node probability'))
            children = node.get('children', [])
            if not isinstance(children, list):
                raise PlanRenderError('children must be a list.')
            has_children = bool(children)
            if has_children == ('payoffs' in node):
                raise PlanRenderError('A node requires children or terminal payoffs, exclusively.')
            active = node.get('active_progressions', [])
            if not isinstance(active, list) or not all(isinstance(x, str) for x in active):
                raise PlanRenderError('active_progressions must be a list of identifiers.')
            state = node.get('state', {})
            evidence = node.get('evidence', [])
            if not isinstance(state, dict) or not isinstance(evidence, list):
                raise PlanRenderError('Invalid explicit state/evidence shape.')
            edge = Edge(_text(node.get('label'), 'node label'), probability, node_id,
                        active=tuple(active), state=deepcopy(state),
                        evidence=deepcopy(evidence), residual=residual)
            if has_children:
                edge.children = parse_nodes(children, level + 1, ancestors | {id(node)})
            else:
                leaf_count += 1
                if leaf_count > 20000:
                    raise PlanRenderError('Tree exceeds the leaf limit of 20000.')
                payoffs = node['payoffs']
                if not isinstance(payoffs, dict) or set(payoffs) != {'cost', 'le', 'qale', 'life'}:
                    raise PlanRenderError('Terminal payoffs require cost, le, qale and life expressions.')
                edge.payoffs = {key: canonical_formula(_text(value, 'payoff ' + key)) for key, value in payoffs.items()}
                if '{life}' in edge.payoffs['life']:
                    raise PlanRenderError('The life expression cannot reference its own cell.')
            result.append(edge)
        return result

    trees, labels = [], {}
    for intervention in interventions:
        if not isinstance(intervention, dict):
            raise PlanRenderError('Each intervention must be an object.')
        ident = _text(intervention.get('iri'), 'intervention iri')
        if ident in seen_interventions:
            raise PlanRenderError('Duplicate intervention: ' + ident)
        seen_interventions.add(ident)
        labels[ident] = _text(intervention.get('label'), 'intervention label')
        trees.append((ident, parse_nodes(intervention.get('children'), 1, set())))

    cells, edges, leaves, starts = {}, [], [], []
    output_col = 4 + 3 * (max_depth + 1)
    detail_col = output_col + 5
    le_col = detail_col + 4
    current = max(6, len(interventions) + 4)

    def visit(branches, parent_col, parent_row, path):
        nonlocal current
        sibling_probs = []
        for edge in branches:
            edge.row, edge.column = current, parent_col + 3
            if edge.residual:
                edge.probability = '1 - SUM(' + ', '.join(sibling_probs) + ')'
            probability_cell = '$' + col(edge.column) + '$' + str(edge.row + 1)
            sibling_probs.append(probability_cell)
            edges.append((edge, parent_col, parent_row))
            new_path = path + [probability_cell]
            if edge.children:
                visit(edge.children, edge.column, edge.row, new_path)
            else:
                leaves.append((edge, new_path))
                current += 3

    for ident, branches in trees:
        start = current
        visit(branches, 4, start, [])
        starts.append((ident, start, current - 3))

    def put(address, value=None, formula=None, role=None):
        cells[address] = {'value': value} if formula is None else {'formula': formula}
        if role:
            cells[address]['role'] = role

    headers = {'C2': ('IF(language=1,"Chequeo","CHECK")', 'header_check'),
               'D2': ('IF(language=1,"COSTE","COST")', 'header_cost'),
               'E2': ('unitLE', 'header_le'), 'F2': ('unitQALE', 'header_qale')}
    for address, (formula, role) in headers.items():
        put(address, formula=formula, role=role)
    for index, (ident, first, last) in enumerate(starts):
        row = 3 + index
        put('B' + str(row), labels[ident], role='summary_intervention')
        put('D' + str(first), labels[ident], role='branch_label')
        for offset, letter in enumerate(['C', 'D', 'E', 'F']):
            formula = 'SUM($' + col(output_col + offset) + '$' + str(first) + ':$' + col(output_col + offset) + '$' + str(last) + ')' + ('=1' if offset == 0 else '')
            put(letter + str(row), formula=formula,
                role=['summary_check', 'summary_cost', 'summary_le', 'summary_qale'][offset])
    put(col(detail_col) + '3', formula='IF(language=1,"DETALLE","DETAIL")', role='detail_header')
    for offset, formula in enumerate(['IF(language=1,"PROB.","PROBABILITY")', 'IF(language=1,"COSTE","COST")', 'unitLE', 'unitQALE']):
        put(col(output_col + offset) + '4', formula=formula,
            role=['header_probability', 'header_cost', 'header_le', 'header_qale'][offset])
    for offset, formula in enumerate(['IF(language=1,"COSTE","COST")', 'unitLE', 'unitQALE']):
        put(col(detail_col + offset) + '4', formula=formula,
            role=['header_cost', 'header_le', 'header_qale'][offset])
    put(col(le_col) + '4', formula='"Undiscounted "&unitLE', role='undiscounted_header')
    for edge, _, _ in edges:
        put(col(edge.column) + str(edge.row), edge.label, role='branch_label')
        put(col(edge.column) + str(edge.row + 1), formula=edge.probability, role='probability')
    for edge, path in leaves:
        row = str(edge.row)
        probability = path[0] if len(path) == 1 else 'PRODUCT(' + ', '.join(path) + ')'
        put(col(output_col) + row, formula=probability, role='payoff_probability')
        life_reference = 'Model!' + col(le_col) + row
        for offset, key in enumerate(['cost', 'le', 'qale']):
            formula = edge.payoffs[key].replace('{life}', life_reference)
            put(col(output_col + offset + 1) + row,
                formula='Model!' + col(output_col) + row + ' * Model!' + col(detail_col + offset) + row,
                role=['payoff_cost', 'payoff_le', 'payoff_qale'][offset])
            role = ['detail_cost', 'detail_le', 'detail_qale'][offset]
            if formula == '0':
                put(col(detail_col + offset) + row, 0.0, role=role)
            else:
                put(col(detail_col + offset) + row, formula=formula, role=role)
        put(col(le_col) + row, formula=edge.payoffs['life'], role='undiscounted_le')
    compiled = {'cells': cells, 'edges': edges, 'leaves': leaves, 'starts': starts,
                'depth': max_depth, 'output_col': output_col, 'detail_col': detail_col,
                'le_col': le_col, 'last_row': current - 2,
                'parameters': deepcopy(plan['parameters']), 'settings': deepcopy(settings),
                'diagnostics': deepcopy(plan.get('diagnostics', []))}
    return compiled, pcells, names
