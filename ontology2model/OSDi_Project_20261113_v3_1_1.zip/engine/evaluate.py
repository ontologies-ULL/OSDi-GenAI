"""Small deterministic evaluator for generated arithmetic, never workbook execution."""
import ast,math,re

class UnavailableValue(ValueError):pass

class Evaluator:
    def __init__(self,cells,names):self.cells=cells;self.names=names;self.cache={};self.stack=set()
    @staticmethod
    def flatten(xs):
        for x in xs:
            if isinstance(x,list):yield from Evaluator.flatten(x)
            else:yield x
    @staticmethod
    def pv(r,n,pmt):return -pmt*n if r==0 else -pmt*(1-(1+r)**(-n))/r
    def cell(self,c):
        c=c.replace('Model!','').replace('$','')
        if c in self.cache:return self.cache[c]
        if c in self.stack:raise UnavailableValue('Circular formula at '+c)
        entry=self.cells.get(c)
        if entry is None:return 0
        if 'formula' not in entry:return entry.get('value') or 0
        self.stack.add(c)
        try:value=self.formula(entry['formula']);self.cache[c]=value;return value
        finally:self.stack.remove(c)
    def formula(self,f):
        funcs={'SUM':lambda *x:sum(self.flatten(x)),'PRODUCT':lambda *x:math.prod(self.flatten(x)),'MIN':lambda *x:min(self.flatten(x)),'MAX':lambda *x:max(self.flatten(x)),'PV':self.pv}
        pattern=r'Model!\$?[A-Z]+\$?\d+|\$?[A-Z]+\$?\d+:\$?[A-Z]+\$?\d+|\$?[A-Z]+\$?\d+|[A-Za-z_][A-Za-z0-9_.]*'
        def replace(m):
            x=m[0]
            if x in funcs:return x
            if x in self.names:
                value=self.names[x]
                if not isinstance(value,(int,float)):raise UnavailableValue('Non-numeric/unavailable '+x)
                return repr(value)
            if ':' in x:
                c1,r1,c2,r2=re.fullmatch(r'\$?([A-Z]+)\$?(\d+):\$?([A-Z]+)\$?(\d+)',x).groups()
                if c1!=c2:raise UnavailableValue('Only single-column ranges supported')
                return repr([self.cell(c1+str(r)) for r in range(int(r1),int(r2)+1)])
            if re.fullmatch(r'(Model!)?\$?[A-Z]+\$?\d+',x):return repr(self.cell(x))
            raise UnavailableValue('No authorized numeric input for '+x)
        text=re.sub(pattern,replace,f).replace('^','**')
        tree=ast.parse(text,mode='eval')
        def walk(n):
            if isinstance(n,ast.Expression):return walk(n.body)
            if isinstance(n,ast.Constant) and isinstance(n.value,(int,float)):return n.value
            if isinstance(n,ast.List):return [walk(x) for x in n.elts]
            if isinstance(n,ast.UnaryOp) and isinstance(n.op,(ast.UAdd,ast.USub)):return walk(n.operand)*(1 if isinstance(n.op,ast.UAdd) else -1)
            if isinstance(n,ast.BinOp):
                a,b=walk(n.left),walk(n.right)
                for typ,fn in [(ast.Add,lambda:a+b),(ast.Sub,lambda:a-b),(ast.Mult,lambda:a*b),(ast.Div,lambda:a/b),(ast.Pow,lambda:a**b)]:
                    if isinstance(n.op,typ):return fn()
            if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in funcs and not n.keywords:return funcs[n.func.id](*(walk(x) for x in n.args))
            raise UnavailableValue('Unsupported generated arithmetic')
        return walk(tree)
