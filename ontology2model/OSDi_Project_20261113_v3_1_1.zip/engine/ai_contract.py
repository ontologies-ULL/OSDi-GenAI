"""Evidence checks for AI-authored plans. Never constructs a decision tree.

The context is a factual serialization of the input and selected schema. Passing
this contract proves syntax, source bindings and coverage accounting, not that an
AI's clinical interpretation is complete or that its authorship is authentic.
"""
from __future__ import annotations

import ast
import hashlib
import json
import math
import re
from pathlib import Path

from ontology import (Dataset, Literal, OSDI, RDF, RDFS, OWL,
                      LEGACY_1_0_PROPERTIES, local)
from schema_selection import select_schema
from semantic_guards import validate_semantic_structure


class PlanError(ValueError):
    pass


FORMAT = 'osdi-ai-plan/1'
SETTING_PREDICATES = {
    'studyYear': 'hasYear', 'timeHorizon': 'hasTimeHorizon',
    'discountCosts': 'hasDiscountForCosts', 'discountLE': 'hasDiscountForEffects',
    'discountQALE': 'hasDiscountForEffects',
}
GROUPS = {'ATTRIBUTE', 'RISK', 'COST', 'UTILITY', 'DISUTILITY', 'UNKNOWN'}
GROUP_ORDER = {name: index for index, name in enumerate(
    ('ATTRIBUTE', 'RISK', 'COST', 'UTILITY', 'DISUTILITY', 'UNKNOWN'))}
PARAMETER_SOURCE_TYPES = {OSDI + name for name in (
    'Parameter', 'DeterministicParameter', 'SecondOrderUncertaintyParameter',
    'FirstOrderUncertaintyParameter', 'CalculatedParameter')}
PROBABILITY_TYPES = {OSDI+x for x in ('DI_Probability', 'DI_Proportion',
    'DI_Prevalence', 'DI_Incidence', 'DI_Sensitivity', 'DI_Specificity', 'DI_BirthPrevalence')}
FUNCTION_ARITIES = {'SUM': (1, None), 'PRODUCT': (1, None),
                    'MIN': (1, None), 'MAX': (1, None), 'PV': (3, 3)}
UNSUPPORTED_TYPES = {
    'Pathway', 'ResourceUsageItem', 'Guideline', 'AtomicGuideline',
    'CompositeGuideline', 'SequentialCombinationRule',
    'SequentialDiseaseProgressionSet', 'CalculatedParameter',
    'FirstOrderUncertaintyParameter',
}
UNSUPPORTED_PROPERTIES = {
    'hasNext', 'hasPrevious', 'hasFirst', 'hasNextProgression', 'requires',
    'isRequiredBy', 'hasConditionExpression', 'isConditionExpressionOf',
    'dependsOn', 'dependsOnAttribute', 'hasSubProgression', 'failsIf',
    'causesFailOf', 'excludesDiseaseProgression', 'hasStrategy', 'isStrategyOf',
    'hasGuideline', 'isGuidelineOf', 'usesHealthTechnology',
    'hasDiagnosisStrategy', 'hasTreatmentStrategy', 'hasFollowUpStrategy',
    'followedByStrategy', 'followsStrategy', 'hasInitialProportion',
    'hasSubpopulation', 'hasDuration', 'hasAssessedIntervention',
    'hasComparatorIntervention', 'isAssessedInterventionOf',
    'isComparatorInterventionOf', 'hasCostCombinationMethod',
    'hasLifeExpectancyReductionCombinationMethod', 'hasMortalityRateCombinationMethod',
}


def _digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _object(term):
    if isinstance(term, Literal):
        return {'kind': 'literal', 'value': term.value, 'lexical': term.lexical,
                'datatype': term.datatype, 'language': term.language}
    return {'kind': 'iri', 'value': term}


def _facts(triples, prefix):
    rows = [{'subject': s, 'predicate': p, 'object': _object(o)} for s, p, o in set(triples)]
    rows.sort(key=lambda f: json.dumps(f, ensure_ascii=False, sort_keys=True))
    return [{'id': f'{prefix}{i:06d}', **f} for i, f in enumerate(rows, 1)]


def prepare_context(case, schema=None, compatibility_profile=None, package=None):
    """Read facts and vocabulary only; no routes, probabilities or payoffs inferred."""
    package = Path(package) if package else Path(__file__).resolve().parents[1]
    selected, selection = select_schema(case, schema, package, compatibility_profile)
    graph = Dataset(case, selected, compatibility=selection.get('compatibility_profile'))
    if graph.compatibility is not None:
        selection['compatibility_profile'] = graph.compatibility
    models = graph.models()
    classes = {s for s, p, o in graph.schema_triples
               if p == RDF + 'type' and o in (OWL + 'Class', RDFS + 'Class')}
    properties = {s for s, p, o in graph.schema_triples if p == RDF + 'type'
                  and o in (OWL + 'ObjectProperty', OWL + 'DatatypeProperty',
                            OWL + 'AnnotationProperty', RDF + 'Property')}
    tbox = {RDFS + 'subClassOf', RDFS + 'subPropertyOf', RDFS + 'domain',
            RDFS + 'range', OWL + 'equivalentClass', OWL + 'equivalentProperty',
            OWL + 'inverseOf', OWL + 'disjointWith', RDF + 'type'}
    schema_set = set(graph.schema_triples)
    for triple in graph.case_triples:
        if triple[0] in classes | properties and triple[1] in tbox and triple not in schema_set:
            raise PlanError('Case redefines a canonical schema axiom: ' + triple[0])
    scopes = {}
    members = {}
    settings_owners = {}
    for model in models:
        members[model] = sorted(graph.members(model))
        experiments = graph.subjects('usesModel', model)
        scopes[model] = sorted(set(graph._reachable(members[model])) | {model} | set(experiments))
        settings_owners[model] = [model] if selection['selected_version'] == '1.0' else experiments
    constant_subjects = {s for s, _, _ in graph.schema_triples
                         if s.startswith(OSDI) and local(s).startswith('Constant')}
    constants = [t for t in graph.schema_triples if t[0] in constant_subjects]
    subjects = {s for s, _, _ in graph.case_triples} | constant_subjects
    # Type closure is limited to the graph reader's named-class hierarchy.
    types = {s: sorted(graph.types(s)) for s in sorted(subjects)}
    schema_direct = {}; schema_parents = {}; inverses = {}
    for s, p, o in graph.schema_triples:
        if p == RDF+'type': schema_direct.setdefault(s, set()).add(o)
        elif p in (RDFS+'subClassOf', OWL+'equivalentClass') and isinstance(o,str) and not o.startswith('_:'):
            schema_parents.setdefault(s,set()).add(o)
            if p == OWL+'equivalentClass': schema_parents.setdefault(o,set()).add(s)
        elif p == OWL+'inverseOf' and isinstance(o,str):
            inverses.setdefault(s,set()).add(o); inverses.setdefault(o,set()).add(s)
    schema_individual_types = {}
    for subject, direct in schema_direct.items():
        if not subject.startswith(OSDI) or subject in classes | properties: continue
        pending=list(direct); closure=set()
        while pending:
            cls=pending.pop()
            if cls in closure: continue
            closure.add(cls); pending.extend(schema_parents.get(cls, ()))
        schema_individual_types[subject]=sorted(closure)
    result = {
        'format': 'osdi-ai-context/1', 'case_sha256': _digest(case),
        'schema_sha256': _digest(selected), 'schema_selection': selection,
        'case_path': str(Path(case).resolve()), 'schema_path': str(selected),
        'ttl_text': Path(case).read_text(encoding='utf-8-sig'),
        'model_candidates': models, 'model_members': members, 'model_scopes': scopes,
        'settings_owners': settings_owners, 'facts': _facts(graph.case_triples, 'f'),
        'schema_evidence': _facts(constants, 's'), 'types': types,
        'schema_classes': sorted(classes), 'schema_properties': sorted(properties),
        'schema_individual_types':schema_individual_types,
        'inverse_properties':{k:sorted(v) for k,v in inverses.items()},
        'effect_ancestor_types':sorted(graph.ancestors(OSDI+'Effect')|{OSDI+'Effect'}),
        'aliases': dict(graph.aliases), 'source_metadata': graph.source_metadata,
        'diagnostics': graph.diagnostics,
        'limitations': ['No decision tree or payoff is generated by context preparation.',
                       'Named-class and inverse-property inspection is not full OWL reasoning.'],
    }
    return result


def _number(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise PlanError(label + ' must be a finite numeric value.')
    return value


def _nonempty(value, label):
    if not isinstance(value, str) or not value.strip():
        raise PlanError(label + ' must be nonempty text.')
    return value


def _list(value, label, nonempty=False):
    if not isinstance(value, list) or (nonempty and not value):
        raise PlanError(label + ' must be ' + ('a nonempty ' if nonempty else 'a ') + 'list.')
    return value


def canonical_parameter_name(identifier):
    """Checkable display convention; never chooses parameters or changes a plan."""
    name = re.sub(r'[^A-Za-z0-9_.]', '_', identifier)
    if (not re.match(r'[A-Za-z_]', name) or name.upper() in {'R', 'C'}
            or re.fullmatch(r'[A-Za-z]{1,3}[1-9][0-9]*', name)
            or re.fullmatch(r'R[1-9][0-9]*C[1-9][0-9]*', name, re.I)):
        name = 'p_' + name
    if len(name) > 255:
        raise PlanError('Canonical parameter name exceeds 255 characters; no silent truncation is allowed.')
    return name


def check_expression(expression, names, allow_life=False):
    """Accept a small symbolic arithmetic grammar, never arbitrary Excel/code."""
    _nonempty(expression, 'Formula')
    if len(expression) > 8192:
        raise PlanError('Formula exceeds 8192 characters.')
    if '**' in expression:
        raise PlanError('Excel powers must use ^, not Python **.')
    if '{life}' in expression:
        if not allow_life:
            raise PlanError('{life} is only allowed in cost/le/qale payoff formulas.')
        expression = expression.replace('{life}', '__life_placeholder')
    allowed = set(names) | ({'__life_placeholder'} if allow_life else set())
    tokens = re.findall(r'[A-Za-z_][A-Za-z0-9_.]*|(?:\d+(?:\.\d*)?|\.\d+)|[+\-*/^(),]|\s+', expression)
    if ''.join(tokens) != expression:
        raise PlanError('Formula contains unsupported characters, cell/sheet references or syntax.')
    aliases = {n: f'v_{i}' for i, n in enumerate(sorted(allowed))}
    converted = []
    for token in tokens:
        if token.isspace():
            converted.append(token)
        elif token in FUNCTION_ARITIES:
            converted.append(token)
        elif token in aliases:
            converted.append(aliases[token])
        elif re.fullmatch(r'[A-Za-z_][A-Za-z0-9_.]*', token):
            raise PlanError('Unknown or unauthorized formula symbol: ' + token)
        elif re.fullmatch(r'(?:\d+(?:\.\d*)?|\.\d+)', token):
            if float(token) not in (0, 1):
                raise PlanError('Clinical numbers must reference evidenced parameters, not formula literals: ' + token)
            converted.append(token)
        else:
            converted.append('**' if token == '^' else token)
    try:
        tree = ast.parse(''.join(converted).strip(), mode='eval')
    except (SyntaxError, ValueError) as error:
        raise PlanError('Invalid arithmetic formula.') from error
    used = set()
    reverse = {v: k for k, v in aliases.items()}
    def visit(node):
        if isinstance(node, ast.Expression):
            visit(node.body)
        elif isinstance(node, ast.Constant) and type(node.value) in (int, float) and node.value in (0, 1):
            return
        elif isinstance(node, ast.Name) and node.id in reverse:
            used.add(reverse[node.id])
        elif isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
            if isinstance(node.operand, ast.BinOp) and isinstance(node.operand.op, ast.Pow):
                raise PlanError('Unary signs applied to powers are unsupported because Excel/Python precedence differs; express the signed base explicitly or use multiplication.')
            visit(node.operand)
        elif isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow)):
            if isinstance(node.op, ast.Pow) and any(isinstance(child, ast.BinOp) and isinstance(child.op, ast.Pow)
                                                   for part in (node.left, node.right) for child in ast.walk(part)):
                raise PlanError('Nested or chained powers are unsupported because Excel/Python associativity differs.')
            visit(node.left); visit(node.right)
        elif isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in FUNCTION_ARITIES and not node.keywords:
            minimum, maximum = FUNCTION_ARITIES[node.func.id]
            if len(node.args) < minimum or (maximum is not None and len(node.args) > maximum):
                raise PlanError('Wrong function arity for ' + node.func.id)
            for arg in node.args: visit(arg)
        else:
            raise PlanError('Unsupported arithmetic construct.')
    visit(tree)
    return used - {'__life_placeholder'}


def validate_plan(plan, context):
    """Validate an explicit plan without supplying or repairing its interpretation."""
    if not isinstance(plan, dict) or plan.get('format') != FORMAT:
        raise PlanError('An explicit osdi-ai-plan/1 plan is required.')
    if not isinstance(context, dict) or context.get('format') != 'osdi-ai-context/1':
        raise PlanError('A freshly prepared source context is required.')
    author = plan.get('authorship')
    if not isinstance(author, dict) or author.get('kind') != 'ai':
        raise PlanError('Plan must declare AI authorship; this declaration is not authentication.')
    for key in ('system', 'model'): _nonempty(author.get(key), 'authorship.' + key)
    source = plan.get('source', {})
    if not isinstance(source,dict): raise PlanError('source must be an object.')
    for key in ('case_sha256', 'schema_sha256'):
        if source.get(key) != context.get(key):
            raise PlanError('Plan is bound to a different ' + key + '.')
    model = plan.get('model_iri')
    if model not in context['model_candidates']:
        raise PlanError('Plan model is not a DecisionTreeModel candidate from this case.')
    if plan.get('blockers') != []:
        raise PlanError('Plan must explicitly declare blockers=[]; unresolved blockers forbid generation.')
    facts = {f['id']: f for f in context['facts'] + context.get('schema_evidence', [])}
    case_ids = {f['id'] for f in context['facts']}
    used = set()
    seen = set()
    scope = set(context['model_scopes'][model])
    annotation_predicates = {RDFS + 'label', RDFS + 'comment', OSDI + 'hasDescription', OSDI + 'hasSource'}
    for item in _list(plan.get('coverage'), 'coverage', True):
        if not isinstance(item, dict) or item.get('disposition') not in {'used', 'metadata', 'outside_model'}:
            raise PlanError('Invalid coverage disposition.')
        _nonempty(item.get('reason'), 'coverage.reason')
        for fid in _list(item.get('facts'), 'coverage.facts', True):
            if not isinstance(fid,str) or fid not in case_ids or fid in seen:
                raise PlanError('Unknown or duplicated case fact in coverage: ' + str(fid))
            seen.add(fid)
            fact = facts[fid]
            if item['disposition'] == 'outside_model' and fact['subject'] in scope:
                raise PlanError('A fact connected to this model cannot be marked outside_model: ' + fid)
            if item['disposition'] == 'metadata' and fact['subject'] in scope and fact['predicate'] not in annotation_predicates and not (fact['predicate'] == RDF+'type' and fact['object']['value'] == OWL+'NamedIndividual'):
                raise PlanError('A connected semantic fact cannot be classified as metadata: ' + fid)
            if item['disposition'] == 'used': used.add(fid)
    if seen != case_ids:
        raise PlanError('Coverage is incomplete: ' + str(len(case_ids - seen)) + ' case facts missing.')
    evidence_used = set()
    def evidence(ids, label, nonempty=True):
        for fid in _list(ids, label, nonempty):
            if not isinstance(fid,str) or fid not in facts or (fid in case_ids and fid not in used):
                raise PlanError('Evidence must cite a known used fact: ' + str(fid))
            evidence_used.add(fid)
    def literal_evidence(fid, subject, predicate, value, label):
        evidence([fid], label)
        fact = facts[fid]
        obj = fact['object']
        if fact['subject'] != subject or fact['predicate'] != OSDI + predicate or obj['kind'] != 'literal':
            raise PlanError(label + ' cites the wrong subject/predicate/literal.')
        if isinstance(value, bool) != isinstance(obj['value'], bool) or value != obj['value']:
            raise PlanError(label + ' does not match the source value.')
        competing = {json.dumps(f['object']['value'], sort_keys=True) for f in facts.values()
                     if f['subject'] == subject and f['predicate'] == OSDI+predicate}
        if len(competing) != 1:
            raise PlanError('Ambiguous source values for ' + predicate + ' on ' + subject)
    def matching(subject, predicate, value):
        return [f['id'] for f in facts.values() if f['subject'] == subject
                and f['predicate'] == predicate and f['object']['value'] == value]
    def relationship(subject,predicate,value):
        ids=matching(subject,predicate,value)
        for inverse in context.get('inverse_properties',{}).get(predicate,[]):
            ids+=matching(value,inverse,subject)
        return ids
    def data_types(subject):
        values={f['object']['value'] for f in facts.values()
                if f['subject']==subject and f['predicate']==OSDI+'hasDataItemType'}
        for value in values:
            if OSDI+'DataItemType' not in context.get('schema_individual_types',{}).get(value,[]):
                raise PlanError('Data item type is not an official schema-defined DataItemType: '+str(value))
        return values
    forbidden_types = set(UNSUPPORTED_TYPES)
    forbidden_properties = set(UNSUPPORTED_PROPERTIES)
    if context['schema_selection']['selected_version'] == '1.0':
        forbidden_types.add('ModifierParameter')
        forbidden_properties |= LEGACY_1_0_PROPERTIES
    for subject in scope:
        bad = set(context['types'].get(subject, [])) & {OSDI+x for x in forbidden_types}
        if bad: raise PlanError('Unsupported connected construction: ' + ', '.join(sorted(bad)))
    for fact in context['facts']:
        if fact['subject'] not in scope: continue
        predicate = fact['predicate']
        if predicate in {OSDI+x for x in ('appliesOneTime','isDisutility','isAssessedIntervention')}:
            if fact['object']['kind']!='literal' or type(fact['object']['value']) is not bool:
                raise PlanError('Source boolean must be a typed RDF boolean: '+fact['id'])
        if predicate in {OSDI+x for x in forbidden_properties}:
            raise PlanError('Unsupported connected semantics: ' + predicate)
        if predicate.startswith(OSDI) and predicate not in context['schema_properties']:
            raise PlanError('Unknown OSDi property for selected schema: ' + predicate)
        if predicate == RDF+'type' and fact['object']['kind'] == 'iri':
            cls = fact['object']['value']
            if cls.startswith(OSDI) and cls not in context['schema_classes']:
                raise PlanError('Unknown OSDi class for selected schema: ' + cls)
    members = context['model_members'][model]
    def canonical_subject(subject):
        aliases = context.get('aliases', {})
        visited = set()
        while subject in aliases:
            if subject in visited:
                raise PlanError('Cyclic source alias in context.')
            visited.add(subject)
            subject = aliases[subject]
        return subject
    member_parameters = {canonical_subject(subject) for subject in members
                         if PARAMETER_SOURCE_TYPES & (set(context['types'].get(subject, []))
                             | set(context['types'].get(canonical_subject(subject), [])))}
    for required_type in ('Disease', 'Population'):
        candidates = [s for s in members if OSDI+required_type in context['types'].get(s, [])]
        if len(candidates) != 1:
            raise PlanError('Finite-tree profile requires one included ' + required_type + '.')
    names = set(); parameter_iris = set(); canonical_parameter_iris = set()
    parameters = _list(plan.get('parameters'), 'parameters', True)
    for p in parameters:
        if not isinstance(p, dict): raise PlanError('Each parameter must be an object.')
        required_fields={'iri','id','name','group','uncertainty','expected','year','description','source','one_time','distribution','evidence','value_evidence'}
        if not required_fields <= set(p): raise PlanError('Missing parameter fields: '+', '.join(sorted(required_fields-set(p))))
        subject = _nonempty(p.get('iri'), 'parameter.iri')
        if subject in parameter_iris: raise PlanError('Duplicate parameter IRI: ' + subject)
        parameter_iris.add(subject)
        canonical_iri = canonical_subject(subject)
        if canonical_iri in canonical_parameter_iris:
            raise PlanError('Duplicate parameter through a canonical source alias: ' + subject)
        canonical_parameter_iris.add(canonical_iri)
        if subject not in scope and subject not in {f['subject'] for f in context.get('schema_evidence', [])}:
            raise PlanError('Parameter is not connected to the selected model: ' + subject)
        identifier = _nonempty(p.get('id'), 'parameter.id')
        if identifier != local(subject):
            raise PlanError('Parameter id must equal the local source identifier: ' + subject)
        name = _nonempty(p.get('name'), 'parameter.name')
        if name != canonical_parameter_name(identifier):
            raise PlanError('Parameter name must follow the canonical source-name convention: ' + identifier)
        if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_.]{0,254}', name) or re.fullmatch(r'[A-Za-z]{1,3}[1-9][0-9]*', name) or name.upper() in {'R', 'C'} | set(FUNCTION_ARITIES):
            raise PlanError('Invalid or ambiguous Excel parameter name: ' + name)
        reserved_names=set(SETTING_PREDICATES)|{'isProbabilistic','CPI','language','unitLE','unitQALE'}|set(FUNCTION_ARITIES)
        if name.casefold() in {n.casefold() for n in names|reserved_names}:
            raise PlanError('Duplicate or reserved parameter name: ' + name)
        names.add(name)
        if p.get('group') not in GROUPS: raise PlanError('Unknown parameter group.')
        value = _number(p.get('expected'), 'parameter.expected')
        evidence(p.get('evidence'), 'parameter.evidence')
        literal_evidence(p.get('value_evidence'), subject, 'hasExpectedValue', value, 'parameter.value_evidence')
        types = set(context['types'].get(subject, []))
        natures = types & {OSDI+x for x in ('DeterministicParameter', 'SecondOrderUncertaintyParameter', 'FirstOrderUncertaintyParameter', 'CalculatedParameter')}
        expected_type = {'DETERMINISTIC': 'DeterministicParameter', 'SECOND_ORDER': 'SecondOrderUncertaintyParameter'}.get(p.get('uncertainty'))
        if expected_type is None or natures != {OSDI+expected_type}:
            raise PlanError('Parameter uncertainty does not match its source type: ' + subject)
        if {OSDI+'Cost',OSDI+'Utility'} <= types: raise PlanError('Conflicting Cost/Utility source types.')
        if p['group'] == 'COST' and OSDI+'Cost' not in types:
            raise PlanError('COST group lacks the source Cost type.')
        if OSDI+'Cost' in types and p['group']!='COST': raise PlanError('Source Cost cannot be assigned a different parameter group.')
        if p['group'] in {'UTILITY','DISUTILITY'} and OSDI+'Utility' not in types:
            raise PlanError('Utility group lacks the source Utility type.')
        if OSDI+'Utility' in types:
            flags=[f['object']['value'] for f in facts.values() if f['subject']==subject and f['predicate']==OSDI+'isDisutility']
            if len(set(flags))>1 or any(type(flag) is not bool for flag in flags): raise PlanError('Ambiguous or untyped isDisutility.')
            expected_group='DISUTILITY' if flags and flags[0] else 'UTILITY'
            if p['group']!=expected_group: raise PlanError('Utility/disutility group does not match source flag.')
        is_attribute=OSDI+'AttributeValueParameter' in types or any(f['subject']==subject and f['predicate']==OSDI+'isValueOfAttribute' for f in facts.values())
        if is_attribute and OSDI+'Cost' not in types and OSDI+'Utility' not in types and p['group']!='ATTRIBUTE':
            raise PlanError('Source attribute value must retain ATTRIBUTE group.')
        declared_data_types=data_types(subject)
        if p.get('data_item_types') is not None and set(p['data_item_types'])!=declared_data_types:
            raise PlanError('Declared data_item_types differ from the source.')
        is_risk=(OSDI+'EpidemiologicalParameter' in types or
            any(f['object']['value']==subject and f['predicate'] in {OSDI+'hasRiskCharacterization',OSDI+'hasEpidemiologicalParameter'} for f in facts.values()) or
            bool(declared_data_types & {OSDI+x for x in ('DI_Probability','DI_Incidence','DI_Prevalence','DI_Proportion')}))
        if is_risk and not is_attribute and OSDI+'Cost' not in types and OSDI+'Utility' not in types and p['group']!='RISK':
            raise PlanError('Source risk parameter must retain RISK group.')
        if (OSDI+'Cost' not in types and OSDI+'Utility' not in types
                and not is_attribute and not is_risk and p['group'] != 'UNKNOWN'):
            raise PlanError('An unclassified source parameter must retain UNKNOWN group.')
        if p['group'] in {'COST', 'ATTRIBUTE', 'DISUTILITY'} and value < 0:
            raise PlanError('Negative cost/attribute/disutility is unsupported.')
        for text_key, predicate, fallback in [('description','hasDescription',''), ('source','hasSource','Unknown')]:
            text_value = p.get(text_key)
            if not isinstance(text_value, str): raise PlanError('parameter.' + text_key + ' must be text.')
            options = [f['object']['value'] for f in facts.values() if f['subject']==subject and f['predicate']==OSDI+predicate and f['object']['kind']=='literal']
            if text_value not in options and not (not options and text_value == fallback):
                raise PlanError('Parameter metadata not present in source: ' + text_key)
        if p.get('year') is not None:
            year = _number(p['year'], 'parameter.year')
            if year != int(year) or not -32768 <= year <= 32767: raise PlanError('Invalid xsd:short year.')
            literal_evidence(p.get('year_evidence'), subject, 'hasYear', year, 'parameter.year_evidence')
        if p.get('group') == 'COST':
            if p.get('year') is None or type(p.get('one_time')) is not bool:
                raise PlanError('Cost requires explicit source year and one_time boolean.')
            one_time_ids = matching(subject, OSDI+'appliesOneTime', p['one_time'])
            if not one_time_ids: raise PlanError('Cost frequency does not match source.')
            literal_evidence(p.get('one_time_evidence') or one_time_ids[0], subject, 'appliesOneTime', p['one_time'], 'parameter.one_time')
        dist = p.get('distribution')
        if expected_type == 'SecondOrderUncertaintyParameter':
            if not isinstance(dist, dict): raise PlanError('Second-order parameter requires an explicit distribution.')
            dist_iri = _nonempty(dist.get('iri'), 'distribution.iri')
            links = matching(subject, OSDI+'hasUncertaintyCharacterization', dist_iri)
            if not links: raise PlanError('Distribution is not linked to source parameter.')
            all_distributions={f['object']['value'] for f in facts.values() if f['subject']==subject and f['predicate']==OSDI+'hasUncertaintyCharacterization'}
            if all_distributions!={dist_iri}: raise PlanError('Ambiguous multiple source distributions.')
            evidence(links, 'distribution.link')
            kinds = {'BETA':('BetaDistributionExpression','hasAlfaParameter','hasBetaParameter'),
                     'GAMMA':('GammaDistributionExpression','hasAlfaParameter','hasLambdaParameter'),
                     'UNIFORM':('UniformDistributionExpression','hasLowerLimitParameter','hasUpperLimitParameter'),
                     'NORMAL':('NormalDistributionExpression','hasAverageParameter','hasStandardDeviationParameter')}
            kind = dist.get('kind')
            if kind not in kinds or OSDI+kinds[kind][0] not in context['types'].get(dist_iri, []):
                raise PlanError('Distribution kind does not match source.')
            if len(set(context['types'].get(dist_iri,[])) & {OSDI+x[0] for x in kinds.values()})!=1:
                raise PlanError('Conflicting distribution source kinds.')
            dp = dist.get('parameters', {}); de = p.get('distribution_evidence', {})
            if not isinstance(dp, dict) or not isinstance(de, dict): raise PlanError('Invalid distribution parameters/evidence.')
            required = set(kinds[kind][1:]); optional={'hasScaleParameter':1, 'hasOffsetParameter':0}
            if not required <= set(dp) or set(dp) - required - set(optional): raise PlanError('Invalid distribution parameter fields.')
            for prop, val in dp.items():
                _number(val, 'distribution.' + prop)
                literal_evidence(de.get(prop), dist_iri, prop, val, 'distribution_evidence.' + prop)
                if prop in optional and val != optional[prop]: raise PlanError('Nonidentity distribution transformations are unsupported.')
            for prop in optional:
                source_fields = [f for f in facts.values() if f['subject']==dist_iri and f['predicate']==OSDI+prop]
                if source_fields and prop not in dp: raise PlanError('Distribution transform was omitted: ' + prop)
            a,b=(dp[k] for k in kinds[kind][1:])
            if kind in {'BETA','GAMMA'} and (a <= 0 or b <= 0): raise PlanError('Distribution parameters must be positive.')
            if kind=='NORMAL' and b <= 0: raise PlanError('Normal standard deviation must be positive.')
            if kind=='UNIFORM' and a > b: raise PlanError('Uniform bounds are inverted.')
        elif dist is not None:
            raise PlanError('Deterministic parameter cannot declare a distribution.')
    if [(GROUP_ORDER[p['group']], p['id']) for p in parameters] != sorted(
            (GROUP_ORDER[p['group']], p['id']) for p in parameters):
        raise PlanError('Parameters must follow the documented group and local-identifier order.')
    absent_members = member_parameters - canonical_parameter_iris
    if absent_members:
        raise PlanError('Explicit model-member parameters omitted from the plan: ' + ', '.join(sorted(absent_members)))
    settings = plan.get('settings')
    if not isinstance(settings, dict) or settings.get('isProbabilistic') != 0 or isinstance(settings.get('isProbabilistic'), bool):
        raise PlanError('settings must explicitly select isProbabilistic=0 for initial validation.')
    if set(settings) - set(SETTING_PREDICATES) - {'isProbabilistic'}: raise PlanError('Unknown settings keys.')
    setting_evidence = plan.get('settings_evidence', {})
    if not isinstance(setting_evidence, dict): raise PlanError('settings_evidence must be an object.')
    owners = context['settings_owners'][model]
    if len(owners) > 1: raise PlanError('Multiple experiments require an explicit reviewed extension.')
    if owners:
        for key, predicate in SETTING_PREDICATES.items():
            known = [f for f in facts.values() if f['subject'] == owners[0]
                     and f['predicate'] == OSDI+predicate]
            if known and key not in settings:
                raise PlanError('Explicit source setting must be included, not omitted or declared unresolved: ' + key)
    for key, value in settings.items():
        _number(value, 'settings.' + key)
        if key == 'isProbabilistic': continue
        if not owners: raise PlanError('No source owner for setting: ' + key)
        literal_evidence(setting_evidence.get(key), owners[0], SETTING_PREDICATES[key], value, 'settings_evidence.' + key)
        if key == 'timeHorizon' and value <= 0: raise PlanError('timeHorizon must be positive.')
        if key.startswith('discount') and not 0 <= value <= 1: raise PlanError('Discount must be a fraction in [0,1].')
        if key == 'studyYear' and (value != int(value) or not -32768 <= value <= 32767): raise PlanError('Invalid studyYear.')
    missing_list=_list(plan.get('unresolved_dependencies', []), 'unresolved_dependencies')
    if any(not isinstance(x,str) for x in missing_list): raise PlanError('Unresolved dependency names must be text.')
    missing = set(missing_list)
    if missing - set(SETTING_PREDICATES): raise PlanError('Unknown unresolved setting dependency.')
    if missing & set(settings): raise PlanError('Dependency cannot be both resolved and unresolved.')
    decisions=_list(plan.get('decisions'),'decisions',True)
    for decision in decisions:
        if not isinstance(decision,dict): raise PlanError('Each decision must be an object.')
        _nonempty(decision.get('topic'),'decision.topic');_nonempty(decision.get('explanation'),'decision.explanation')
        evidence(decision.get('evidence'),'decision.evidence')
    nodes_seen = set(); leaf_count = 0; formula_refs = set(); intervention_iris = set()
    parameters_by_name={p['name']:p for p in parameters}
    parameters_by_iri={p['iri']:p for p in parameters}
    def probability_reference(name,node,current_intervention):
        if name not in parameters_by_name:
            raise PlanError('Branch probabilities must use source probability parameters, not analysis settings: '+name)
        subject=parameters_by_name[name]['iri']; item_types=data_types(subject)
        if item_types and item_types <= PROBABILITY_TYPES:
            if not 0<=parameters_by_name[name]['expected']<=1: raise PlanError('Source probability is outside [0,1]: '+name)
            return
        if item_types!={OSDI+'DI_Continuous_Variable'}:
            raise PlanError('Parameter type cannot be used as a branch probability: '+name)
        citations=set(node['evidence'])
        for fact in facts.values():
            if fact['predicate']!=OSDI+'hasEffectMagnitude' or fact['object']['value']!=subject: continue
            effect=fact['subject']; owner_ids=relationship(current_intervention,OSDI+'hasEffect',effect)
            if not owner_ids or fact['id'] not in citations or not set(owner_ids)&citations: continue
            effect_types=set(context['types'].get(effect,[]))
            allowed_effect_types=set(context.get('effect_ancestor_types',[OSDI+'Effect']))
            if OSDI+'Effect' not in effect_types or any(t.startswith(OSDI) and t not in allowed_effect_types for t in effect_types): continue
            if data_types(effect) - PROBABILITY_TYPES - {OSDI+'DI_Continuous_Variable'}: continue
            targets={f['object']['value'] for f in facts.values() if f['subject']==effect and f['predicate']==OSDI+'affects'}
            targets|={f['subject'] for f in facts.values() if f['predicate']==OSDI+'isAffectedBy' and f['object']['value']==effect}
            for target in targets:
                target_ids=relationship(effect,OSDI+'affects',target)
                target_types=data_types(target)
                if not target_types or not target_types<=PROBABILITY_TYPES or not set(target_ids)&citations: continue
                target_values=[f for f in facts.values() if f['subject']==target and f['predicate']==OSDI+'hasExpectedValue']
                if not target_values or any(f['object']['kind']!='literal' for f in target_values):
                    raise PlanError('Original replacement target lacks an explicit numeric expected value.')
                target_numbers={_number(f['object']['value'], 'replacement target expected value') for f in target_values}
                if len(target_numbers)!=1:
                    raise PlanError('Ambiguous original replacement target probability.')
                if not 0<=next(iter(target_numbers))<=1: raise PlanError('Original replacement target probability is outside [0,1].')
                if not 0<=parameters_by_name[name]['expected']<=1: raise PlanError('Continuous replacement magnitude is outside [0,1].')
                explicit=any(isinstance(d,dict) and d.get('topic')=='replacement'
                    and isinstance(d.get('evidence'),list) and fact['id'] in d['evidence']
                    and bool(set(owner_ids)&set(d['evidence'])) and bool(set(target_ids)&set(d['evidence'])) for d in decisions)
                if explicit: return
        raise PlanError('Continuous branch magnitude lacks a cited replacement effect for the current intervention: '+name)
    def walk(nodes, depth, current_intervention):
        nonlocal leaf_count
        if depth > 12: raise PlanError('Tree exceeds maximum depth 12.')
        siblings = _list(nodes, 'children', True)
        if any(not isinstance(n,dict) for n in siblings): raise PlanError('Each tree node must be an object.')
        residuals = [i for i,n in enumerate(siblings) if n.get('residual') is True]
        if residuals and (residuals != [len(siblings)-1] or len(siblings) < 2):
            raise PlanError('A residual must be the last and only residual among at least two siblings.')
        for node in siblings:
            if not isinstance(node, dict): raise PlanError('Each tree node must be an object.')
            node_id = _nonempty(node.get('id'), 'node.id')
            if node_id in nodes_seen: raise PlanError('Duplicate node id: ' + node_id)
            nodes_seen.add(node_id)
            if len(nodes_seen)>100000: raise PlanError('Plan exceeds node bound.')
            _nonempty(node.get('label'), 'node.label')
            evidence(node.get('evidence'), 'node.evidence')
            if node.get('residual') is True:
                if 'probability' in node: raise PlanError('Residual probability must not also be supplied.')
            else:
                if node.get('residual',False) is not False: raise PlanError('residual must be a boolean.')
                refs=check_expression(node.get('probability'), names | set(settings))
                for reference in refs: probability_reference(reference,node,current_intervention)
                formula_refs.update(refs)
            for subject in node.get('active_progressions', []):
                if subject not in scope: raise PlanError('Active progression outside model scope.')
            if 'children' in node:
                if 'payoffs' in node: raise PlanError('Node cannot have both children and terminal payoffs.')
                walk(node['children'], depth+1,current_intervention)
            else:
                leaf_count += 1
                if leaf_count>20000: raise PlanError('Plan exceeds 20000 terminal routes.')
                payoffs=node.get('payoffs')
                if not isinstance(payoffs,dict) or set(payoffs)!={'cost','le','qale','life'}:
                    raise PlanError('Terminal node requires explicit cost/le/qale/life formulas.')
                for key, formula in payoffs.items():
                    formula_refs.update(check_expression(formula, names | set(settings) | missing, key!='life'))
    interventions=_list(plan.get('interventions'),'interventions',True)
    included_interventions={s for s in members if OSDI+'Intervention' in context['types'].get(s,[])}
    for intervention in interventions:
        if not isinstance(intervention,dict): raise PlanError('Each intervention must be an object.')
        subject=intervention.get('iri')
        if subject not in included_interventions or subject in intervention_iris: raise PlanError('Unknown or repeated included intervention.')
        intervention_iris.add(subject)
        _nonempty(intervention.get('label'),'intervention.label')
        walk(intervention.get('children'),1,subject)
    if intervention_iris!=included_interventions: raise PlanError('Every included intervention must be represented exactly once.')
    formula_parameters = {canonical_subject(parameters_by_name[name]['iri'])
                          for name in formula_refs if name in parameters_by_name}
    extra_parameters = canonical_parameter_iris - member_parameters - formula_parameters
    if extra_parameters:
        raise PlanError('Parameters must be explicit model members or referenced by a formula; evidence-only items belong in decisions: '
                        + ', '.join(sorted(extra_parameters)))
    semantic_structure_checks = validate_semantic_structure(plan, context)
    return {
        'status':'PLAN_CONTRACT_VALID', 'case_fact_count':len(case_ids),
        'covered_fact_count':len(seen), 'referenced_evidence_count':len(evidence_used),
        'parameters':len(parameters),'interventions':len(interventions),'nodes':len(nodes_seen),'leaves':leaf_count,
        'authorship_claim':author,'ai_authorship_authenticated':False,
        'semantic_completeness':'NOT_PROVEN', 'clinical_semantic_correctness':'NOT_PROVEN',
        'coverage_meaning':'All source facts have an explicit AI disposition; relevance and interpretation remain reviewable AI decisions.',
        'unresolved_dependencies':sorted(missing),
        'semantic_structure_checks': semantic_structure_checks,
        'limitations':['This validator never supplies missing branches, payoffs or parameter values.',
                       'Authorship metadata is a declaration; retain the actual prompt, response and execution record.',
                       'Formula/source checks do not establish full OWL reasoning or clinical/economic equivalence.'],
    }
