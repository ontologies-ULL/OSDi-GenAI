"""Apply the reference presentation contract to any compiled finite tree.

The presenter knows column/row roles and font metrics, never model identities,
clinical values, parameter names or saved example formulas.
"""
from copy import deepcopy
from ooxml import (
    SheetSpec, load_profile, col_letter, split_address, add_tree_edge,
    parameter_header, parameter_style, model_columns,
)


def present(compiled, parameter_cells, profile=None):
    """Return Parameters/Model SheetSpecs from the explicitly authored plan renderer only."""
    profile = profile or load_profile()
    styles = profile["styles"]

    # The provided template reserves forty parameter rows. Extend the same
    # styled row pattern when the graph supplies more parameters.
    parameters = parameter_header(profile)
    parameters.update(deepcopy(profile.get("parameter_empty_cells", {})))
    last_parameter_row = max((split_address(c)[0] for c in parameter_cells), default=6)
    reserved_end = max(profile.get("parameter_reserved_last_row", 40), last_parameter_row)
    for row in range(7, last_parameter_row + 1):
        for column in range(2, 17):
            letter = col_letter(column)
            style_id = 43 if letter in {"E", "M"} else parameter_style(letter, profile=profile)
            parameters[f"{letter}{row}"] = {"value": None, "style": style_id}
    for address, cell in parameter_cells.items():
        _, column = split_address(address)
        clean = {k: deepcopy(v) for k, v in cell.items() if k not in {"parameter_group", "uncertainty", "role"}}
        clean["style"] = parameter_style(col_letter(column), cell.get("parameter_group"), cell.get("uncertainty"), profile)
        parameters[address] = clean

    parameter_rows = {int(r): deepcopy(attrs) for r, attrs in profile.get("parameter_row_attributes", {}).items()}
    parameter_sheet = SheetSpec(
        cells=parameters,
        columns=deepcopy(profile["parameter_columns"]),
        row_attributes=parameter_rows,
        merges=deepcopy(profile.get("parameter_merges", [])),
        dimension=f"A1:P{reserved_end}",
        sheet_format=deepcopy(profile["parameter_sheet_format"]),
    )

    model = {"B2": {"value": None, "style": styles["background"]}}
    # Entire payoff heading regions have an intentional background, including
    # the empty spacer columns and the continuous three-cell detail banner.
    for row in (3, 4):
        for column in range(compiled["output_col"], compiled["le_col"] + 1):
            role = "header_detail" if row == 3 and compiled["detail_col"] <= column <= compiled["detail_col"] + 2 else "background"
            model[f"{col_letter(column)}{row}"] = {"value": None, "style": styles[role]}

    starts = compiled["starts"]
    first_root_row = starts[0][1] if starts else profile["geometry"]["tree_first_row"]
    for _, first, _ in starts:
        root_label = compiled["cells"][f"D{first}"].get("value", "")
        add_tree_edge(model, 1, first_root_row, 4, first, None, root_label, profile)
    for edge, parent_column, parent_row in compiled["edges"]:
        add_tree_edge(model, parent_column, parent_row, edge.column, edge.row, edge.probability, edge.label, profile)
    # A route ending before the deepest branch still connects horizontally to
    # the common payoff columns. All terminal outputs align at the same depth.
    for edge, _ in compiled["leaves"]:
        for column in range(edge.column + 1, compiled["output_col"] - 1):
            model[f"{col_letter(column)}{edge.row}"] = {"value": None, "style": styles["branch_label"]}

    role_alias = {"detail_header": "header_detail", "undiscounted_header": "header_le"}
    for address, cell in compiled["cells"].items():
        clean = {k: deepcopy(v) for k, v in cell.items() if k != "role"}
        role = role_alias.get(cell.get("role"), cell.get("role"))
        if role:
            clean["style"] = styles[role]
        else:
            clean.setdefault("style", styles["background"])
        model[address] = clean

    # The reference layout leaves two initialized, empty trailing rows. They
    # affect its saved used range but have no clinical or formula content.
    model_rows = {split_address(address)[0]: {} for address in model}
    model_rows[compiled["last_row"] + 2] = {}
    model_rows[compiled["last_row"] + 3] = {}
    deepest_node_col = 4 + 3 * compiled["depth"]
    model_sheet = SheetSpec(
        cells=model,
        columns=model_columns(model, deepest_node_col, profile),
        row_attributes=model_rows,
        merges=[],
        dimension=f"B2:{col_letter(compiled['le_col'])}{compiled['last_row'] + 3}",
        sheet_format=deepcopy(profile["model_sheet_format"]),
    )
    return {"Parameters": parameter_sheet, "Model": model_sheet}
