"""Reject a narrow class of invalid AI-authored clinical structures.

This module never creates or repairs branches, probabilities or payoff formulas.
Its supported profile places an unsequenced disease-level InstantDeathEffect at
condition onset, before any progression. Explicit temporal constructions,
progression-owned instant death and combinations of death effects need another
reviewed profile and fail closed here. Passing is not a proof of completeness.

Affected plans declare a ``role='disease'`` node with ``entity=<disease IRI>``
and ``state.disease=True``. Its two children are ``instant_death`` and residual
``survival``; both bind ``entity`` and ``effect`` and cite the source links/types.
The declaration makes the AI's clinical interpretation inspectable, not inferred.
"""
from __future__ import annotations

import re

from ontology import OSDI, RDF, OWL


PROFILE = 'disease-instant-death-before-progression/1'
_SYMBOL = re.compile(r'[A-Za-z_][A-Za-z0-9_.]*')
_TEMPORAL = {OSDI + name for name in (
    'hasNext', 'hasPrevious', 'hasFirst', 'hasNextProgression', 'hasDuration')}
_PROGRESSION_TYPES = {OSDI + name for name in (
    'DiseaseProgression', 'ClinicalProgressionElement', 'Manifestation',
    'AcuteManifestation', 'ChronicManifestation', 'Stage')}


def validate_semantic_structure(plan, context):
    """Validate supplied topology against source facts; return a small audit.

    General syntax, formula grammar and source-value checks belong to
    ``ai_contract.validate_plan``. No-effect cases retain the existing contract.
    This function does not mutate either argument.
    """
    def fail(message):
        raise ValueError('Semantic guard (' + PROFILE + '): ' + message)

    if not isinstance(plan, dict) or not isinstance(context, dict):
        fail('plan and context must be objects.')
    model = plan.get('model_iri')
    scope = set(context.get('model_scopes', {}).get(model, []))
    types = context.get('types', {})
    instant = {iri for iri in scope if OSDI + 'InstantDeathEffect' in types.get(iri, [])}
    report = {'status': 'SEMANTIC_GUARDS_VALID', 'profile': PROFILE,
              'applicable_effects': len(instant), 'validated_splits': 0,
              'semantic_completeness': 'NOT_PROVEN',
              'limitations': ['Shared payoff parameters are allowed only with cited disease, intervention or instant-death ownership; allocation of shared occurrences is not proved.']}
    if not instant:
        return report
    if not isinstance(plan.get('authorship'), dict) or plan['authorship'].get('kind') != 'ai':
        fail('an explicit AI-authored proposal is required.')
    facts = context.get('facts', []) + context.get('schema_evidence', [])
    direct = {}
    for fact in facts:
        obj = fact['object']
        if obj['kind'] == 'iri':
            direct.setdefault((fact['subject'], fact['predicate']), {}).setdefault(obj['value'], set()).add(fact['id'])

    def links(subject, predicate):
        result = {target: set(ids) for target, ids in direct.get((subject, predicate), {}).items()}
        for inverse in context.get('inverse_properties', {}).get(predicate, []):
            for (source, prop), values in direct.items():
                if prop == inverse and subject in values:
                    result.setdefault(source, set()).update(values[subject])
        return result

    def cited(node, ids, label):
        evidence = node.get('evidence')
        if not isinstance(evidence, list) or not set(evidence).intersection(ids):
            fail(label + ' requires the corresponding source evidence.')

    def cited_types(node, subject, required_type):
        acceptable = {OSDI + required_type}
        if required_type == 'Parameter':
            # OSDi 1.1 separates parameter nature from parameter role; a
            # nature assertion alone need not entail the named Parameter type.
            acceptable.update({OSDI + 'DeterministicParameter', OSDI + 'SecondOrderUncertaintyParameter'})
        if not acceptable.intersection(types.get(subject, [])):
            fail('source entity lacks type ' + required_type + ': ' + subject)
        explicit = direct.get((subject, RDF + 'type'), {})
        # The context already carries named-class closure. Cite every direct
        # semantic type, so an unrelated NamedIndividual assertion cannot hide
        # the actual disease/effect/parameter type.
        semantic = {cls: ids for cls, ids in explicit.items() if cls != OWL + 'NamedIndividual'}
        if not semantic:
            fail('source entity has no explicit type evidence: ' + subject)
        for ids in semantic.values():
            cited(node, ids, 'Type of ' + subject)

    if any(f['subject'] in scope and f['predicate'] in _TEMPORAL for f in facts):
        fail('explicit temporal sequencing requires a separately supported profile.')
    if any(OSDI + 'SequentialDiseaseProgressionSet' in types.get(s, []) for s in scope):
        fail('sequential progression requires a separately supported profile.')

    diseases = {s for s in scope if OSDI + 'Disease' in types.get(s, [])}
    by_disease = {}
    for effect in sorted(instant):
        owners = {s: links(s, OSDI + 'hasEffect')[effect]
                  for s in scope if effect in links(s, OSDI + 'hasEffect')}
        if len(owners) != 1 or not set(owners) <= diseases:
            fail('InstantDeathEffect must have one disease owner; progression-owned or unowned effects are unsupported: ' + effect)
        disease = next(iter(owners))
        if disease in by_disease:
            fail('multiple disease-level death effects require an explicit supported combination profile.')
        magnitudes = links(effect, OSDI + 'hasEffectMagnitude')
        if len(magnitudes) != 1:
            fail('InstantDeathEffect requires one unambiguous source magnitude: ' + effect)
        magnitude = next(iter(magnitudes))
        by_disease[disease] = (effect, magnitude, owners[disease], magnitudes[magnitude])

    parameters = plan.get('parameters', [])
    by_iri = {p['iri']: p for p in parameters}
    progressions = {s for s in scope if _PROGRESSION_TYPES.intersection(types.get(s, []))}
    for disease in diseases:
        progressions.update(links(disease, OSDI + 'hasProgressionElement'))
    progression_parameters = {target for progression in progressions
                              for prop in ('hasCost', 'hasUtility')
                              for target in links(progression, OSDI + prop)}
    progression_risks = {target for progression in progressions
                         for target in links(progression, OSDI + 'hasRiskCharacterization')}
    payoff_names = {p['name'] for p in parameters if p['iri'] in progression_parameters}
    risk_names = {p['name'] for p in parameters if p['iri'] in progression_risks}

    def symbols(formula):
        return set(_SYMBOL.findall(formula)) if isinstance(formula, str) else set()

    def progression_node(node):
        return (node.get('entity') in progressions or bool(node.get('active_progressions'))
                or node.get('role') in {'progression', 'manifestation'}
                or bool(symbols(node.get('probability')) & risk_names))

    def unsupported_progression_payoffs(node, owners):
        referenced = set().union(*(symbols(formula) for formula in node.get('payoffs', {}).values()))
        for name in referenced & payoff_names:
            parameter = next(p['iri'] for p in parameters if p['name'] == name)
            # Sharing a parameter is not evidence that two clinical occurrences
            # are interchangeable. A non-progression occurrence must itself be
            # bound by a cited direct source relationship.
            if not any(set(node.get('evidence', [])).intersection(links(owner, OSDI + prop).get(parameter, set()))
                       for owner in owners for prop in ('hasCost', 'hasUtility')):
                return True
        return False

    def mortality_probability(node, intervention, magnitude):
        replacements = []
        for effect, owner_ids in links(intervention, OSDI + 'hasEffect').items():
            target_ids = links(effect, OSDI + 'affects').get(magnitude)
            if not target_ids:
                continue
            effect_types = set(types.get(effect, []))
            ancestors = set(context.get('effect_ancestor_types', [OSDI + 'Effect']))
            if OSDI + 'Effect' not in effect_types or any(t.startswith(OSDI) and t not in ancestors for t in effect_types):
                fail('a mortality-modifying effect needs a separately supported operation: ' + effect)
            magnitudes = links(effect, OSDI + 'hasEffectMagnitude')
            if len(magnitudes) != 1:
                fail('mortality replacement requires one source magnitude.')
            replacement = next(iter(magnitudes))
            magnitude_ids = magnitudes[replacement]
            for ids, label in ((owner_ids, 'Intervention effect'), (target_ids, 'Mortality replacement target'),
                               (magnitude_ids, 'Mortality replacement magnitude')):
                cited(node, ids, label)
            cited_types(node, effect, 'Effect')
            cited_types(node, replacement, 'Parameter')
            if not any(d.get('topic') == 'replacement'
                       and all(set(d.get('evidence', [])).intersection(ids)
                               for ids in (owner_ids, target_ids, magnitude_ids))
                       for d in plan.get('decisions', [])):
                fail('mortality replacement requires an explicit evidenced replacement decision.')
            replacements.append(replacement)
        if len(replacements) > 1:
            fail('multiple mortality replacements require a supported combination profile.')
        expected_iri = replacements[0] if replacements else magnitude
        parameter = by_iri.get(expected_iri)
        if parameter is None or node.get('probability', '').strip() != parameter['name']:
            fail('death probability must directly reference its evidenced magnitude; arithmetic operations cannot be invented.')

    interventions = plan.get('interventions')
    if not isinstance(interventions, list) or not interventions:
        fail('every intervention must include the affected disease split.')
    for intervention in interventions:
        records = []

        def collect(nodes, ancestors):
            if not isinstance(nodes, list) or not nodes:
                fail('tree children must be a nonempty list.')
            if len(ancestors) > 12:
                fail('tree exceeds supported depth.')
            for node in nodes:
                if not isinstance(node, dict):
                    fail('tree nodes must be objects.')
                if not isinstance(node.get('state', {}), dict):
                    fail('node state must be an object.')
                if any(key in node and not isinstance(node[key], str) for key in ('role', 'entity', 'effect')):
                    fail('role, entity and effect metadata must be strings.')
                if 'payoffs' in node and not isinstance(node['payoffs'], dict):
                    fail('terminal payoffs must be an object.')
                records.append((node, ancestors))
                if 'children' in node:
                    collect(node['children'], ancestors + [node])

        collect(intervention.get('children'), [])
        roots = [(node, ancestors) for node, ancestors in records if node.get('role') == 'disease']
        expected_children = set()
        for disease, (effect, magnitude, owner_ids, magnitude_ids) in by_disease.items():
            matching = [(node, ancestors) for node, ancestors in roots if node.get('entity') == disease]
            if not matching:
                fail('each intervention requires an explicit disease role and onset split: ' + disease)
            for root, ancestors in matching:
                if any(progression_node(n) or n.get('role') in {'disease', 'survival', 'instant_death'} for n in ancestors):
                    fail('disease-level instant death cannot follow a progression or another disease outcome.')
                state = root.get('state', {})
                if state.get('disease') is not True or state.get('dead', False) is not False or progression_node(root):
                    fail('disease node requires truthful disease/alive state without preceding progressions.')
                children = root.get('children', [])
                if len(children) != 2 or [n.get('role') for n in children] != ['instant_death', 'survival']:
                    fail('disease node must immediately split into exactly instant_death and survival.')
                death, survival = children
                expected_children.update(map(id, children))
                for child in children:
                    if child.get('entity') != disease or child.get('effect') != effect:
                        fail('death and survival must bind the source disease and effect IRIs.')
                    cited(child, owner_ids, 'Disease hasEffect')
                    cited(child, magnitude_ids, 'Effect hasEffectMagnitude')
                    cited_types(child, disease, 'Disease')
                    cited_types(child, effect, 'InstantDeathEffect')
                    cited_types(child, magnitude, 'Parameter')
                death_state = death.get('state', {})
                if death_state.get('dead') is not True or death_state.get('disease') is not True:
                    fail('instant death requires state.dead=true and state.disease=true.')
                if 'children' in death or death.get('active_progressions') != []:
                    fail('instant death must be terminal with active_progressions=[].')
                payoffs = death.get('payoffs')
                if not isinstance(payoffs, dict) or re.sub(r'\s+', '', str(payoffs.get('life'))) not in {'0', 'MIN(0,timeHorizon)'}:
                    fail('instant death life must explicitly be 0 or MIN(0,timeHorizon).')
                if unsupported_progression_payoffs(death, (disease, effect, intervention['iri'])):
                    fail('instant death cannot reference costs or utilities owned by progressions, even multiplied by zero.')
                if death.get('residual', False) is not False:
                    fail('instant death must have an explicit source probability.')
                survivor_state = survival.get('state', {})
                if (survival.get('residual') is not True or 'probability' in survival
                        or survivor_state.get('disease') is not True or survivor_state.get('dead') is not False
                        or survival.get('active_progressions') != []):
                    fail('survival must be the disease/alive residual with active_progressions=[].')
                mortality_probability(death, intervention['iri'], magnitude)
                report['validated_splits'] += 1

        for node, ancestors in records:
            role = node.get('role')
            if role in {'instant_death', 'survival'} and id(node) not in expected_children:
                fail('death/survival roles must be direct outcomes of their declared disease split.')
            if role == 'disease' and node.get('entity') not in by_disease:
                fail('disease role refers to an unsupported or unknown disease.')
            surviving = any(n.get('role') == 'survival' and id(n) in expected_children for n in ancestors)
            state = node.get('state', {})
            if role not in {'disease', 'instant_death', 'survival'}:
                if state.get('disease') is True and not surviving:
                    fail('a diseased route bypasses the required instant-death split.')
                if state.get('dead') is True:
                    fail('an undeclared death outcome bypasses the supported instant-death split.')
                if surviving and state.get('disease', True) is not True:
                    fail('surviving disease route cannot falsely declare absence of disease.')
            if progression_node(node) and not surviving:
                fail('progressions must occur below the survival outcome, never before instant death.')
            allowed_owners = [intervention['iri']]
            if role == 'instant_death':
                allowed_owners += [node['entity'], node['effect']]
            if unsupported_progression_payoffs(node, allowed_owners) and not surviving:
                fail('progression payoffs require a surviving disease route.')
    return report
