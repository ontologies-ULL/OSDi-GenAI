"""Surgical XLSM I/O. Only Parameters/Model cell contents are ever parsed.

Other OPC parts are opaque byte streams copied and hashed for preservation.
Workbook-level sheet relationships, defined names and styles are metadata, not
permission to inspect another worksheet. No Excel/openpyxl load/save is used.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
import hashlib
import json
import math
import posixpath
import re
import zipfile
import xml.etree.ElementTree as ET

MAIN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PKGREL = "http://schemas.openxmlformats.org/package/2006/relationships"
ALLOWED_SHEETS = frozenset(("Parameters", "Model"))
ET.register_namespace("", MAIN)
ET.register_namespace("r", REL)
Q = lambda name: f"{{{MAIN}}}{name}"


class WorkbookContractError(ValueError):
    pass


def col_index(column: str) -> int:
    n = 0
    for ch in column.upper():
        if ch < "A" or ch > "Z":
            raise WorkbookContractError(f"Invalid column {column!r}")
        n = n * 26 + ord(ch) - 64
    if not 1 <= n <= 16384:
        raise WorkbookContractError(f"Column exceeds Excel limits: {column}")
    return n


def col_letter(index: int) -> str:
    if not 1 <= index <= 16384:
        raise WorkbookContractError(f"Column index exceeds Excel limits: {index}")
    result = ""
    while index:
        index, rem = divmod(index - 1, 26)
        result = chr(65 + rem) + result
    return result


def split_address(address: str) -> tuple[int, int]:
    match = re.fullmatch(r"([A-Z]+)([1-9][0-9]*)", address)
    if not match:
        raise WorkbookContractError(f"Invalid cell address {address!r}")
    column, row = match.groups()
    r = int(row)
    if r > 1048576:
        raise WorkbookContractError(f"Row exceeds Excel limit: {address}")
    return r, col_index(column)


def _part_path(target: str) -> str:
    result = target.lstrip("/") if target.startswith("/") else posixpath.normpath(posixpath.join("xl", target))
    if not result.startswith("xl/") or ".." in result.split("/"):
        raise WorkbookContractError(f"Unsafe OPC target {target!r}")
    return result


def _metadata(archive: zipfile.ZipFile) -> tuple[dict[str, str], ET.Element]:
    workbook = ET.fromstring(archive.read("xl/workbook.xml"))
    relationships = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
    relmap = {entry.attrib["Id"]: entry.attrib["Target"] for entry in relationships if entry.attrib.get("TargetMode") != "External"}
    paths = {}
    for sheet in workbook.findall(Q("sheets") + "/" + Q("sheet")):
        name = sheet.attrib["name"]
        if name in ALLOWED_SHEETS:
            paths[name] = _part_path(relmap[sheet.attrib[f"{{{REL}}}id"]])
    if set(paths) != ALLOWED_SHEETS:
        raise WorkbookContractError("The template must contain Parameters and Model, with exact names.")
    return paths, workbook


def styles_fingerprint(styles_bytes: bytes) -> str:
    # Canonicalizing XML removes declaration/prefix variation without guessing style IDs.
    normalized = ET.canonicalize(styles_bytes.decode("utf-8"), rewrite_prefixes=True)
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()


def _allowed_reference(text: str | None) -> bool:
    return bool(text and re.match(r"^'?(Parameters|Model)'?!", text))


def read_allowed_workbook(path: str | Path) -> dict[str, Any]:
    """Return ONLY the two permitted sheet contents and their package metadata."""
    with zipfile.ZipFile(path) as archive:
        paths, workbook = _metadata(archive)
        roots = {name: ET.fromstring(archive.read(part)) for name, part in paths.items()}
        needed = {int(c.findtext(Q("v"))) for rt in roots.values() for c in rt.iter(Q("c")) if c.attrib.get("t") == "s"}
        strings = {}
        if needed:
            shared = ET.fromstring(archive.read("xl/sharedStrings.xml"))
            strings = {i: "".join(t.text or "" for t in item.iter(Q("t"))) for i, item in enumerate(shared) if i in needed}
        sheets = {}
        for name, root in roots.items():
            cells = {}
            for cell in root.iter(Q("c")):
                formula = cell.find(Q("f"))
                raw = cell.findtext(Q("v"))
                kind = cell.attrib.get("t")
                if kind == "s":
                    value = strings[int(raw)]
                elif kind == "inlineStr":
                    value = "".join(t.text or "" for t in cell.iter(Q("t")))
                elif kind == "b":
                    value = raw == "1" if raw is not None else None
                elif raw is not None and kind not in ("str", "e"):
                    try:
                        value = float(raw) if "." in raw or "e" in raw.lower() else int(raw)
                    except ValueError:
                        value = raw
                else:
                    value = raw
                data = {"style": int(cell.attrib.get("s", "0"))}
                if formula is not None:
                    data.update(formula=formula.text or "", cached=value)
                    if formula.attrib:
                        data["formula_attributes"] = dict(formula.attrib)
                    if kind == "e": data["cached_type"] = "e"
                else:
                    data["value"] = value
                    if kind == "e": data["value_type"] = "e"
                cells[cell.attrib["r"]] = data
            dimension = root.find(Q("dimension"))
            fmt = root.find(Q("sheetFormatPr"))
            sheets[name] = {
                "cells": cells,
                "columns": [dict(c.attrib) for c in root.findall(Q("cols") + "/" + Q("col"))],
                "row_attributes": {int(r.attrib["r"]): {k: v for k, v in r.attrib.items() if k != "r"} for r in root.findall(Q("sheetData") + "/" + Q("row"))},
                "merges": [m.attrib["ref"] for m in root.findall(Q("mergeCells") + "/" + Q("mergeCell"))],
                "dimension": dimension.attrib["ref"] if dimension is not None else "A1",
                "sheet_format": dict(fmt.attrib) if fmt is not None else {},
                "part": paths[name],
            }
        names = {n.attrib["name"]: n.text for n in workbook.findall(Q("definedNames") + "/" + Q("definedName")) if _allowed_reference(n.text)}
        return {"sheets": sheets, "names": names, "styles_fingerprint": styles_fingerprint(archive.read("xl/styles.xml"))}


@dataclass
class SheetSpec:
    cells: dict[str, dict[str, Any]]
    columns: list[dict[str, Any]] | None = None
    row_heights: dict[int, float] = field(default_factory=dict)
    row_attributes: dict[int, dict[str, Any]] = field(default_factory=dict)
    merges: list[str] | None = None
    dimension: str | None = None
    sheet_format: dict[str, Any] | None = None


def _bool_string(value: Any) -> str:
    return "1" if value is True else "0" if value is False else str(value)


def _make_cell(address: str, data: dict[str, Any]) -> ET.Element:
    attrib = {"r": address}
    if data.get("style") is not None:
        attrib["s"] = str(data["style"])
    cell = ET.Element(Q("c"), attrib)
    if "formula" in data and data["formula"] is not None:
        formula = str(data["formula"]).removeprefix("=")
        if len(formula) > 8192:
            raise WorkbookContractError(f"Formula exceeds 8192 characters at {address}.")
        ET.SubElement(cell, Q("f"), {k: str(v) for k, v in data.get("formula_attributes", {}).items()}).text = formula
        cached = data.get("cached")
        if cached is not None:
            if isinstance(cached, bool): cell.set("t", "b")
            elif data.get("cached_type") == "e": cell.set("t", "e")
            elif isinstance(cached, str): cell.set("t", "str")
            elif isinstance(cached, float) and not math.isfinite(cached):
                raise WorkbookContractError(f"Non-finite cached value at {address}.")
            ET.SubElement(cell, Q("v")).text = _bool_string(cached)
    else:
        value = data.get("value")
        if value is None:
            return cell
        if isinstance(value, str) and data.get("value_type") != "e":
            if len(value) > 32767:
                raise WorkbookContractError(f"Text exceeds Excel limit at {address}.")
            cell.set("t", "inlineStr")
            text = ET.SubElement(ET.SubElement(cell, Q("is")), Q("t"))
            text.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
            text.text = value
        else:
            if isinstance(value, bool): cell.set("t", "b")
            elif data.get("value_type") == "e": cell.set("t", "e")
            elif isinstance(value, float) and not math.isfinite(value):
                raise WorkbookContractError(f"Non-finite value at {address}.")
            ET.SubElement(cell, Q("v")).text = _bool_string(value)
    return cell


_SHEET_ORDER = ["sheetPr", "dimension", "sheetViews", "sheetFormatPr", "cols", "sheetData", "sheetCalcPr", "sheetProtection", "protectedRanges", "scenarios", "autoFilter", "sortState", "dataConsolidate", "customSheetViews", "mergeCells", "phoneticPr", "conditionalFormatting", "dataValidations", "hyperlinks", "printOptions", "pageMargins", "pageSetup", "headerFooter", "rowBreaks", "colBreaks", "customProperties", "cellWatches", "ignoredErrors", "smartTags", "drawing", "legacyDrawing", "legacyDrawingHF", "picture", "oleObjects", "controls", "webPublishItems", "tableParts", "extLst"]


def _replace_child(root: ET.Element, name: str, child: ET.Element | None) -> None:
    existing = root.find(Q(name))
    if existing is not None:
        index = list(root).index(existing)
        root.remove(existing)
        if child is not None: root.insert(index, child)
    elif child is not None:
        priority = _SHEET_ORDER.index(name)
        index = next((i for i, e in enumerate(root) if e.tag.rsplit("}", 1)[-1] in _SHEET_ORDER and _SHEET_ORDER.index(e.tag.rsplit("}", 1)[-1]) > priority), len(root))
        root.insert(index, child)


def _replace_xml_section(original: bytes, name: str, element: ET.Element | None, order: list[str], root_name: str) -> bytes:
    """Replace one section while retaining all original namespace declarations.

    Full ElementTree serialization drops namespace prefixes referenced only by
    mc:Ignorable/Requires attribute values. Surgical replacement also avoids
    rewriting unrelated workbook metadata.
    """
    text = original.decode("utf-8")
    pattern = re.compile(rf"<(?:[\w.-]+:)?{name}\b(?:[^>]*?/>|[^>]*>.*?</(?:[\w.-]+:)?{name}\s*>)", re.S)
    fragment = ET.tostring(element, encoding="unicode") if element is not None else ""
    if pattern.search(text):
        return pattern.sub(lambda _: fragment, text, count=1).encode("utf-8")
    if element is None:
        return original
    index = order.index(name)
    for later in order[index + 1:]:
        match = re.search(rf"<(?:[\w.-]+:)?{later}\b", text)
        if match:
            return (text[:match.start()] + fragment + text[match.start():]).encode("utf-8")
    close = re.search(rf"</(?:[\w.-]+:)?{root_name}\s*>", text)
    if not close:
        raise WorkbookContractError(f"Missing {root_name} closing element.")
    return (text[:close.start()] + fragment + text[close.start():]).encode("utf-8")


def _render_sheet(original: bytes, spec: SheetSpec) -> bytes:
    root = ET.fromstring(original)  # Called ONLY for one of the two permitted sheets.
    coordinates = {address: split_address(address) for address in spec.cells}
    rows: dict[int, list[tuple[int, str, dict]]] = {}
    for address, data in spec.cells.items():
        row, column = coordinates[address]
        rows.setdefault(row, []).append((column, address, data))
    sheet_data = ET.Element(Q("sheetData"))
    row_attributes = {int(r): a for r, a in spec.row_attributes.items()}
    row_heights = {int(r): h for r, h in spec.row_heights.items()}
    for row in sorted(set(rows) | set(row_attributes) | set(row_heights)):
        attrib = {"r": str(row), **{k: _bool_string(v) for k, v in row_attributes.get(row, {}).items()}}
        if row in row_heights:
            attrib.update(ht=str(row_heights[row]), customHeight="1")
        element = ET.SubElement(sheet_data, Q("row"), attrib)
        for _, address, data in sorted(rows.get(row, [])):
            element.append(_make_cell(address, data))
    _replace_child(root, "sheetData", sheet_data)
    dimension = spec.dimension
    if not dimension:
        if coordinates:
            minrow = min(r for r, _ in coordinates.values()); maxrow = max(r for r, _ in coordinates.values())
            mincol = min(c for _, c in coordinates.values()); maxcol = max(c for _, c in coordinates.values())
            dimension = f"{col_letter(mincol)}{minrow}:{col_letter(maxcol)}{maxrow}"
        else: dimension = "A1"
    _replace_child(root, "dimension", ET.Element(Q("dimension"), {"ref": dimension}))
    if spec.columns is not None:
        cols = ET.Element(Q("cols"))
        for column in spec.columns:
            attrib = {k: _bool_string(v) for k, v in column.items()}
            ET.SubElement(cols, Q("col"), attrib)
        _replace_child(root, "cols", cols if len(cols) else None)
    if spec.sheet_format is not None:
        _replace_child(root, "sheetFormatPr", ET.Element(Q("sheetFormatPr"), {k: _bool_string(v) for k, v in spec.sheet_format.items()}))
    if spec.merges is not None:
        merged = ET.Element(Q("mergeCells"), {"count": str(len(spec.merges))})
        for ref in spec.merges:
            ET.SubElement(merged, Q("mergeCell"), {"ref": ref})
        _replace_child(root, "mergeCells", merged if len(merged) else None)
    sections = ["dimension", "sheetData"]
    if spec.columns is not None: sections.append("cols")
    if spec.sheet_format is not None: sections.append("sheetFormatPr")
    if spec.merges is not None: sections.append("mergeCells")
    result = original
    for name in sections:
        result = _replace_xml_section(result, name, root.find(Q(name)), _SHEET_ORDER, "worksheet")
    return result


def _update_workbook_metadata(original: bytes, names: dict[str, str], scoped_names: list[dict[str, Any]]) -> bytes:
    root = ET.fromstring(original)
    container = root.find(Q("definedNames"))
    if container is None:
        container = ET.Element(Q("definedNames"))
        calculation = root.find(Q("calcPr"))
        root.insert(list(root).index(calculation) if calculation is not None else len(root), container)
    existing = {}
    for element in container:
        if 'localSheetId' in element.attrib:continue
        key=element.attrib['name'].casefold()
        if key in existing:raise WorkbookContractError('Duplicate case-insensitive global defined name: '+element.attrib['name'])
        existing[key]=element
    if len({n.casefold() for n in names}) != len(names):
        raise WorkbookContractError('Generated defined names collide ignoring letter case.')
    for name, reference in names.items():
        if not re.fullmatch(r"[A-Za-z_\\][A-Za-z0-9_.\\]*", name):
            raise WorkbookContractError(f"Invalid defined name {name!r}.")
        if not _allowed_reference(reference):
            raise WorkbookContractError(f"New or changed defined name must point to Parameters/Model: {name}")
        element = existing.get(name.casefold())
        if element is not None and element.text != reference and not _allowed_reference(element.text):
            raise WorkbookContractError(f"Cannot replace protected defined name {name!r} pointing outside permitted sheets.")
        if element is None:
            element = ET.SubElement(container, Q("definedName"), {"name": name})
            existing[name.casefold()]=element
        element.text = reference
    sheet_indices = {e.attrib["name"]: i for i, e in enumerate(root.findall(Q("sheets") + "/" + Q("sheet")))}
    seen_scoped=set()
    for item in scoped_names:
        name, sheet, value = item["name"], item["sheet"], str(item["value"])
        if sheet not in ALLOWED_SHEETS:
            raise WorkbookContractError("Scoped names can be changed only within Parameters or Model.")
        if not re.fullmatch(r"[A-Za-z_\\][A-Za-z0-9_.\\]*", name):
            raise WorkbookContractError(f"Invalid scoped name {name!r}.")
        if not (_allowed_reference(value) or re.fullmatch(r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?|TRUE|FALSE|"(?:[^"]|"")*"', value)):
            raise WorkbookContractError(f"Scoped value must be a constant or a reference to an allowed sheet: {name}.")
        sheet_index = str(sheet_indices[sheet])
        scoped_key=(sheet_index,name.casefold())
        if scoped_key in seen_scoped:raise WorkbookContractError('Duplicate generated scoped name: '+name)
        seen_scoped.add(scoped_key)
        matches=[e for e in container if e.attrib.get("name",'').casefold() == name.casefold() and e.attrib.get("localSheetId") == sheet_index]
        if len(matches)>1:raise WorkbookContractError('Duplicate case-insensitive scoped defined name: '+name)
        element=matches[0] if matches else None
        if element is None:
            element = ET.SubElement(container, Q("definedName"), {"name": name, "localSheetId": sheet_index})
        element.text = value
    calc = root.find(Q("calcPr"))
    if calc is None: calc = ET.SubElement(root, Q("calcPr"))
    calc.set("fullCalcOnLoad", "1")
    calc.set("forceFullCalc", "1")
    calc.set("calcCompleted", "0")
    order = ["fileVersion", "fileSharing", "workbookPr", "workbookProtection", "bookViews", "sheets", "functionGroups", "externalReferences", "definedNames", "calcPr", "oleSize", "customWorkbookViews", "pivotCaches", "smartTagPr", "smartTagTypes", "webPublishing", "fileRecoveryPr", "webPublishObjects", "extLst"]
    result = _replace_xml_section(original, "definedNames", container, order, "workbook")
    return _replace_xml_section(result, "calcPr", calc, order, "workbook")


def patch_workbook(template: str | Path, output: str | Path, sheets: dict[str, SheetSpec | dict], names: dict[str, str] | None = None, *, scoped_names: list[dict[str, Any]] | None = None, expected_styles_fingerprint: str | None = None) -> dict[str, Any]:
    """Write generated content without interpreting or changing other sheets.

    The ONLY mutable ZIP entries are the two worksheet XMLs and workbook.xml
    for names targeting those sheets plus recalculation flags. Existing style,
    shared-string, macro and calculation-chain entries remain byte-identical.
    """
    template, output = Path(template), Path(output)
    if template.resolve() == output.resolve():
        raise WorkbookContractError("Refusing to overwrite the source template.")
    if set(sheets) - ALLOWED_SHEETS:
        raise WorkbookContractError("Only Parameters and Model can be authored.")
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_name(output.name + ".writing")
    try:
        with zipfile.ZipFile(template) as source:
            paths, _ = _metadata(source)
            if expected_styles_fingerprint and styles_fingerprint(source.read("xl/styles.xml")) != expected_styles_fingerprint:
                raise WorkbookContractError("Template styles differ from the validated profile; explicit remapping is required.")
            replacements = {}
            for name, specification in sheets.items():
                if isinstance(specification, dict):
                    specification = SheetSpec(**{k: v for k, v in specification.items() if k in SheetSpec.__dataclass_fields__})
                replacements[paths[name]] = _render_sheet(source.read(paths[name]), specification)
            replacements["xl/workbook.xml"] = _update_workbook_metadata(source.read("xl/workbook.xml"), names or {}, scoped_names or [])
            before = {}
            with zipfile.ZipFile(temporary, "w") as target:
                for info in source.infolist():
                    payload = source.read(info.filename)  # Opaque copy/hash for every unpermitted part.
                    before[info.filename] = hashlib.sha256(payload).hexdigest()
                    target.writestr(deepcopy(info), replacements.get(info.filename, payload))
        with zipfile.ZipFile(temporary) as target:
            after = {name: hashlib.sha256(target.read(name)).hexdigest() for name in target.namelist()}
        changed = sorted(n for n in before if before[n] != after[n])
        if set(before) != set(after) or set(changed) - set(replacements):
            raise WorkbookContractError("OPC preservation check failed.")
        protected = {n: h for n, h in before.items() if n not in replacements}
        aggregate = hashlib.sha256(json.dumps(protected, sort_keys=True).encode()).hexdigest()
        temporary.replace(output)
        return {"changed_parts": changed, "permitted_parts": sorted(replacements), "protected_part_count": len(protected), "protected_payloads_sha256": aggregate, "all_protected_payloads_identical": True, "worksheets_inspected": sorted(sheets), "recalculation": "Cached values supplied by generator; Excel full recalculation requested on open; macros not executed."}
    except Exception:
        if temporary.exists(): temporary.unlink()
        raise


def load_profile(path: str | Path | None = None) -> dict[str, Any]:
    profile = Path(path) if path else Path(__file__).with_name("style_profile.json")
    return json.loads(profile.read_text(encoding="utf-8"))


def style(role: str, profile: dict[str, Any] | None = None) -> int:
    return int((profile or load_profile())["styles"][role])


def add_tree_edge(cells: dict[str, dict], parent_col: int, parent_row: int, child_col: int, child_row: int, prob_formula: str | None, label: str, profile: dict | None = None) -> None:
    """Draw one branch using the reference's cell borders, with no shapes."""
    profile = profile or load_profile()
    styles = profile["styles"]
    if child_col <= parent_col or child_row < parent_row:
        raise WorkbookContractError("Tree edges must run rightwards/downwards.")
    if child_row == parent_row:
        for col in range(parent_col + 1, child_col + 2):
            cells.setdefault(f"{col_letter(col)}{child_row}", {"value": None, "style": styles["branch_label"]})
    else:
        trunk = child_col - 1
        for row in range(parent_row + 1, child_row):
            address = f"{col_letter(trunk)}{row}"
            if cells.get(address, {}).get("style") != styles["tree_corner"]:
                cells[address] = {"value": None, "style": styles["tree_vertical"]}
        cells[f"{col_letter(trunk)}{child_row}"] = {"value": None, "style": styles["tree_corner"]}
        cells[f"{col_letter(child_col + 1)}{child_row}"] = {"value": None, "style": styles["branch_label"]}
    cells[f"{col_letter(child_col)}{child_row}"] = {"value": label, "style": styles["branch_label"]}
    if prob_formula is not None:
        cells[f"{col_letter(child_col)}{child_row + 1}"] = {"formula": prob_formula, "style": styles["probability"]}


def parameter_header(profile: dict | None = None) -> dict[str, dict]:
    return deepcopy((profile or load_profile())["parameter_header"])


def parameter_style(column: str, group: str | None = None, uncertainty: str | None = None, profile: dict | None = None) -> int:
    # All four supplied references use the same style by column, not by diagnosis.
    profile = profile or load_profile()
    return int(profile["styles"]["parameter_active" if column in {"B", "C", "D", "F"} else "parameter_input"])


def label_width(text: str, profile: dict | None = None) -> float:
    """Content-driven Calibri Bold width; no example strings or case IDs."""
    profile = profile or load_profile()
    metrics = profile["font_metrics"]
    advance = sum(metrics["advances"].get(str(ord(ch)), metrics["fallback_advance"]) for ch in text)
    raw = (advance + metrics["trailing_zero_ink_right"]) / metrics["normal_zero_advance"]
    return min(255.0, max(profile["geometry"]["default_column_width"], math.floor(raw * 256 + metrics["quantization_offset"]) / 256))


def model_columns(cells: dict[str, dict], deepest_node_col: int, profile: dict | None = None) -> list[dict]:
    profile = profile or load_profile()
    styles = profile["styles"]
    default = profile["geometry"]["default_column_width"]
    # Preserve baseline column formats at AF/AG while all tree columns use the
    # reference's default background and label-width / gutter-width pattern.
    overrides = {32: {"width": default, "style": 73}, 33: {"width": default, "style": 72}}
    for col in range(4, deepest_node_col + 1, 3):
        labels = [str(data["value"]) for address, data in cells.items() if split_address(address)[1] == col and split_address(address)[0] >= 6 and data.get("value") is not None and data.get("style") == styles["branch_label"]]
        overrides[col] = {"width": max((label_width(t, profile) for t in labels), default=default), "style": 14, "customWidth": "true", "bestFit": "true"}
        overrides[col - 1] = {"width": profile["geometry"]["tree_gutter_width"], "style": 14, "customWidth": "true"}
    columns = []
    start = 1
    for col in sorted(overrides):
        if start < col:
            columns.append({"min": start, "max": col - 1, "style": 14, "width": default})
        columns.append({"min": col, "max": col, **overrides[col]})
        start = col + 1
    if start <= 16384:
        columns.append({"min": start, "max": 16384, "style": 14, "width": default})
    return columns
