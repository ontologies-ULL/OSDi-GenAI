"""Select an exact local OSDi schema without fetching or rewriting imports."""
from pathlib import Path
import hashlib
from ontology import OSDI, OntologyError, parse_turtle, osdi_import_identifiers, osdi_version_declaration, COMPATIBILITY_PROFILE, AUDITED_SCHEMA_HASHES

SCHEMA_FILES={'1.0':'schemas/OSDi-1.0.ttl','1.1':'OSDi.ttl'}
SCHEMA_URLS={'1.0':'https://github.com/ontologies-ULL/OSDi/raw/refs/heads/main/docs/1.0/ontology.ttl',
             '1.1':'https://github.com/ontologies-ULL/OSDi/raw/refs/heads/main/docs/1.1/ontology.ttl'}


def select_schema(case_path, schema_path=None, package=None, compatibility_profile=None):
    package=Path(package) if package is not None else Path(__file__).resolve().parents[1]
    triples=parse_turtle(case_path)
    imports=osdi_import_identifiers(triples)
    base=OSDI.rstrip('#')
    versioned=[x for x in imports if x!=base]
    if len(versioned)>1:
        raise OntologyError('Ambiguous mixed OSDi version imports: '+', '.join(versioned))
    requested=None
    if versioned:
        accepted={base+'/'+version:version for version in SCHEMA_FILES}
        if versioned[0] not in accepted:
            raise OntologyError('Unsupported OSDi version import: '+versioned[0]+'. No import aliases or version rewrites are applied.')
        requested=accepted[versioned[0]]
    case_declaration=osdi_version_declaration(triples,'case')
    if case_declaration['version']:
        if case_declaration['version'] not in SCHEMA_FILES:
            raise OntologyError('Unsupported embedded OSDi version declaration: '+case_declaration['version'])
        if requested and requested!=case_declaration['version']:
            raise OntologyError('Conflicting OSDi import and embedded version declaration in case.')
        requested=requested or case_declaration['version']
    compatibility=None
    if compatibility_profile is not None:
        if compatibility_profile!=COMPATIBILITY_PROFILE:
            raise OntologyError('Unknown compatibility profile: '+str(compatibility_profile))
        if versioned!=[base+'/1.0']:
            raise OntologyError('Compatibility profile requires the exact declared OSDi 1.0 import.')
        compatibility={'profile':COMPATIBILITY_PROFILE,'explicit_opt_in':True,
            'declared_version':'1.0','effective_version':'1.1',
            'declared_schema_path':str((package/SCHEMA_FILES['1.0']).resolve()),
            'status':'PENDING_GATE','imports_rewritten':False,'semantic_equivalence_claimed':False}
    if schema_path is None:
        selected='1.1' if compatibility is not None else requested or '1.1'
        path=(package/SCHEMA_FILES[selected]).resolve()
        reason=('EXACT_VERSION_IMPORT' if versioned else 'EMBEDDED_OSDI_VERSION_DECLARATION'
                if case_declaration['version'] else 'BASE_IMPORT_DEFAULT_1_1'
                if imports else 'NO_OSDI_VERSION_IMPORT_DEFAULT_1_1')
        mode='auto'
    else:
        path=Path(schema_path).resolve()
        mode='explicit';reason='EXPLICIT_SCHEMA'
    if compatibility is not None:reason='EXPLICIT_COMPATIBILITY_PROFILE'
    if not path.is_file():
        raise OntologyError('Selected local schema is unavailable: '+str(path)+'. Supply the exact schema; no fallback to another version is allowed.')
    declaration=osdi_version_declaration(parse_turtle(path),'selected schema')
    selected=declaration['version']
    if selected not in SCHEMA_FILES:
        raise OntologyError('Unsupported or missing declared OSDi schema version: '+str(selected)+'. An audited 1.0 or 1.1 schema is required.')
    if compatibility is not None and selected!='1.1':
        raise OntologyError('Compatibility profile requires effective schema 1.1; an explicit --schema is never overridden.')
    if requested and selected!=requested and compatibility is None:
        raise OntologyError('Case imports a different version of OSDi than the explicit schema: '+requested+' versus '+selected+'. The explicit selection is never overridden.')
    if versioned and declaration['version_iri']!=versioned[0] and compatibility is None:
        raise OntologyError('Selected schema lacks the exact imported OSDi versionIRI; no aliases are applied.')
    known_path=(package/SCHEMA_FILES[selected]).resolve()
    selection={'mode':mode,'reason':reason,'requested_osdi_imports':imports,
                'selected_version':selected,'schema_path':str(path),
                'schema_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                'source_url':SCHEMA_URLS[selected] if path==known_path else None,
                'imports_rewritten':False,'remote_schema_fetched':False}
    if compatibility is not None:
        native_path=Path(compatibility['declared_schema_path'])
        if not native_path.is_file():raise OntologyError('Audited native 1.0 schema is required for compatibility evidence.')
        native_hash=hashlib.sha256(native_path.read_bytes()).hexdigest()
        if native_hash!=AUDITED_SCHEMA_HASHES['1.0'] or selection['schema_sha256']!=AUDITED_SCHEMA_HASHES['1.1']:
            raise OntologyError('Compatibility profile requires the unchanged audited native 1.0 / target 1.1 schema pair.')
        compatibility.update(declared_schema_sha256=native_hash,effective_schema_sha256=selection['schema_sha256'],effective_schema_path=str(path))
        selection['compatibility_profile']=compatibility
    return path,selection
