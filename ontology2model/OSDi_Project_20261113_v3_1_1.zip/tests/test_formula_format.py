"""Regression guards for authored arithmetic versus Excel syntax."""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'engine'))
from ai_contract import check_expression, PlanError
from plan_renderer import canonical_formula, PlanRenderError


class FormulaFormatTests(unittest.TestCase):
    def test_python_only_and_ambiguous_power_rejected(self):
        for expression in ('Risk ** 1', 'Risk // 1', 'Risk % 1',
                           'Risk ^ Risk ^ 1', '-Risk ^ 1', '(Risk ^ 1) ^ 1'):
            with self.subTest(expression=expression):
                with self.assertRaises(PlanError):
                    check_expression(expression, {'Risk'})

    def test_discount_power_uses_explicit_grouping_and_excel_operator(self):
        expression = '(1 + discountCosts) ^ Start'
        self.assertEqual(check_expression(expression, {'discountCosts', 'Start'}), {'discountCosts', 'Start'})
        self.assertEqual(canonical_formula(expression), expression)

    def test_formula_format_is_mechanical_and_idempotent(self):
        examples = {
            'SUM(ChargeA,ChargeB)': 'SUM(ChargeA, ChargeB)',
            'MIN(Life,timeHorizon)': 'MIN(Life, timeHorizon)',
            'PV(discountQALE,{life},-Base)-SUM(PV(discountQALE,{life},-Loss))':
                'PV(discountQALE,{life},-Base) - PV(discountQALE,{life},-Loss)',
            'PRODUCT(Risk)': 'Risk',
        }
        for original, expected in examples.items():
            with self.subTest(original=original):
                self.assertEqual(canonical_formula(original), expected)
                self.assertEqual(canonical_formula(expected), expected)

    def test_formatter_never_accepts_external_references_or_python_power(self):
        for expression in ('Risk ** 1', 'OtherSheet!A1', '__import__("os")'):
            with self.subTest(expression=expression):
                with self.assertRaises(PlanRenderError):
                    canonical_formula(expression)


if __name__ == '__main__':
    unittest.main()
