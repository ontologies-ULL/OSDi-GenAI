"""Artificial two-manifestation examples; no real-case tree or workbook oracle."""
from copy import deepcopy

from synthetic_support import (SyntheticCase, EX, OSDI, RDF, PACKAGE, case_text,
                               explicit_plan, fact_id, prepare_context, validate_plan)
from semantic_guards import validate_semantic_structure
from ai_contract import GROUP_ORDER


def instant_death_case(replacement=False, shared_cost=False):
    text = case_text() + '''
ex:Condition o:hasEffect ex:OnsetDeath ; o:hasProgressionElement ex:SecondManifestation .
ex:OnsetDeath a o:InstantDeathEffect ; o:hasEffectMagnitude ex:Mortality ; o:hasCost ex:DeathCost .
ex:Mortality a o:Parameter, o:DeterministicParameter ; o:hasExpectedValue 0.1 ; o:hasDataItemType o:DI_Probability .
ex:Progression o:hasCost ex:FirstCost ; o:hasUtility ex:FirstDisutility .
ex:SecondManifestation a o:ChronicManifestation ; o:hasRiskCharacterization ex:SecondRisk ; o:hasCost ex:SecondCost ; o:hasUtility ex:SecondDisutility .
ex:SecondRisk a o:Parameter, o:DeterministicParameter ; o:hasExpectedValue 0.4 ; o:hasDataItemType o:DI_Probability .
ex:FirstCost a o:Cost, o:DeterministicParameter ; o:hasExpectedValue 12 ; o:hasYear 2031 ; o:appliesOneTime true ; o:hasDataItemType o:Currency_Euro .
ex:SecondCost a o:Cost, o:DeterministicParameter ; o:hasExpectedValue 23 ; o:hasYear 2031 ; o:appliesOneTime false ; o:hasDataItemType o:Currency_Euro .
ex:DeathCost a o:Cost, o:DeterministicParameter ; o:hasExpectedValue 4 ; o:hasYear 2031 ; o:appliesOneTime true ; o:hasDataItemType o:Currency_Euro .
ex:FirstDisutility a o:Utility, o:DeterministicParameter ; o:hasExpectedValue 0.1 ; o:isDisutility true ; o:hasDataItemType o:DI_Continuous_Variable .
ex:SecondDisutility a o:Utility, o:DeterministicParameter ; o:hasExpectedValue 0.2 ; o:isDisutility true ; o:hasDataItemType o:DI_Continuous_Variable .
'''
    if replacement:
        text += '''
ex:ArmA o:hasEffect ex:MortalityReplacement .
ex:MortalityReplacement a o:Effect ; o:affects ex:Mortality ; o:hasEffectMagnitude ex:ReducedMortality .
ex:ReducedMortality a o:Parameter, o:DeterministicParameter ; o:hasExpectedValue 0.02 ; o:hasDataItemType o:DI_Continuous_Variable .
'''
    if shared_cost:
        text += 'ex:ArmA o:hasCost ex:FirstCost .\n'
    return text


def onset_plan(context, replacement=False):
    """Hand-authored onset death then two manifestations; only IDs are bound."""
    plan = explicit_plan(context)

    def evidence(*subjects):
        return [f['id'] for f in context['facts'] if f['subject'] in {EX + s for s in subjects}]

    for name, group, value, once in [
        ('Mortality', 'RISK', 0.1, None), ('SecondRisk', 'RISK', 0.4, None),
        ('FirstCost', 'COST', 12, True), ('SecondCost', 'COST', 23, False),
        ('DeathCost', 'COST', 4, True), ('FirstDisutility', 'DISUTILITY', 0.1, None),
        ('SecondDisutility', 'DISUTILITY', 0.2, None),
    ] + ([('ReducedMortality', 'UNKNOWN', 0.02, None)] if replacement else []):
        parameter = {'iri': EX + name, 'id': name, 'name': name, 'group': group,
                     'uncertainty': 'DETERMINISTIC', 'expected': value,
                     'year': 2031 if group == 'COST' else None, 'description': '',
                     'source': 'Unknown', 'one_time': once, 'distribution': None,
                     'evidence': evidence(name),
                     'value_evidence': fact_id(context, EX + name, OSDI + 'hasExpectedValue')}
        if group == 'COST':
            parameter['year_evidence'] = fact_id(context, EX + name, OSDI + 'hasYear')
            parameter['one_time_evidence'] = fact_id(context, EX + name, OSDI + 'appliesOneTime')
        plan['parameters'].append(parameter)
    for arm in plan['interventions']:
        prefix = arm['iri'].rsplit('/', 1)[-1]
        disease = arm['children'][0]
        disease.update(role='disease', entity=EX + 'Condition',
                       state={'disease': True, 'dead': False}, active_progressions=[])
        manifestations = disease['children']
        for index, first in enumerate(manifestations):
            first.update(role='manifestation', entity=EX + 'Progression')
            first.pop('payoffs')
            first_active = index == 0
            second_children = []
            for second_active in (True, False):
                active = ([EX + 'Progression'] if first_active else []) + ([EX + 'SecondManifestation'] if second_active else [])
                cost = ('FirstCost' if first_active else '0') + (' + PV(discountCosts,{life},-SecondCost)' if second_active else '')
                utility = 'BaselineUtility' + (' - FirstDisutility' if first_active else '') + (' - SecondDisutility' if second_active else '')
                leaf = {'id': prefix + '_second_' + str(index) + '_' + str(second_active),
                        'label': 'Second manifestation' if second_active else 'No second manifestation',
                        'role': 'manifestation', 'entity': EX + 'SecondManifestation',
                        'active_progressions': active, 'state': {'disease': True, 'dead': False},
                        'evidence': evidence('SecondManifestation', 'SecondRisk'),
                        'payoffs': {'cost': cost, 'life': 'MIN(Life,timeHorizon)',
                                    'le': 'PV(discountLE,{life},-1)',
                                    'qale': 'PV(discountQALE,{life},-(' + utility + '))'}}
                leaf.update(probability='SecondRisk') if second_active else leaf.update(residual=True)
                second_children.append(leaf)
            first['children'] = second_children
        split_evidence = evidence('Condition', 'OnsetDeath', 'Mortality')
        death = {'id': prefix + '_onset_death', 'label': 'Death at onset',
                 'role': 'instant_death', 'entity': EX + 'Condition', 'effect': EX + 'OnsetDeath',
                 'probability': 'Mortality', 'active_progressions': [],
                 'state': {'disease': True, 'dead': True}, 'evidence': list(split_evidence),
                 'payoffs': {'cost': 'DeathCost', 'life': '0', 'le': '0', 'qale': '0'}}
        survival = {'id': prefix + '_onset_survival', 'label': 'Survives onset',
                    'role': 'survival', 'entity': EX + 'Condition', 'effect': EX + 'OnsetDeath',
                    'residual': True, 'active_progressions': [],
                    'state': {'disease': True, 'dead': False}, 'evidence': list(split_evidence),
                    'children': manifestations}
        disease['children'] = [death, survival]
        if replacement and prefix == 'ArmA':
            death['probability'] = 'ReducedMortality'
            replacement_evidence = evidence('ArmA', 'MortalityReplacement', 'ReducedMortality')
            death['evidence'] += replacement_evidence
            plan['decisions'].append({'topic': 'replacement',
                                     'explanation': 'The generic intervention effect replaces onset mortality with its linked magnitude.',
                                     'evidence': replacement_evidence})
    plan['parameters'].sort(key=lambda p: (GROUP_ORDER[p['group']], p['id']))
    return plan


class InstantDeathSemantics(SyntheticCase):
    def setUp(self):
        super().setUp()
        self.load_case()

    def load_case(self, replacement=False, shared_cost=False, transform=None):
        text = instant_death_case(replacement, shared_cost)
        self.case = self.root / 'artificial_onset.ttl'
        self.case.write_text(transform(text) if transform else text, encoding='utf-8')
        self.context = prepare_context(self.case, None, None, PACKAGE)
        self.plan = onset_plan(self.context, replacement)

    def disease(self, plan=None):
        return (plan or self.plan)['interventions'][0]['children'][0]

    def death(self, plan=None):
        return self.disease(plan)['children'][0]

    def reject(self, mutation, message=None):
        plan = deepcopy(self.plan)
        mutation(plan)
        with self.assertRaisesRegex(ValueError, message or 'Semantic guard'):
            validate_semantic_structure(plan, self.context)

    def test_explicit_death_before_two_manifestations_is_valid_and_unmodified(self):
        original_plan, original_context = deepcopy(self.plan), deepcopy(self.context)
        report = validate_semantic_structure(self.plan, self.context)
        self.assertEqual(report['validated_splits'], 2)
        self.assertEqual(report['applicable_effects'], 1)
        self.assertEqual(report['semantic_completeness'], 'NOT_PROVEN')
        self.assertEqual(self.plan, original_plan)
        self.assertEqual(self.context, original_context)
        validate_plan(self.plan, self.context)

    def test_death_last_cross_product_is_rejected(self):
        def death_last(plan):
            root = self.disease(plan)
            death, survival = root['children']
            progressions = survival['children']
            leaf = progressions[0]['children'][0]
            late_survival = deepcopy(survival)
            late_survival.pop('children')
            late_survival['payoffs'] = leaf.pop('payoffs')
            leaf['children'] = [death, late_survival]
            root['children'] = progressions
        self.reject(death_last, 'immediately split')

    def test_omitted_effect_is_rejected_even_with_coverage_used(self):
        self.reject(lambda p: self.disease(p).update(children=self.disease(p)['children'][1]['children']))

    def test_removed_roles_cannot_disable_guard(self):
        def remove_roles(plan):
            for arm in plan['interventions']:
                arm['children'][0].pop('role')
        self.reject(remove_roles, 'explicit disease role')

    def test_missing_split_in_one_intervention_is_rejected(self):
        self.reject(lambda p: p['interventions'][1]['children'][0].pop('role'))

    def test_false_death_and_disease_states_are_rejected(self):
        for state in ({'dead': False, 'disease': True}, {'dead': True, 'disease': False},
                      {'dead': 1, 'disease': True}):
            with self.subTest(state=state):
                self.reject(lambda p: self.death(p).update(state=state))

    def test_false_disease_parent_is_rejected(self):
        self.reject(lambda p: self.disease(p).update(state={'disease': False}))

    def test_malformed_state_is_a_controlled_error(self):
        self.reject(lambda p: self.death(p).update(state=['dead']))

    def test_death_requires_empty_active_progressions(self):
        self.reject(lambda p: self.death(p).update(active_progressions=[EX + 'Progression']))
        self.reject(lambda p: self.death(p).pop('active_progressions'))

    def test_death_cannot_continue_into_children(self):
        self.reject(lambda p: self.death(p).update(children=[deepcopy(p['interventions'][0]['children'][1])]))

    def test_positive_life_or_disguised_zero_is_rejected(self):
        for life in ('Life', 'MIN(Life,timeHorizon)', 'Life*0'):
            with self.subTest(life=life):
                self.reject(lambda p: self.death(p)['payoffs'].update(life=life))

    def test_explicit_horizon_clipped_zero_is_valid(self):
        self.death()['payoffs']['life'] = 'MIN(0, timeHorizon)'
        validate_semantic_structure(self.plan, self.context)

    def test_progression_payoffs_are_rejected_even_when_zero(self):
        for key, formula in (('cost', 'FirstCost'), ('cost', 'SecondCost * 0'),
                             ('qale', 'FirstDisutility * 0'), ('qale', 'SecondDisutility')):
            with self.subTest(key=key, formula=formula):
                self.reject(lambda p: self.death(p)['payoffs'].update({key: formula}), 'costs or utilities')

    def test_instant_death_own_cost_is_allowed(self):
        self.assertEqual(self.death()['payoffs']['cost'], 'DeathCost')
        validate_semantic_structure(self.plan, self.context)

    def test_shared_intervention_cost_requires_its_own_evidence(self):
        self.load_case(shared_cost=True)
        self.death()['payoffs']['cost'] = 'FirstCost + DeathCost'
        with self.assertRaises(ValueError):
            validate_semantic_structure(self.plan, self.context)
        self.death()['evidence'].append(fact_id(self.context, EX + 'ArmA', OSDI + 'hasCost', EX + 'FirstCost'))
        validate_semantic_structure(self.plan, self.context)

    def test_wrong_entity_or_effect_is_rejected(self):
        self.reject(lambda p: self.death(p).update(entity=EX + 'Progression'))
        self.reject(lambda p: self.death(p).update(effect=EX + 'OtherDeath'))

    def test_death_and_survival_require_link_and_type_evidence(self):
        ids = [fact_id(self.context, EX + 'Condition', OSDI + 'hasEffect'),
               fact_id(self.context, EX + 'OnsetDeath', OSDI + 'hasEffectMagnitude'),
               fact_id(self.context, EX + 'OnsetDeath', RDF + 'type', OSDI + 'InstantDeathEffect')]
        for child in (0, 1):
            for fid in ids:
                with self.subTest(child=child, fid=fid):
                    self.reject(lambda p: self.disease(p)['children'][child]['evidence'].remove(fid))

    def test_survival_must_be_complement_and_alive(self):
        self.reject(lambda p: self.disease(p)['children'][1].update(residual=False))
        self.reject(lambda p: self.disease(p)['children'][1]['state'].update(dead=True))

    def test_arithmetic_on_mortality_cannot_be_invented(self):
        for probability in ('1-Mortality', 'Mortality*Risk', 'Mortality/Mortality', '0', 'Risk'):
            with self.subTest(probability=probability):
                self.reject(lambda p: self.death(p).update(probability=probability))

    def test_progression_ancestor_is_detected_by_source_risk_even_without_role(self):
        def wrap(plan):
            root = self.disease(plan)
            plan['interventions'][0]['children'][0] = {
                'id': 'unmarked_progression', 'probability': 'Risk', 'children': [root]}
        self.reject(wrap, 'cannot follow a progression')

    def test_diseased_route_cannot_bypass_onset_split(self):
        self.reject(lambda p: p['interventions'][0]['children'][1]['state'].update(disease=True), 'bypasses')

    def test_surviving_route_cannot_claim_absence_of_disease(self):
        self.reject(lambda p: self.disease(p)['children'][1]['children'][0]['state'].update(disease=False))

    def test_explicit_mortality_replacement_is_valid(self):
        self.load_case(replacement=True)
        validate_semantic_structure(self.plan, self.context)
        validate_plan(self.plan, self.context)

    def test_parameter_nature_without_parameter_role_is_valid(self):
        self.load_case(transform=lambda t: t.replace('ex:Mortality a o:Parameter, o:DeterministicParameter',
                                                     'ex:Mortality a o:DeterministicParameter'))
        validate_semantic_structure(self.plan, self.context)
        validate_plan(self.plan, self.context)

    def test_second_order_nature_without_parameter_role_is_valid(self):
        def uncertain(text):
            return text.replace('ex:Mortality a o:Parameter, o:DeterministicParameter',
                                'ex:Mortality a o:SecondOrderUncertaintyParameter') + '''
ex:Mortality o:hasUncertaintyCharacterization ex:MortalityDistribution .
ex:MortalityDistribution a o:BetaDistributionExpression ; o:hasAlfaParameter 1 ; o:hasBetaParameter 9 .
'''
        self.load_case(transform=uncertain)
        parameter = next(p for p in self.plan['parameters'] if p['id'] == 'Mortality')
        parameter.update(uncertainty='SECOND_ORDER',
                         distribution={'iri': EX + 'MortalityDistribution', 'kind': 'BETA',
                                       'parameters': {'hasAlfaParameter': 1, 'hasBetaParameter': 9}},
                         distribution_evidence={prop: fact_id(self.context, EX + 'MortalityDistribution', OSDI + prop)
                                                for prop in ('hasAlfaParameter', 'hasBetaParameter')})
        parameter['evidence'] += [f['id'] for f in self.context['facts'] if f['subject'] == EX + 'MortalityDistribution']
        validate_semantic_structure(self.plan, self.context)
        validate_plan(self.plan, self.context)

    def test_replacement_cannot_be_applied_to_other_intervention(self):
        self.load_case(replacement=True)
        self.reject(lambda p: p['interventions'][1]['children'][0]['children'][0].update(probability='ReducedMortality'))

    def test_replacement_cannot_be_ignored_or_lose_decision(self):
        self.load_case(replacement=True)
        self.reject(lambda p: self.death(p).update(probability='Mortality'))
        self.reject(lambda p: p.update(decisions=[d for d in p['decisions'] if d['topic'] != 'replacement']))

    def test_replacement_must_affect_original_mortality_magnitude(self):
        self.load_case(replacement=True, transform=lambda t: t.replace('o:affects ex:Mortality', 'o:affects ex:Risk'))
        with self.assertRaises(ValueError):
            validate_semantic_structure(self.plan, self.context)

    def test_progression_owned_death_is_explicitly_unsupported(self):
        self.load_case(transform=lambda t: t.replace('ex:Condition o:hasEffect ex:OnsetDeath', 'ex:Progression o:hasEffect ex:OnsetDeath'))
        with self.assertRaisesRegex(ValueError, 'progression-owned'):
            validate_semantic_structure(self.plan, self.context)

    def test_multiple_death_effects_are_not_combined_implicitly(self):
        self.load_case(transform=lambda t: t + '\nex:Condition o:hasEffect ex:AnotherDeath .\nex:AnotherDeath a o:InstantDeathEffect ; o:hasEffectMagnitude ex:Mortality .\n')
        with self.assertRaisesRegex(ValueError, 'multiple disease-level death effects'):
            validate_semantic_structure(self.plan, self.context)

    def test_temporal_evidence_cannot_silently_disable_guard(self):
        self.load_case(transform=lambda t: t + '\nex:OnsetDeath o:hasNext ex:Progression .\n')
        with self.assertRaisesRegex(ValueError, 'temporal sequencing'):
            validate_semantic_structure(self.plan, self.context)

    def test_no_instant_death_retains_existing_contract(self):
        plan, context = self.inputs()
        report = validate_semantic_structure(plan, context)
        self.assertEqual(report['applicable_effects'], 0)
        self.assertEqual(report['validated_splits'], 0)
        validate_plan(plan, context)
