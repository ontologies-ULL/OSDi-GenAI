"""Source-grounding and expression checks do not manufacture a semantic model."""
from copy import deepcopy
from synthetic_support import *


class Contract(SyntheticCase):
    def setUp(self):
        super().setUp()
        self.inputs()

    def reject(self, mutation):
        plan = deepcopy(self.plan)
        mutation(plan)
        with self.assertRaises(ValueError):
            validate_plan(plan, self.context)

    def test_valid_explicit_plan(self):
        report = validate_plan(self.plan, self.context)
        self.assertIsInstance(report, dict)
        self.assertEqual(report['semantic_completeness'], 'NOT_PROVEN')

    def test_case_hash_must_match(self):
        self.reject(lambda p: p['source'].update(case_sha256='0' * 64))

    def test_schema_hash_must_match(self):
        self.reject(lambda p: p['source'].update(schema_sha256='0' * 64))

    def test_unknown_model_is_rejected(self):
        self.reject(lambda p: p.update(model_iri=EX + 'Absent'))

    def test_false_expected_value_is_rejected(self):
        self.reject(lambda p: p['parameters'][0].update(expected=22))

    def test_other_subject_cannot_supply_value_evidence(self):
        self.reject(lambda p: p['parameters'][0].update(value_evidence=p['parameters'][1]['value_evidence']))

    def test_numeric_boolean_is_not_a_parameter_value(self):
        self.reject(lambda p: p['parameters'][0].update(expected=False))

    def test_nonfinite_expected_is_rejected(self):
        self.reject(lambda p: p['parameters'][0].update(expected=float('nan')))

    def test_missing_source_evidence_is_rejected(self):
        self.reject(lambda p: p['parameters'][0].pop('value_evidence'))

    def test_absent_coverage_fact_is_rejected(self):
        self.reject(lambda p: p['coverage'][0]['facts'].pop())

    def test_duplicate_coverage_fact_is_rejected(self):
        self.reject(lambda p: p['coverage'][0]['facts'].append(p['coverage'][0]['facts'][0]))

    def test_unknown_coverage_fact_is_rejected(self):
        self.reject(lambda p: p['coverage'][0]['facts'].append('f999999'))

    def test_missing_decision_evidence_is_rejected(self):
        self.reject(lambda p: p['decisions'][0].update(evidence=['f999999']))

    def test_false_setting_value_is_rejected(self):
        self.reject(lambda p: p['settings'].update(timeHorizon=26))

    def test_probabilistic_mode_cannot_silently_activate(self):
        self.reject(lambda p: p['settings'].update(isProbabilistic=1))

    def test_missing_setting_evidence_is_rejected(self):
        self.reject(lambda p: p['settings_evidence'].pop('discountCosts'))

    def test_empty_authorship_is_rejected(self):
        self.reject(lambda p: p.update(authorship={}))

    def test_unresolved_blocker_prevents_generation(self):
        self.reject(lambda p: p['blockers'].append('A dependency remains undecided.'))

    def test_unknown_parameter_reference_is_rejected(self):
        self.reject(lambda p: p['interventions'][0]['children'][0].update(probability='UnknownRisk'))

    def test_malformed_node_is_a_controlled_validation_error(self):
        self.reject(lambda p: p['interventions'][0]['children'].append('not a node'))

    def test_connected_semantics_cannot_be_hidden_as_metadata(self):
        self.reject(lambda p: p['coverage'][0].update(disposition='metadata'))

    def test_connected_semantics_cannot_be_hidden_outside_model(self):
        self.reject(lambda p: p['coverage'][0].update(disposition='outside_model'))

    def test_hidden_numeric_literal_is_rejected(self):
        self.reject(lambda p: p['interventions'][0]['children'][0].update(probability='0.2'))

    def test_attribute_cannot_be_used_as_probability(self):
        self.reject(lambda p: p['interventions'][0]['children'][0].update(probability='1 / Life'))

    def test_cost_cannot_be_used_as_probability_even_when_in_range(self):
        self.inputs(cost=True)
        self.plan['interventions'][0]['children'][0]['probability'] = '1 / VisitCost'
        with self.assertRaises(ValueError):
            validate_plan(self.plan, self.context)

    def test_raw_cell_reference_is_rejected(self):
        self.reject(lambda p: p['interventions'][0]['children'][0].update(probability='A1'))

    def test_other_sheet_reference_is_rejected(self):
        self.reject(lambda p: p['interventions'][0]['children'][0].update(probability='Config!A1'))

    def test_external_formula_function_is_rejected(self):
        self.reject(lambda p: p['interventions'][0]['children'][0].update(probability='WEBSERVICE(1)'))

    def test_python_call_is_rejected(self):
        self.reject(lambda p: p['interventions'][0]['children'][0].update(probability="__import__('os').system('echo injected')"))

    def test_circular_life_placeholder_is_rejected(self):
        self.reject(lambda p: p['interventions'][0]['children'][1]['payoffs'].update(life='{life}'))

    def test_duplicate_parameter_name_is_rejected(self):
        self.reject(lambda p: p['parameters'][1].update(name='age'))

    def test_setting_name_case_variant_cannot_be_parameter(self):
        self.reject(lambda p: p['parameters'][0].update(name='DiscountCosts'))

    def test_out_of_range_source_probability_cannot_hide_in_normalization(self):
        self.case.write_text(case_text().replace('o:hasExpectedValue 0.3', 'o:hasExpectedValue 2'), encoding='utf-8')
        self.context = prepare_context(self.case, None, None, PACKAGE)
        self.plan = explicit_plan(self.context)
        next(p for p in self.plan['parameters'] if p['id'] == 'Risk')['expected'] = 2
        for arm in self.plan['interventions']:
            arm['children'][0]['children'][0]['probability'] = 'Risk / (Risk + Risk)'
        with self.assertRaises(ValueError):
            validate_plan(self.plan, self.context)

    def test_known_payoff_dependency_cannot_be_declared_unresolved(self):
        plan = deepcopy(self.plan)
        plan['settings'].pop('timeHorizon')
        plan['settings_evidence'].pop('timeHorizon')
        plan['unresolved_dependencies'].append('timeHorizon')
        with self.assertRaisesRegex(ValueError, 'Explicit source setting'):
            validate_plan(plan, self.context)

    def test_missing_setting_cannot_be_used_in_probability(self):
        plan = deepcopy(self.plan)
        plan['settings'].pop('discountCosts')
        plan['settings_evidence'].pop('discountCosts')
        plan['unresolved_dependencies'].append('discountCosts')
        plan['interventions'][0]['children'][0]['probability'] = 'discountCosts'
        with self.assertRaises(ValueError):
            validate_plan(plan, self.context)

    def test_wrong_year_evidence_is_rejected(self):
        self.inputs(cost=True)
        p = next(p for p in self.plan['parameters'] if p['id'] == 'VisitCost')
        p['year'] = 2031
        p['year_evidence'] = self.plan['settings_evidence']['studyYear']
        with self.assertRaises(ValueError):
            validate_plan(self.plan, self.context)

    def test_second_order_numeric_evidence_is_checked(self):
        self.inputs(second_order=True)
        validate_plan(self.plan, self.context)
        risk = next(p for p in self.plan['parameters'] if p['id'] == 'Risk')
        risk['distribution']['parameters']['hasAlfaParameter'] = 4
        with self.assertRaises(ValueError):
            validate_plan(self.plan, self.context)

    def test_unknown_distribution_is_rejected(self):
        self.inputs(second_order=True)
        risk = next(p for p in self.plan['parameters'] if p['id'] == 'Risk')
        risk['distribution']['kind'] = 'INVENTED'
        with self.assertRaises(ValueError):
            validate_plan(self.plan, self.context)

    def test_nonidentity_distribution_transform_is_rejected(self):
        self.inputs(second_order=True)
        risk = next(p for p in self.plan['parameters'] if p['id'] == 'Risk')
        risk['distribution']['parameters']['hasScaleParameter'] = 2
        with self.assertRaises(ValueError):
            validate_plan(self.plan, self.context)


class ContinuousEffect(SyntheticCase):
    def setUp(self):
        super().setUp()
        self.case = self.root / 'case.ttl'
        self.case.write_text(case_text() + '''
ex:ArmA o:hasEffect ex:Replacement .
ex:Replacement a o:Effect ; o:affects ex:Risk ; o:hasEffectMagnitude ex:Magnitude .
ex:Magnitude a o:Parameter, o:DeterministicParameter ; o:hasExpectedValue 0.25 ; o:hasDataItemType o:DI_Continuous_Variable .
''', encoding='utf-8')
        self.context = prepare_context(self.case, None, None, PACKAGE)
        self.plan = explicit_plan(self.context)
        magnitude_facts = [f['id'] for f in self.context['facts'] if f['subject'] == EX + 'Magnitude']
        effect_facts = [fact_id(self.context, EX + 'ArmA', OSDI + 'hasEffect'),
                        fact_id(self.context, EX + 'Replacement', OSDI + 'affects'),
                        fact_id(self.context, EX + 'Replacement', OSDI + 'hasEffectMagnitude')]
        self.plan['parameters'].append({'iri': EX + 'Magnitude', 'id': 'Magnitude', 'name': 'Magnitude',
            'group': 'UNKNOWN', 'uncertainty': 'DETERMINISTIC', 'expected': 0.25, 'year': None,
            'description': '', 'source': 'Unknown', 'one_time': None, 'distribution': None,
            'evidence': magnitude_facts,
            'value_evidence': fact_id(self.context, EX + 'Magnitude', OSDI + 'hasExpectedValue')})
        node = self.plan['interventions'][0]['children'][0]['children'][0]
        node['probability'] = 'Magnitude'
        node['evidence'] += effect_facts + magnitude_facts
        self.plan['decisions'].append({'topic': 'replacement',
            'explanation': 'The explicit generic effect replaces this arm risk with the source magnitude under the frozen replacement convention.',
            'evidence': effect_facts})

    def test_continuous_replacement_requires_and_accepts_contextual_evidence(self):
        validate_plan(self.plan, self.context)
        report = self.run_plan()
        self.assertEqual(report['status'], 'GENERATED_STRUCTURALLY_VALIDATED', report)

    def test_continuous_magnitude_cannot_affect_an_unlinked_arm(self):
        self.plan['interventions'][1]['children'][0]['children'][0]['probability'] = 'Magnitude'
        with self.assertRaises(ValueError):
            validate_plan(self.plan, self.context)

    def test_missing_replacement_decision_is_rejected(self):
        self.plan['decisions'] = self.plan['decisions'][:1]
        with self.assertRaises(ValueError):
            validate_plan(self.plan, self.context)
