"""Integration checks for explicit plans, protected XLSM parts and no fallback."""
import ast
from copy import deepcopy
import hashlib
import subprocess
import zipfile
from unittest.mock import patch
from synthetic_support import *
from comparar_dos_hojas import compare
from ooxml import read_allowed_workbook, patch_workbook, SheetSpec, WorkbookContractError
from plan_renderer import render_plan, PlanRenderError


class Generation(SyntheticCase):
    def setUp(self):
        super().setUp()
        self.inputs()

    def success(self, report):
        self.assertEqual(report['status'], 'GENERATED_STRUCTURALLY_VALIDATED', report)

    def test_explicit_plan_generates_six_routes(self):
        report = self.run_plan()
        self.success(report)
        self.assertEqual(report['leaves'], 6)
        self.assertEqual(report['parameters'], 5)
        self.assertTrue(all(abs(p['probability_sum'] - 1) < 1e-12 for p in report['probabilities']))

    def test_only_authorized_parts_change(self):
        report = self.run_plan()
        self.success(report)
        self.assertTrue(report['preservation']['all_protected_payloads_identical'])
        with zipfile.ZipFile(PACKAGE / 'PLANTILLA_BASE.xlsm') as source, zipfile.ZipFile(self.root / 'out' / report['file']) as result:
            self.assertEqual(set(source.namelist()), set(result.namelist()))
            changed = {name for name in source.namelist() if source.read(name) != result.read(name)}
        self.assertEqual(changed, set(report['preservation']['changed_parts']))
        self.assertLessEqual(changed, set(report['preservation']['permitted_parts']))

    def test_source_and_submitted_plan_preserved(self):
        original = self.case.read_bytes()
        report = self.run_plan()
        self.success(report)
        self.assertEqual(self.case.read_bytes(), original)
        submitted = self.root / 'out' / 'submitted.ai-plan.json'
        self.assertEqual(submitted.read_bytes(), (self.root / 'out.plan.json').read_bytes())
        self.assertEqual(hashlib.sha256(submitted.read_bytes()).hexdigest(), report['plan_sha256'])

    def test_rejected_plan_is_preserved_without_xlsm(self):
        self.plan['source']['case_sha256'] = 'bad'
        report = self.run_plan()
        self.assertEqual(report['status'], 'BLOCKED')
        self.assertTrue((self.root / 'out' / 'submitted.ai-plan.json').exists())
        self.assertFalse(list((self.root / 'out').glob('*.xlsm')))

    def test_failed_ir_publication_removes_new_workbook(self):
        original_case = self.case.read_bytes()
        original_write = Path.write_text
        def failing_write(path, *args, **kwargs):
            if path.name.endswith('.ir.json'):
                raise OSError('Injected IR publication failure')
            return original_write(path, *args, **kwargs)
        with patch.object(Path, 'write_text', new=failing_write):
            report = self.run_plan()
        self.assertEqual(report['status'], 'BLOCKED')
        self.assertFalse(list((self.root / 'out').glob('*.xlsm')))
        self.assertFalse(list((self.root / 'out').glob('*.ir.json')))
        self.assertTrue((self.root / 'out' / 'submitted.ai-plan.json').exists())
        self.assertEqual(self.case.read_bytes(), original_case)

    def test_failed_validation_publication_removes_new_workbook_and_ir(self):
        original_case = self.case.read_bytes()
        original_write = Path.write_text
        def failing_write(path, *args, **kwargs):
            if path.name.endswith('.validation.json'):
                raise OSError('Injected validation publication failure')
            return original_write(path, *args, **kwargs)
        with patch.object(Path, 'write_text', new=failing_write):
            with self.assertRaises(OSError):
                self.run_plan()
        self.assertFalse(list((self.root / 'out').glob('*.xlsm')))
        self.assertFalse(list((self.root / 'out').glob('*.ir.json')))
        self.assertTrue((self.root / 'out' / 'submitted.ai-plan.json').exists())
        self.assertEqual(self.case.read_bytes(), original_case)

    def test_existing_run_is_never_overwritten(self):
        first = self.run_plan()
        self.success(first)
        target = self.root / 'out' / first['file']
        original = target.read_bytes()
        with self.assertRaises(ValueError):
            self.run_plan()
        self.assertEqual(target.read_bytes(), original)

    def test_ai_claim_is_not_presented_as_provenance_verification(self):
        report = self.run_plan()
        self.success(report)
        self.assertFalse(report['ai_authorship_verifiable_from_plan_alone'])
        self.assertEqual(report['semantic_completeness'], 'NOT_PROVEN')
        self.assertFalse(report['deterministic_semantic_fallback'])
        self.assertEqual(report['native_excel_recalculation'], 'NOT_RUN')

    def test_node_label_changes_the_written_model(self):
        first = self.run_plan(out='first')
        self.success(first)
        self.plan['interventions'][0]['children'][0]['children'][0]['label'] = 'Explicit altered label'
        second = self.run_plan(out='second')
        self.success(second)
        result = compare(self.root / 'first' / first['file'], self.root / 'second' / second['file'])
        self.assertFalse(result['match'])
        self.assertTrue(any(d.get('sheet') == 'Model' for d in result['differences']))

    def test_repeated_plan_keeps_content_and_geometry(self):
        first = self.run_plan(out='first')
        second = self.run_plan(out='second')
        self.success(first)
        self.success(second)
        result = compare(self.root / 'first' / first['file'], self.root / 'second' / second['file'])
        self.assertTrue(result['match'], result)

    def test_generated_result_name_cannot_shadow_parameter(self):
        self.case.write_text(case_text() + '''
ex:Model o:includesModelItem ex:C_ArmA .
ex:C_ArmA a o:AttributeValueParameter, o:DeterministicParameter ; o:hasExpectedValue 0 .
''', encoding='utf-8')
        self.context = prepare_context(self.case, None, None, PACKAGE)
        self.plan = explicit_plan(self.context)
        self.plan['parameters'].insert(1, {'iri': EX + 'C_ArmA', 'id': 'C_ArmA', 'name': 'C_ArmA',
            'group': 'ATTRIBUTE', 'uncertainty': 'DETERMINISTIC', 'expected': 0, 'year': None,
            'description': '', 'source': 'Unknown', 'one_time': None, 'distribution': None,
            'evidence': [f['id'] for f in self.context['facts'] if f['subject'] == EX + 'C_ArmA'],
            'value_evidence': fact_id(self.context, EX + 'C_ArmA', OSDI + 'hasExpectedValue')})
        report = self.run_plan()
        self.assertEqual(report['status'], 'BLOCKED')
        self.assertIn('collision', report['reason'].lower())

    def test_payoff_changes_are_taken_from_explicit_plan(self):
        compiled, _, _ = render_plan(self.plan)
        self.plan['interventions'][0]['children'][1]['payoffs']['cost'] = '1'
        altered, _, _ = render_plan(self.plan)
        self.assertNotEqual(compiled['cells'], altered['cells'])

    def test_nonunit_sibling_probabilities_are_blocked(self):
        sibling = self.plan['interventions'][0]['children'][1]
        sibling.pop('residual')
        sibling['probability'] = 'Prevalence'
        report = self.run_plan()
        self.assertEqual(report['status'], 'BLOCKED')
        self.assertFalse(list((self.root / 'out').glob('*.xlsm')))

    def test_negative_branch_probability_is_blocked(self):
        self.plan['interventions'][0]['children'][0]['probability'] = '-Prevalence'
        report = self.run_plan()
        self.assertEqual(report['status'], 'BLOCKED')

    def test_duplicate_node_id_is_blocked(self):
        self.plan['interventions'][1]['children'][0]['id'] = self.plan['interventions'][0]['children'][0]['id']
        report = self.run_plan()
        self.assertEqual(report['status'], 'BLOCKED')

    def test_nonterminal_cannot_hide_payoffs(self):
        self.plan['interventions'][0]['children'][0]['payoffs'] = self.plan['interventions'][0]['children'][1]['payoffs']
        report = self.run_plan()
        self.assertEqual(report['status'], 'BLOCKED')

    def test_second_order_keeps_deterministic_mode_and_excel_sampling_formula(self):
        self.inputs(second_order=True)
        report = self.run_plan()
        self.success(report)
        book = read_allowed_workbook(self.root / 'out' / report['file'])
        params = book['sheets']['Parameters']['cells']
        self.assertTrue(any('BETA.INV' in cell.get('formula', '') for cell in params.values()))
        self.assertEqual(report['settings']['isProbabilistic'], 0)

    def test_cost_year_and_cpi_expression_remain_explicit(self):
        self.inputs(cost=True)
        report = self.run_plan()
        self.success(report)
        book = read_allowed_workbook(self.root / 'out' / report['file'])
        params = book['sheets']['Parameters']['cells']
        self.assertTrue(any('VLOOKUP(studyYear,CPI' in cell.get('formula', '') for cell in params.values()))
        self.assertIn('CPI', report['uninspected_dependencies'])

    def test_cli_requires_ai_plan(self):
        process = subprocess.run([sys.executable, '-B', str(PACKAGE / 'generar_desde_plan.py'), '--ttl', str(self.case), '--out', str(self.root / 'no_plan')], capture_output=True, text=True)
        self.assertNotEqual(process.returncode, 0)
        self.assertIn('--plan', process.stderr)
        self.assertFalse((self.root / 'no_plan').exists())

    def test_context_does_not_generate_a_plan(self):
        process = subprocess.run([sys.executable, '-B', str(PACKAGE / 'preparar_contexto.py'), '--ttl', str(self.case), '--out', str(self.root / 'context')], capture_output=True, text=True)
        self.assertEqual(process.returncode, 0, process.stdout + process.stderr)
        self.assertEqual({p.name for p in (self.root / 'context').iterdir()}, {'contexto.json'})
        saved = json.loads((self.root / 'context' / 'contexto.json').read_text(encoding='utf-8'))
        self.assertNotIn('interventions', saved)
        self.assertNotIn('parameters', saved)

    def test_context_refuses_to_overwrite_prior_attempt(self):
        out = self.root / 'context'
        out.mkdir()
        sentinel = out / 'sentinel.txt'
        sentinel.write_text('keep', encoding='utf-8')
        process = subprocess.run([sys.executable, '-B', str(PACKAGE / 'preparar_contexto.py'), '--ttl', str(self.case), '--out', str(out)], capture_output=True, text=True)
        self.assertNotEqual(process.returncode, 0)
        self.assertEqual(sentinel.read_text(), 'keep')

    def test_no_legacy_semantic_compiler_in_package_or_renderer_imports(self):
        self.assertFalse((PACKAGE / 'engine' / 'compiler.py').exists())
        tree = ast.parse((PACKAGE / 'engine' / 'plan_renderer.py').read_text(encoding='utf-8'))
        imports = {n.module for n in ast.walk(tree) if isinstance(n, ast.ImportFrom)}
        self.assertFalse(imports & {'compiler', 'ontology', 'schema_selection', 'ai_contract'})

    def test_only_template_is_bundled_workbook(self):
        self.assertEqual([p.name for p in PACKAGE.rglob('*.xlsm')], ['PLANTILLA_BASE.xlsm'])

    def test_protected_sheet_cannot_be_written(self):
        with self.assertRaises(WorkbookContractError):
            patch_workbook(PACKAGE / 'PLANTILLA_BASE.xlsm', self.root / 'forbidden.xlsm', {'Elsewhere': SheetSpec(cells={'A1': {'value': 1}})})

    def test_writer_cannot_overwrite_template(self):
        with self.assertRaises(WorkbookContractError):
            patch_workbook(PACKAGE / 'PLANTILLA_BASE.xlsm', PACKAGE / 'PLANTILLA_BASE.xlsm', {'Model': SheetSpec(cells={})})

    def test_modern_1_0_case_requires_explicit_compatibility(self):
        self.inputs(version='1.0', compatibility='declared-1.0-modern-1.1')
        report = self.run_plan(compatibility='declared-1.0-modern-1.1')
        self.success(report)
        selection = report['schema_selection']
        self.assertEqual(selection['compatibility_profile']['declared_version'], '1.0')
        self.assertEqual(selection['compatibility_profile']['effective_version'], '1.1')
        self.assertFalse(selection['imports_rewritten'])


if __name__ == '__main__':
    unittest.main()
