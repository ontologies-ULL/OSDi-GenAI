"""Synthetic contract regressions: no clinical reference workbook is involved."""
from copy import deepcopy
from synthetic_support import *
from ai_contract import canonical_parameter_name


ORDER = {g: i for i, g in enumerate(
    ('ATTRIBUTE', 'RISK', 'COST', 'UTILITY', 'DISUTILITY', 'UNKNOWN'))}


class ModelContractGuards(SyntheticCase):
    def setUp(self):
        super().setUp()
        self.inputs()

    def reject(self, edit, message):
        plan = deepcopy(self.plan)
        edit(plan)
        with self.assertRaisesRegex(ValueError, message):
            validate_plan(plan, self.context)

    def test_parameter_identifier_is_bound_to_source(self):
        self.reject(lambda p: p['parameters'][0].update(id='InventedAge'), 'local source identifier')

    def test_legal_but_noncanonical_excel_name_is_rejected(self):
        self.reject(lambda p: p['parameters'][0].update(name='AnotherLegalName'), 'canonical source-name')

    def test_reordered_parameters_are_rejected_not_silently_sorted(self):
        self.reject(lambda p: p['parameters'].reverse(), 'group and local-identifier order')

    def test_canonical_excel_names_cover_references_and_characters(self):
        for source, expected in [('Risk-Value', 'Risk_Value'), ('1stRisk', 'p_1stRisk'),
                                 ('A1', 'p_A1'), ('R1C1', 'p_R1C1'), ('r', 'p_r'),
                                 ('Risk.value', 'Risk.value'), ('Risk_1', 'Risk_1')]:
            with self.subTest(source=source):
                self.assertEqual(canonical_parameter_name(source), expected)

    def test_long_names_block_without_truncation(self):
        with self.assertRaisesRegex(ValueError, '255'):
            canonical_parameter_name('x' * 256)

    def test_explicit_unused_member_still_requires_a_parameter_row(self):
        self.reject(lambda p: p.update(parameters=[x for x in p['parameters'] if x['id'] != 'Age']),
                    'model-member parameters omitted')

    def test_nature_only_explicit_member_is_still_a_parameter(self):
        self.case.write_text(case_text() + '''
ex:Model o:includesModelItem ex:OnlyNature .
ex:OnlyNature a o:DeterministicParameter ; o:hasExpectedValue 2 .
''', encoding='utf-8')
        context = prepare_context(self.case, None, None, PACKAGE)
        plan = explicit_plan(context)
        with self.assertRaisesRegex(ValueError, 'model-member parameters omitted'):
            validate_plan(plan, context)
        plan['parameters'].append({'iri': EX + 'OnlyNature', 'id': 'OnlyNature', 'name': 'OnlyNature',
            'group': 'UNKNOWN', 'uncertainty': 'DETERMINISTIC', 'expected': 2, 'year': None,
            'description': '', 'source': 'Unknown', 'one_time': None, 'distribution': None,
            'evidence': [f['id'] for f in context['facts'] if f['subject'] == EX + 'OnlyNature'],
            'value_evidence': fact_id(context, EX + 'OnlyNature', OSDI + 'hasExpectedValue')})
        validate_plan(plan, context)

    def test_reachable_unused_nonmember_is_not_a_parameter_row(self):
        self.case.write_text(case_text().replace(', ex:Age .', ' .'), encoding='utf-8')
        context = prepare_context(self.case, None, None, PACKAGE)
        plan = explicit_plan(context)
        with self.assertRaisesRegex(ValueError, 'evidence-only items'):
            validate_plan(plan, context)
        plan['parameters'] = [p for p in plan['parameters'] if p['id'] != 'Age']
        validate_plan(plan, context)

    def test_formula_referenced_nonmembers_remain_parameters(self):
        self.assertNotIn(EX + 'Life', self.context['model_members'][EX + 'Model'])
        validate_plan(self.plan, self.context)

    def test_explicit_settings_cannot_be_silently_omitted(self):
        def omit(plan):
            del plan['settings']['discountCosts']
            del plan['settings_evidence']['discountCosts']
        self.reject(omit, 'Explicit source setting')

    def test_known_setting_cannot_be_marked_unresolved(self):
        def omit(plan):
            del plan['settings']['discountLE']
            del plan['settings_evidence']['discountLE']
            plan['unresolved_dependencies'].append('discountLE')
        self.reject(omit, 'Explicit source setting')

    def test_actually_absent_setting_can_remain_declared_unresolved(self):
        self.case.write_text(case_text().replace(' ; o:hasTimeHorizon 25', ''), encoding='utf-8')
        context = prepare_context(self.case, None, None, PACKAGE)
        plan = explicit_plan(context, missing_settings=('timeHorizon',))
        report = validate_plan(plan, context)
        self.assertEqual(report['unresolved_dependencies'], ['timeHorizon'])

    def test_unclassified_source_parameter_requires_unknown_group(self):
        self.case.write_text(case_text() + '''
ex:Model o:includesModelItem ex:Factor .
ex:Factor a o:Parameter, o:DeterministicParameter ; o:hasExpectedValue 2 ; o:hasDataItemType o:DI_Continuous_Variable .
''', encoding='utf-8')
        context = prepare_context(self.case, None, None, PACKAGE)
        plan = explicit_plan(context)
        row = {'iri': EX + 'Factor', 'id': 'Factor', 'name': 'Factor', 'group': 'UNKNOWN',
               'uncertainty': 'DETERMINISTIC', 'expected': 2, 'year': None,
               'description': '', 'source': 'Unknown', 'one_time': None, 'distribution': None,
               'evidence': [f['id'] for f in context['facts'] if f['subject'] == EX + 'Factor'],
               'value_evidence': fact_id(context, EX + 'Factor', OSDI + 'hasExpectedValue')}
        plan['parameters'].append(row)
        validate_plan(plan, context)
        row['group'] = 'RISK'
        plan['parameters'].sort(key=lambda p: (ORDER[p['group']], p['id']))
        with self.assertRaisesRegex(ValueError, 'UNKNOWN group'):
            validate_plan(plan, context)

    def test_canonical_schema_alias_satisfies_explicit_membership(self):
        self.case.write_text(case_text() + '\nex:Model o:includesModelItem o:ConstantProbability1 .\no:ConstantProbability1 a owl:NamedIndividual .\n', encoding='utf-8')
        context = prepare_context(self.case, None, None, PACKAGE)
        plan = explicit_plan(context)
        subject = OSDI + 'Constant_Probability1'
        rows = [f for f in context['schema_evidence'] if f['subject'] == subject]
        self.assertEqual(context['aliases'][OSDI + 'ConstantProbability1'], subject)
        plan['parameters'].append({'iri': subject, 'id': 'Constant_Probability1',
            'name': 'Constant_Probability1', 'group': 'RISK', 'uncertainty': 'DETERMINISTIC',
            'expected': 1, 'year': None, 'description': '', 'source': 'Unknown',
            'one_time': None, 'distribution': None, 'evidence': [f['id'] for f in rows],
            'value_evidence': next(f['id'] for f in rows if f['predicate'] == OSDI + 'hasExpectedValue')})
        plan['parameters'].sort(key=lambda p: (ORDER[p['group']], p['id']))
        validate_plan(plan, context)

    def test_replacement_target_can_remain_evidence_only(self):
        self.case.write_text(case_text() + '''
ex:ArmA o:hasEffect ex:Replacement .
ex:ArmB o:hasEffect ex:Replacement .
ex:Replacement a o:Effect ; o:affects ex:Risk ; o:hasEffectMagnitude ex:Magnitude .
ex:Magnitude a o:Parameter, o:DeterministicParameter ; o:hasExpectedValue 0.25 ; o:hasDataItemType o:DI_Continuous_Variable .
''', encoding='utf-8')
        context = prepare_context(self.case, None, None, PACKAGE)
        plan = explicit_plan(context)
        plan['parameters'] = [p for p in plan['parameters'] if p['id'] != 'Risk']
        magnitude_facts = [f['id'] for f in context['facts'] if f['subject'] == EX + 'Magnitude']
        plan['parameters'].append({'iri': EX + 'Magnitude', 'id': 'Magnitude', 'name': 'Magnitude',
            'group': 'UNKNOWN', 'uncertainty': 'DETERMINISTIC', 'expected': 0.25, 'year': None,
            'description': '', 'source': 'Unknown', 'one_time': None, 'distribution': None,
            'evidence': magnitude_facts,
            'value_evidence': fact_id(context, EX + 'Magnitude', OSDI + 'hasExpectedValue')})
        shared_evidence = [fact_id(context, EX + 'Replacement', OSDI + 'affects'),
                           fact_id(context, EX + 'Replacement', OSDI + 'hasEffectMagnitude')]
        for arm in plan['interventions']:
            owner = fact_id(context, arm['iri'], OSDI + 'hasEffect')
            node = arm['children'][0]['children'][0]
            node['probability'] = 'Magnitude'
            node['evidence'] += shared_evidence + magnitude_facts + [owner]
            plan['decisions'].append({'topic': 'replacement', 'explanation': 'Explicit replacement relation.',
                                      'evidence': shared_evidence + [owner]})
        validate_plan(plan, context)
