"""Excel names use case-insensitive identity within their scope."""
import xml.etree.ElementTree as ET
from synthetic_support import *
from ooxml import MAIN, Q, _update_workbook_metadata, WorkbookContractError


def metadata(names=""):
    return (f'<workbook xmlns="{MAIN}"><sheets><sheet name="Parameters"/>'
            '<sheet name="Model"/></sheets><definedNames>' + names +
            '</definedNames></workbook>').encode()


class MetadataSafety(unittest.TestCase):
    def test_case_variant_cannot_replace_protected_global(self):
        source = metadata('<definedName name="language">Elsewhere!$B$2</definedName>')
        with self.assertRaisesRegex(WorkbookContractError, "protected"):
            _update_workbook_metadata(source, {"Language": "'Parameters'!$F$7"}, [])

    def test_generated_global_case_collision_is_rejected(self):
        with self.assertRaisesRegex(WorkbookContractError, "collide"):
            _update_workbook_metadata(metadata(), {"Result": "'Model'!$D$3", "result": "'Model'!$D$4"}, [])

    def test_existing_global_case_collision_is_rejected(self):
        source = metadata('<definedName name="Cost">Model!$D$3</definedName><definedName name="cost">Model!$D$4</definedName>')
        with self.assertRaisesRegex(WorkbookContractError, "Duplicate"):
            _update_workbook_metadata(source, {}, [])

    def test_allowed_global_is_updated_without_duplicate_name(self):
        source = metadata('<definedName name="Result">Model!$D$3</definedName>')
        result = _update_workbook_metadata(source, {"result": "'Model'!$D$4"}, [])
        names = list(ET.fromstring(result).find(Q("definedNames")))
        self.assertEqual(len(names), 1)
        self.assertEqual(names[0].text, "'Model'!$D$4")

    def test_generated_scoped_case_collision_is_rejected(self):
        entries = [{"name": name, "sheet": "Model", "value": 3} for name in ("Horizon", "horizon")]
        with self.assertRaisesRegex(WorkbookContractError, "Duplicate"):
            _update_workbook_metadata(metadata(), {}, entries)

    def test_existing_scoped_case_collision_is_rejected(self):
        source = metadata('<definedName name="Horizon" localSheetId="1">3</definedName><definedName name="horizon" localSheetId="1">4</definedName>')
        with self.assertRaisesRegex(WorkbookContractError, "Duplicate"):
            _update_workbook_metadata(source, {}, [{"name": "Horizon", "sheet": "Model", "value": 5}])

    def test_same_name_in_distinct_scopes_remains_allowed(self):
        source = metadata('<definedName name="Horizon">Elsewhere!$B$2</definedName>')
        entries = [{"name": "horizon", "sheet": sheet, "value": 7} for sheet in ("Parameters", "Model")]
        result = _update_workbook_metadata(source, {}, entries)
        names = list(ET.fromstring(result).find(Q("definedNames")))
        self.assertEqual(len(names), 3)
        self.assertEqual(names[0].text, "Elsewhere!$B$2")

    def test_scoped_update_matches_case_and_retains_single_name(self):
        source = metadata('<definedName name="Horizon" localSheetId="1">3</definedName>')
        result = _update_workbook_metadata(source, {}, [{"name": "horizon", "sheet": "Model", "value": 9}])
        names = list(ET.fromstring(result).find(Q("definedNames")))
        self.assertEqual(len(names), 1)
        self.assertEqual(names[0].text, "9")
