"""Post-generation comparator checks permitted sheet contents only."""
import copy
import json
import subprocess
from synthetic_support import *
from comparar_dos_hojas import compare, normalize_columns
from ooxml import read_allowed_workbook, patch_workbook, SheetSpec


class Comparison(SyntheticCase):
    def setUp(self):
        super().setUp()
        self.inputs()
        report = self.run_plan()
        self.assertEqual(report["status"], "GENERATED_STRUCTURALLY_VALIDATED", report)
        self.original = self.root / "out" / report["file"]
        self.book = read_allowed_workbook(self.original)

    def altered(self, sheet, change):
        data = copy.deepcopy(self.book["sheets"][sheet])
        change(data)
        spec = SheetSpec(**{k: v for k, v in data.items() if k in SheetSpec.__dataclass_fields__})
        output = self.root / "changed.xlsm"
        patch_workbook(self.original, output, {sheet: spec})
        return output

    def test_identical_workbook_matches(self):
        result = compare(self.original, self.original)
        self.assertTrue(result["match"])
        self.assertEqual(result["difference_count"], 0)
        self.assertEqual(result["scope"], ["Parameters", "Model"])

    def test_parameter_change_has_precise_cell_location(self):
        target = next(a for a,c in self.book["sheets"]["Parameters"]["cells"].items() if a.startswith("H") and isinstance(c.get("value"), (int,float)))
        changed = self.altered("Parameters", lambda data: data["cells"][target].update(value=1234))
        result = compare(self.original, changed)
        self.assertFalse(result["match"])
        differences = [d for d in result["differences"] if d.get("cell") == target]
        self.assertEqual(len(differences), 1)
        self.assertEqual(differences[0]["sheet"], "Parameters")
        self.assertEqual(differences[0]["actual"]["value"], 1234)

    def test_formula_change_is_reported(self):
        changed = self.altered("Model", lambda data: data["cells"]["D3"].update(formula="1+2"))
        result = compare(self.original, changed)
        self.assertTrue(any(d.get("cell") == "D3" and d["actual"].get("formula") == "1+2" for d in result["differences"]))

    def test_formula_cache_change_is_ignored(self):
        changed = self.altered("Model", lambda data: data["cells"]["D3"].update(cached=999.5))
        result = compare(self.original, changed)
        self.assertTrue(result["match"], result["differences"])

    def test_style_change_is_reported(self):
        changed = self.altered("Model", lambda data: data["cells"]["D3"].update(style=0))
        result = compare(self.original, changed)
        self.assertFalse(result["match"])
        self.assertTrue(any(d.get("cell") == "D3" for d in result["differences"]))

    def test_geometry_change_is_reported(self):
        changed = self.altered("Model", lambda data: data["columns"][0].update(width="17.25"))
        result = compare(self.original, changed)
        self.assertFalse(result["match"])
        self.assertTrue(any(d.get("section") == "columns" and d["sheet"] == "Model" for d in result["differences"]))

    def test_disjoint_column_declaration_order_matches_and_is_reported(self):
        changed = self.altered("Model", lambda data: data["columns"].reverse())
        result = compare(self.original, changed)
        self.assertTrue(result["match"], result)
        self.assertEqual(result["difference_count"], 0)
        self.assertFalse(result["raw_match"])
        self.assertEqual(result["raw_difference_count"], 1)
        self.assertEqual(result["serialization_difference_count"], 1)
        self.assertEqual(result["serialization_differences"][0]["reason"], "disjoint_column_declaration_order")
        self.assertEqual(result["raw_differences"][0]["section"], "columns")
        self.assertEqual(result["column_normalization_warnings"], [])

    def test_reordering_does_not_hide_column_geometry_or_style_changes(self):
        for attribute, value in (("width", "17.25"), ("style", "0"), ("hidden", "true")):
            with self.subTest(attribute=attribute):
                def change(data):
                    data["columns"][0][attribute] = value
                    data["columns"].reverse()
                changed = self.altered("Model", change)
                result = compare(self.original, changed)
                self.assertFalse(result["match"])
                self.assertEqual(result["serialization_differences"], [])
                self.assertTrue(any(d.get("section") == "columns" for d in result["differences"]))

    def test_overlapping_column_declaration_order_keeps_raw_comparison(self):
        columns = [{"min": "1", "max": "3", "width": "10"},
                   {"min": "2", "max": "4", "width": "20"}]
        first = self.altered("Model", lambda data: data.update(columns=columns))
        expected = first.rename(self.root / "overlapping.xlsm")
        actual = self.altered("Model", lambda data: data.update(columns=list(reversed(columns))))
        result = compare(expected, actual)
        self.assertFalse(result["match"])
        self.assertEqual(result["differences"], result["raw_differences"])
        self.assertEqual(result["serialization_differences"], [])
        self.assertEqual(len(result["column_normalization_warnings"]), 2)
        self.assertTrue(all(w["reason"] == "overlapping_column_ranges" for w in result["column_normalization_warnings"]))
        unchanged = compare(expected, expected)
        self.assertTrue(unchanged["match"])
        self.assertEqual(len(unchanged["column_normalization_warnings"]), 2)

    def test_invalid_column_ranges_are_not_normalized(self):
        for columns in ([{"min": "2", "max": "1"}], [{"min": "0", "max": "1"}],
                        [{"min": "1", "max": "16385"}], [{"min": "x", "max": "2"}],
                        [{"min": "1"}]):
            with self.subTest(columns=columns):
                normalized, warning = normalize_columns(columns)
                self.assertEqual(normalized, columns)
                self.assertEqual(warning["reason"], "invalid_column_range")

    def test_cli_generates_report_without_touching_workbooks(self):
        output = self.root / "comparison.json"
        original = self.original.read_bytes()
        process = subprocess.run([sys.executable, str(PACKAGE / "comparar_dos_hojas.py"), "--expected", str(self.original), "--actual", str(self.original), "--report", str(output)], capture_output=True, text=True)
        self.assertEqual(process.returncode, 0, process.stderr)
        self.assertTrue(json.loads(output.read_text(encoding="utf-8"))["match"])
        self.assertEqual(self.original.read_bytes(), original)

    def test_cli_cannot_overwrite_a_compared_workbook(self):
        original = self.original.read_bytes()
        process = subprocess.run([sys.executable, str(PACKAGE / "comparar_dos_hojas.py"), "--expected", str(self.original), "--actual", str(self.original), "--report", str(self.original)], capture_output=True, text=True)
        self.assertNotEqual(process.returncode, 0)
        self.assertEqual(self.original.read_bytes(), original)
