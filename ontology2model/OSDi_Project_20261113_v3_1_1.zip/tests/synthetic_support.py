"""Artificial inputs and a manually specified plan; never a TTL-to-tree builder.

The fixtures contain explicit topology/payoffs. Binding source hashes and fact
identifiers only supplies evidence; no clinical structure is inferred here.
"""
from copy import deepcopy
import json
from pathlib import Path
import sys
import tempfile
import unittest

PACKAGE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE))
sys.path.insert(0, str(PACKAGE / 'engine'))
from ai_contract import prepare_context, validate_plan
from generar_desde_plan import generate

EX = 'https://example.org/artificial/'
OSDI = 'https://w3id.org/ontologies-ULL/OSDi#'
RDF = 'http://www.w3.org/1999/02/22-rdf-syntax-ns#'


def case_text(import_version='1.1', second_order=False, cost=False):
    text = '''@prefix ex: <https://example.org/artificial/> .
@prefix o: <https://w3id.org/ontologies-ULL/OSDi#> .
@prefix owl: <http://www.w3.org/2002/07/owl#> .
@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .
ex:Ontology a owl:Ontology ; owl:imports <https://w3id.org/ontologies-ULL/OSDi/VERSION> .
ex:Model a o:DecisionTreeModel ; o:includesModelItem ex:Condition, ex:Population, ex:ArmA, ex:ArmB, ex:Age .
ex:Condition a o:Disease ; o:hasProgressionElement ex:Progression .
ex:Population a o:Population ; o:hasAge ex:Age ; o:hasLifeExpectancy ex:Life ; o:hasUtility ex:BaselineUtility ; o:hasEpidemiologicalParameter ex:Prevalence .
ex:Run a o:Experiment ; o:usesModel ex:Model ; o:hasYear 2031 ; o:hasTimeHorizon 25 ; o:hasDiscountForCosts 0.02 ; o:hasDiscountForEffects 0.02 .
ex:Age a o:AttributeValueParameter, o:DeterministicParameter ; o:hasExpectedValue 0 .
ex:Life a o:AttributeValueParameter, o:DeterministicParameter ; o:hasExpectedValue 30 .
ex:BaselineUtility a o:Utility, o:DeterministicParameter ; o:hasExpectedValue 0.9 ; o:hasDataItemType o:DI_Continuous_Variable ; o:isDisutility false .
ex:Prevalence a o:EpidemiologicalParameter, o:DeterministicParameter ; o:hasExpectedValue 0.2 ; o:hasDataItemType o:DI_Prevalence .
ex:Risk a o:Parameter, o:DeterministicParameter ; o:hasExpectedValue 0.3 ; o:hasDataItemType o:DI_Probability .
ex:ArmA a o:TherapeuticIntervention ; o:isAssessedIntervention true .
ex:ArmB a o:TherapeuticIntervention ; o:isAssessedIntervention false .
ex:Progression a o:ChronicManifestation ; o:hasRiskCharacterization ex:Risk .
'''.replace('OSDi/VERSION', 'OSDi/' + import_version)
    if second_order:
        text = text.replace('ex:Risk a o:Parameter, o:DeterministicParameter', 'ex:Risk a o:Parameter, o:SecondOrderUncertaintyParameter')
        text += '''ex:Risk o:hasUncertaintyCharacterization ex:Distribution .
ex:Distribution a o:BetaDistributionExpression ; o:hasAlfaParameter 3 ; o:hasBetaParameter 7 .
'''
    if cost:
        text += '''ex:ArmA o:hasCost ex:VisitCost .
ex:VisitCost a o:Cost, o:DeterministicParameter ; o:hasExpectedValue 16 ; o:hasYear 2029 ; o:appliesOneTime true ; o:hasDataItemType o:Currency_Euro .
'''
    return text


def fact_id(context, subject, predicate, value=None):
    matches = [fact['id'] for fact in context['facts']
               if fact['subject'] == subject and fact['predicate'] == predicate
               and (value is None or fact['object']['value'] == value)]
    if len(matches) != 1:
        raise AssertionError('Expected one explicit evidence fact: ' + repr((subject, predicate, value, matches)))
    return matches[0]


def explicit_plan(context, second_order=False, cost=False, missing_settings=()):
    """Return a fixed, hand-authored synthetic model, with evidence IDs bound."""
    def evidence(subject):
        return [fact['id'] for fact in context['facts'] if fact['subject'] == EX + subject]

    parameters = []
    for ident, group, value in [('Age', 'ATTRIBUTE', 0), ('Life', 'ATTRIBUTE', 30),
                                 ('Prevalence', 'RISK', 0.2), ('Risk', 'RISK', 0.3)]:
        parameters.append({'iri': EX + ident, 'id': ident, 'name': ident, 'group': group,
                           'uncertainty': 'DETERMINISTIC', 'expected': value, 'year': None,
                           'description': '', 'source': 'Unknown', 'distribution': None, 'one_time': None,
                           'value_evidence': fact_id(context, EX + ident, OSDI + 'hasExpectedValue'),
                           'evidence': evidence(ident)})
    if cost:
        parameters.append({'iri': EX + 'VisitCost', 'id': 'VisitCost', 'name': 'VisitCost', 'group': 'COST',
                           'uncertainty': 'DETERMINISTIC', 'expected': 16, 'year': 2029,
                           'description': '', 'source': 'Unknown', 'distribution': None, 'one_time': True,
                           'value_evidence': fact_id(context, EX + 'VisitCost', OSDI + 'hasExpectedValue'),
                           'year_evidence': fact_id(context, EX + 'VisitCost', OSDI + 'hasYear'),
                           'one_time_evidence': fact_id(context, EX + 'VisitCost', OSDI + 'appliesOneTime'),
                           'evidence': evidence('VisitCost')})
    parameters.append({'iri': EX + 'BaselineUtility', 'id': 'BaselineUtility', 'name': 'BaselineUtility',
                       'group': 'UTILITY', 'uncertainty': 'DETERMINISTIC', 'expected': 0.9,
                       'year': None, 'description': '', 'source': 'Unknown', 'distribution': None, 'one_time': None,
                       'value_evidence': fact_id(context, EX + 'BaselineUtility', OSDI + 'hasExpectedValue'),
                       'evidence': evidence('BaselineUtility')})
    if second_order:
        risk = next(p for p in parameters if p['id'] == 'Risk')
        risk.update(uncertainty='SECOND_ORDER',
                    distribution={'iri': EX + 'Distribution', 'kind': 'BETA',
                                  'parameters': {'hasAlfaParameter': 3, 'hasBetaParameter': 7}},
                    distribution_evidence={key: fact_id(context, EX + 'Distribution', OSDI + key)
                                           for key in ['hasAlfaParameter', 'hasBetaParameter']})
        risk['evidence'] += evidence('Distribution')
    payoffs = {'cost': '0', 'le': 'PV(discountLE,{life},-1)',
               'qale': 'PV(discountQALE,{life},-BaselineUtility)',
               'life': 'MIN(Life, timeHorizon)'}
    interventions = []
    # Each topology below is an explicit authored fixture, not inferred from TTL.
    for arm in ['ArmA', 'ArmB']:
        arm_payoffs = deepcopy(payoffs)
        if cost and arm == 'ArmA':
            arm_payoffs['cost'] = 'VisitCost'
        common = evidence('Progression') + evidence('Risk')
        active = {'id': arm + '_progression', 'label': 'Progression', 'probability': 'Risk',
                  'payoffs': deepcopy(arm_payoffs), 'active_progressions': [EX + 'Progression'],
                  'state': {'intervention': EX + arm, 'disease': True}, 'evidence': common}
        inactive = {'id': arm + '_no_progression', 'label': 'No Progression', 'residual': True,
                    'payoffs': deepcopy(arm_payoffs), 'active_progressions': [],
                    'state': {'intervention': EX + arm, 'disease': True}, 'evidence': common}
        diseased = {'id': arm + '_disease', 'label': 'Has the disease', 'probability': 'Prevalence',
                    'children': [active, inactive], 'evidence': evidence('Population') + evidence('Prevalence')}
        healthy = {'id': arm + '_healthy', 'label': 'Does not have disease', 'residual': True,
                   'payoffs': deepcopy(arm_payoffs), 'active_progressions': [],
                   'state': {'intervention': EX + arm, 'disease': False},
                   'evidence': evidence('Population') + evidence('Prevalence')}
        interventions.append({'iri': EX + arm, 'label': arm, 'children': [diseased, healthy],
                              'evidence': evidence(arm)})
    settings = {'studyYear': 2031, 'timeHorizon': 25, 'discountCosts': 0.02,
                'discountLE': 0.02, 'discountQALE': 0.02, 'isProbabilistic': 0}
    settings = {key: value for key, value in settings.items() if key not in missing_settings}
    settings_evidence = {key: fact_id(context, EX + 'Run', OSDI + predicate)
                         for key, predicate in [('studyYear', 'hasYear'), ('timeHorizon', 'hasTimeHorizon'),
                                                ('discountCosts', 'hasDiscountForCosts'),
                                                ('discountLE', 'hasDiscountForEffects'),
                                                ('discountQALE', 'hasDiscountForEffects')] if key in settings}
    return {'format': 'osdi-ai-plan/1',
            'authorship': {'kind': 'ai', 'system': 'ChatGPT', 'model': 'not-recorded',
                          'note': 'Explicit artificial fixture authored during development; not proof of runtime AI execution.'},
            'source': {'case_sha256': context['case_sha256'], 'schema_sha256': context['schema_sha256']},
            'model_iri': EX + 'Model', 'parameters': parameters, 'settings': settings,
            'settings_evidence': settings_evidence, 'interventions': interventions,
            'coverage': [{'facts': [f['id'] for f in context['facts']], 'disposition': 'used',
                          'reason': 'All assertions describe this artificial case and its declared ontology.'}],
            'decisions': [{'topic': 'finite-tree', 'explanation': 'Explicit disease/complement and progression/complement per arm; no inferred dependence.',
                           'evidence': evidence('Condition') + evidence('Population') + evidence('Progression')}],
            'blockers': [], 'unresolved_dependencies': list(missing_settings)}


class SyntheticCase(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='osdi_ai_synthetic_', dir=PACKAGE.parent)
        self.root = Path(self.temp.name)
        self.addCleanup(self.temp.cleanup)

    def inputs(self, *, second_order=False, cost=False, version='1.1', compatibility=None):
        self.case = self.root / 'case.ttl'
        self.case.write_text(case_text(version, second_order, cost), encoding='utf-8')
        self.context = prepare_context(self.case, None, compatibility, PACKAGE)
        self.plan = explicit_plan(self.context, second_order, cost)
        return self.plan, self.context

    def run_plan(self, plan=None, out='out', compatibility=None, template=None):
        path = self.root / (out + '.plan.json')
        path.write_text(json.dumps(self.plan if plan is None else plan, ensure_ascii=False, indent=2), encoding='utf-8')
        return generate(self.case, path, self.root / out, template=template, compatibility_profile=compatibility)
