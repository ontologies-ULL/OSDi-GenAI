#!/usr/bin/env python3
"""Optional post-generation comparison; never an input to the generator."""
import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent / 'engine'))
from ooxml import read_allowed_workbook


def normalize_columns(columns):
    """Sort disjoint declarations only; preserve every declared attribute.

    XML declaration order does not change disjoint column geometry. Overlapping
    or invalid ranges are deliberately left raw because their order may matter.
    """
    ranges = []
    for index, declaration in enumerate(columns):
        try:
            minimum, maximum = int(declaration['min']), int(declaration['max'])
        except (KeyError, TypeError, ValueError):
            return columns, {'reason': 'invalid_column_range', 'declaration_index': index}
        if not 1 <= minimum <= maximum <= 16384:
            return columns, {'reason': 'invalid_column_range', 'declaration_index': index}
        ranges.append((minimum, maximum, index, declaration))
    ranges.sort(key=lambda item: item[0])
    for previous, current in zip(ranges, ranges[1:]):
        if current[0] <= previous[1]:
            return columns, {'reason': 'overlapping_column_ranges',
                             'declaration_indices': [previous[2], current[2]]}
    return [item[3] for item in ranges], None


def compare(expected, actual):
    left, right = read_allowed_workbook(expected), read_allowed_workbook(actual)
    differences = []
    raw_differences = []
    serialization_differences = []
    column_normalization_warnings = []
    same_styles = left['styles_fingerprint'] == right['styles_fingerprint']
    for sheet in ('Parameters', 'Model'):
        a, b = left['sheets'][sheet], right['sheets'][sheet]
        for address in sorted(set(a['cells']) | set(b['cells'])):
            # Cached values can be stale and are not a native recalculation test.
            ca = {k: v for k, v in a['cells'].get(address, {}).items() if k not in ('cached', 'cached_type')}
            cb = {k: v for k, v in b['cells'].get(address, {}).items() if k not in ('cached', 'cached_type')}
            if ca != cb:
                difference = {'sheet': sheet, 'cell': address, 'expected': ca, 'actual': cb}
                differences.append(difference)
                raw_differences.append(difference)
        for key in ('columns', 'row_attributes', 'merges', 'dimension', 'sheet_format'):
            normalized_a, normalized_b = a[key], b[key]
            if key == 'columns':
                normalized_a, warning_a = normalize_columns(a[key])
                normalized_b, warning_b = normalize_columns(b[key])
                for side, warning in (('expected', warning_a), ('actual', warning_b)):
                    if warning:
                        column_normalization_warnings.append({'sheet': sheet, 'side': side, **warning})
                if warning_a or warning_b:
                    # Neither side is normalized when either is ambiguous.
                    normalized_a, normalized_b = a[key], b[key]
            if a[key] != b[key]:
                difference = {'sheet': sheet, 'section': key, 'expected': a[key], 'actual': b[key]}
                raw_differences.append(difference)
                if normalized_a == normalized_b:
                    serialization_differences.append({**difference, 'reason': 'disjoint_column_declaration_order'})
                else:
                    differences.append(difference)
    return {'scope': ['Parameters', 'Model'], 'comparison': 'EXACT_CELL_CONTENT_FORMULAS_STYLE_IDS_AND_NORMALIZED_GEOMETRY',
            'match': same_styles and not differences, 'shared_style_table_identical': same_styles,
            'differences': differences, 'difference_count': len(differences),
            'raw_match': same_styles and not raw_differences,
            'raw_differences': raw_differences, 'raw_difference_count': len(raw_differences),
            'serialization_differences': serialization_differences,
            'serialization_difference_count': len(serialization_differences),
            'column_normalization_warnings': column_normalization_warnings,
            'limitations': ['Formula caches and native Excel recalculation not compared.',
                            'Different style tables require semantic style review; style IDs alone are insufficient.',
                            'Only disjoint column declaration order is normalized; overlapping or invalid ranges retain raw comparison.',
                            'No other worksheet content inspected; no reference data passed to generator.',
                            'Defined names and external calculation context not compared.']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected', type=Path, required=True)
    parser.add_argument('--actual', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    if args.report.resolve() in (args.expected.resolve(), args.actual.resolve()):
        parser.error('Report must not overwrite either workbook.')
    result = compare(args.expected, args.actual)
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding='utf-8')
    print(json.dumps({'match': result['match'], 'difference_count': result['difference_count']}))
    return 0 if result['match'] else 1


if __name__ == '__main__':
    sys.exit(main())
